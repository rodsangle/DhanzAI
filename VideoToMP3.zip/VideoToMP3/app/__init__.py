"""Video to MP3 Converter & Downloader."""

APP_NAME = "VideoToMP3"
APP_DISPLAY_NAME = "Video to MP3 Converter & Downloader"
APP_TITLE = "VIDEO TO MP3 CONVERTER & DOWNLOADER"
__version__ = "1.0.0"
