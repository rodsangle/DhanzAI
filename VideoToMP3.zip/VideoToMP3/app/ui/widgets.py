"""Reusable widgets: cards, form helpers, drag-and-drop area and the job card."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QUrl, Qt, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QProgressBar, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

from app.core.ffmpeg import AUDIO_FORMATS, QUALITY_PRESETS
from app.core.jobs import Job, JobKind, JobStatus
from app.core.utils import format_duration, parse_time
from app.core.validators import VIDEO_EXTENSIONS, collect_video_files
from app.ui import icons


def label(text: str = "", role: str | None = None, wrap: bool = False) -> QLabel:
    lbl = QLabel(text)
    if role:
        lbl.setProperty("role", role)
    lbl.setWordWrap(wrap)
    return lbl


def button(text: str, icon_name: str | None = None, variant: str | None = None, tooltip: str = "") -> QPushButton:
    btn = QPushButton(text)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    if variant:
        btn.setProperty("variant", variant)
    if icon_name:
        icons.set_icon(btn, icon_name, "#FFFFFF" if variant == "accent" else None)
    if tooltip:
        btn.setToolTip(tooltip)
    return btn


def repolish(widget: QWidget) -> None:
    widget.style().unpolish(widget)
    widget.style().polish(widget)


class Card(QFrame):
    def __init__(self, title: str | None = None, subtitle: str | None = None, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(20, 18, 20, 20)
        self.body.setSpacing(12)
        if title:
            self.body.addWidget(label(title, "heading"))
        if subtitle:
            self.body.addWidget(label(subtitle, "muted", wrap=True))


def page_scroll(content: QWidget) -> QScrollArea:
    """Wrap a tab page so it scrolls on small screens instead of squashing controls."""
    area = QScrollArea()
    area.setObjectName("pageScroll")
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    content.setObjectName("page")
    area.setWidget(content)
    return area


def format_combo(selected: str = "mp3") -> QComboBox:
    combo = QComboBox()
    for key, fmt in AUDIO_FORMATS.items():
        combo.addItem(fmt.label, key)
    combo.setCurrentIndex(max(0, combo.findData(selected)))
    return combo


def quality_combo(selected: str = "192") -> QComboBox:
    combo = QComboBox()
    for key, text in QUALITY_PRESETS.items():
        combo.addItem(text, key)
    combo.setCurrentIndex(max(0, combo.findData(selected)))
    combo.setToolTip("Original quality keeps the source audio untouched when possible (no re-encoding).\n"
                     "Smaller file size uses 96 kbps.")
    return combo


def sync_quality_enabled(fmt_combo: QComboBox, quality: QComboBox) -> None:
    lossless = AUDIO_FORMATS[fmt_combo.currentData()].lossless
    quality.setEnabled(not lossless)
    quality.setToolTip("Lossless format: quality setting not needed." if lossless else
                       "Original quality keeps the source audio untouched when possible (no re-encoding).")


class TimeEdit(QLineEdit):
    """Line edit accepting HH:MM:SS / MM:SS / seconds; highlights invalid input."""

    def __init__(self, placeholder: str):
        super().__init__()
        self.setPlaceholderText(placeholder)
        self.setMaximumWidth(140)
        self.textChanged.connect(self._validate)

    def _validate(self) -> None:
        try:
            parse_time(self.text())
            ok = True
        except ValueError:
            ok = False
        self.setProperty("invalid", not ok)
        repolish(self)

    def seconds(self) -> float | None:
        return parse_time(self.text())


class FolderPicker(QWidget):
    changed = Signal(str)

    def __init__(self, path: str, title: str = "Choose output folder"):
        super().__init__()
        self._title = title
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        self.edit = QLineEdit(path)
        self.edit.editingFinished.connect(lambda: self.changed.emit(self.path()))
        browse = button("Browse", "folder")
        browse.clicked.connect(self._browse)
        lay.addWidget(self.edit, 1)
        lay.addWidget(browse)

    def path(self) -> str:
        return self.edit.text().strip()

    def set_path(self, path: str) -> None:
        self.edit.setText(path)

    def _browse(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, self._title, self.path() or str(Path.home()))
        if chosen:
            self.edit.setText(os.path.normpath(chosen))
            self.changed.emit(self.path())


class DropArea(QFrame):
    """Drag-and-drop target for video files and folders; click to browse."""

    files_dropped = Signal(list, list)  # accepted paths, rejected names
    browse_requested = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("dropArea")
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(170)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setSpacing(6)
        self._icon = QLabel()
        self._icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icon.setPixmap(icons.pixmap("upload", 40, "#3B82F6"))
        lay.addWidget(self._icon)
        title = label("Drag & drop video files or folders here", "heading")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)
        exts = ", ".join(e[1:].upper() for e in VIDEO_EXTENSIONS)
        sub = label(f"Supported: {exts}", "muted")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)
        self.browse_btn = button("Browse Files", "plus", "accent")
        self.browse_btn.clicked.connect(self.browse_requested)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(self.browse_btn)
        row.addStretch()
        lay.addSpacing(6)
        lay.addLayout(row)

    def mousePressEvent(self, event):  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.browse_requested.emit()
        super().mousePressEvent(event)

    def _set_hover(self, on: bool) -> None:
        self.setProperty("hover", on)
        repolish(self)

    def dragEnterEvent(self, event):  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self._set_hover(True)

    def dragLeaveEvent(self, event):  # noqa: N802
        self._set_hover(False)

    def dropEvent(self, event):  # noqa: N802
        self._set_hover(False)
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        files, rejected = collect_video_files(paths)
        self.files_dropped.emit([str(f) for f in files], rejected)
        event.acceptProposedAction()


def open_folder(path: str | Path, select_file: str | Path | None = None) -> None:
    """Open a folder in Explorer, optionally highlighting a file."""
    path = Path(path)
    if select_file and Path(select_file).exists() and sys.platform == "win32":
        subprocess.Popen(["explorer", "/select,", str(Path(select_file))])
        return
    path.mkdir(parents=True, exist_ok=True)
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


class JobCard(QFrame):
    """One row in the download manager: title, status, progress, speed/ETA and actions."""

    cancel_requested = Signal(int)
    retry_requested = Signal(int)
    remove_requested = Signal(int)

    def __init__(self, job: Job):
        super().__init__()
        self.job_id = job.id
        self.setObjectName("jobCard")
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        outer = QHBoxLayout(self)
        outer.setContentsMargins(14, 12, 12, 12)
        outer.setSpacing(12)

        self.kind_icon = QLabel()
        self.kind_icon.setFixedSize(36, 36)
        self.kind_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.addWidget(self.kind_icon, 0, Qt.AlignmentFlag.AlignTop)

        mid = QVBoxLayout()
        mid.setSpacing(5)
        self.title = label("", None)
        self.title.setStyleSheet("font-weight: 600;")
        self.title.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.subtitle = label("", "small")
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.status = label("", "small")
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        for w in (self.title, self.subtitle, self.progress, self.status):
            mid.addWidget(w)
        outer.addLayout(mid, 1)

        actions = QHBoxLayout()
        actions.setSpacing(4)
        self.btn_cancel = button("Cancel", "stop", "danger", "Cancel this task")
        self.btn_retry = button("Retry", "retry", None, "Run this task again")
        self.btn_open = button("", "folder", "ghost", "Show in folder")
        self.btn_remove = button("", "x", "ghost", "Remove from list")
        for b in (self.btn_cancel, self.btn_retry, self.btn_open, self.btn_remove):
            actions.addWidget(b)
        outer.addLayout(actions)

        self.btn_cancel.clicked.connect(lambda: self.cancel_requested.emit(self.job_id))
        self.btn_retry.clicked.connect(lambda: self.retry_requested.emit(self.job_id))
        self.btn_remove.clicked.connect(lambda: self.remove_requested.emit(self.job_id))
        self.btn_open.clicked.connect(self._open)
        self._job = job
        self.update_job(job)

    def _open(self) -> None:
        job = self._job
        open_folder(job.options.output_dir, job.output_path or None)

    def update_job(self, job: Job) -> None:
        self._job = job
        st = job.status
        is_video = job.options.fmt == "mp4"
        self.kind_icon.setPixmap(icons.pixmap("film" if is_video else "music", 26, "#3B82F6"))
        name = Path(job.output_path).name if job.output_path else job.target_path.name
        self.title.setText(name)
        source = job.source if job.kind == JobKind.DOWNLOAD else Path(job.source).name
        kind = "Download" if job.kind == JobKind.DOWNLOAD else "Convert"
        self.subtitle.setText(f"{kind} · {job.format_label} · {source}")
        self.subtitle.setToolTip(job.source)

        if job.progress is None and st == JobStatus.RUNNING:
            self.progress.setRange(0, 0)  # indeterminate (e.g. merging, unknown size)
        else:
            self.progress.setRange(0, 1000)
            self.progress.setValue(int((job.progress or 0) * 10))
        parts = [job.phase]
        if st == JobStatus.RUNNING and job.progress is not None:
            parts.append(f"{job.progress:.1f}%")
        if job.speed:
            parts.append(job.speed)
        if job.eta:
            parts.append(f"ETA {job.eta}")
        if st == JobStatus.FAILED and job.error:
            parts = [f"Failed: {job.error}"]
        if st == JobStatus.COMPLETED and job.started_at and job.finished_at:
            parts.append(f"in {format_duration(job.finished_at - job.started_at)}")
            parts.append(job.output_path)
        self.status.setText("  ·  ".join(p for p in parts if p))
        for w in (self, self.progress, self.status):
            w.setProperty("status", st.name.title() if st != JobStatus.QUEUED else "Queued")
            repolish(w)

        self.btn_cancel.setVisible(not st.finished)
        self.btn_retry.setVisible(st in (JobStatus.FAILED, JobStatus.CANCELLED))
        self.btn_open.setVisible(st == JobStatus.COMPLETED)
        self.btn_remove.setVisible(st.finished)
