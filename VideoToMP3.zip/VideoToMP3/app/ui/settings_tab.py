"""Tab 4: preferences and dependency status."""

from __future__ import annotations

import os
import sys

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QSpinBox, QVBoxLayout, QWidget)

from app import APP_DISPLAY_NAME, __version__
from app.core.dependencies import DependencyStatus
from app.core.paths import user_data_dir
from app.core.validators import ValidationError, validate_output_dir
from app.ui import icons
from app.ui.context import AppContext
from app.ui.dialogs import show_error
from app.ui.widgets import Card, FolderPicker, button, format_combo, label, open_folder, page_scroll, quality_combo

FFMPEG_HELP_URL = "https://www.gyan.dev/ffmpeg/builds/"


class SettingsTab(QWidget):
    def __init__(self, ctx: AppContext, apply_theme):
        super().__init__()
        self.ctx = ctx
        self._apply_theme = apply_theme
        s = ctx.settings

        content = QWidget()
        root = QVBoxLayout(content)
        root.setContentsMargins(24, 16, 24, 24)
        root.setSpacing(16)

        # --- General -----------------------------------------------------------------
        general = Card("Downloads & conversion")
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        self.folder = FolderPicker(s.download_dir, "Default download folder")
        self.folder.changed.connect(self._folder_changed)
        ctx.output_dir_changed.connect(self.folder.set_path)
        self.format_combo = format_combo(s.default_format)
        self.format_combo.currentIndexChanged.connect(lambda: self._set("default_format", self.format_combo.currentData()))
        self.quality_combo = quality_combo(s.default_quality)
        self.quality_combo.currentIndexChanged.connect(lambda: self._set("default_quality", self.quality_combo.currentData()))
        self.concurrent = QSpinBox()
        self.concurrent.setRange(1, 5)
        self.concurrent.setValue(s.max_concurrent)
        self.concurrent.valueChanged.connect(self._concurrency_changed)
        self.res_combo = QComboBox()
        for h in (2160, 1440, 1080, 720, 480, 360):
            self.res_combo.addItem(f"{h}p", h)
        self.res_combo.setCurrentIndex(max(0, self.res_combo.findData(s.video_height)))
        self.res_combo.currentIndexChanged.connect(lambda: self._set("video_height", self.res_combo.currentData()))
        self.cover_check = QCheckBox("Embed thumbnail / cover art by default")
        self.cover_check.setChecked(s.embed_cover)
        self.cover_check.toggled.connect(lambda v: self._set("embed_cover", v))
        self.notify_check = QCheckBox("Show desktop notifications when tasks finish")
        self.notify_check.setChecked(s.notifications)
        self.notify_check.toggled.connect(lambda v: self._set("notifications", v))

        def field(text):
            return label(text, "field")

        grid.addWidget(field("Default download folder"), 0, 0)
        grid.addWidget(self.folder, 0, 1, 1, 3)
        grid.addWidget(field("Default audio format"), 1, 0)
        grid.addWidget(self.format_combo, 1, 1)
        grid.addWidget(field("Default audio bitrate"), 1, 2)
        grid.addWidget(self.quality_combo, 1, 3)
        grid.addWidget(field("Max simultaneous tasks"), 2, 0)
        grid.addWidget(self.concurrent, 2, 1)
        grid.addWidget(field("Preferred MP4 resolution"), 2, 2)
        grid.addWidget(self.res_combo, 2, 3)
        grid.addWidget(self.cover_check, 3, 1, 1, 2)
        grid.addWidget(self.notify_check, 4, 1, 1, 2)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        general.body.addLayout(grid)
        root.addWidget(general)

        # --- Appearance --------------------------------------------------------------
        appearance = Card("Appearance")
        row = QHBoxLayout()
        row.addWidget(field("Theme"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItem("Dark", "dark")
        self.theme_combo.addItem("Light", "light")
        self.theme_combo.setCurrentIndex(max(0, self.theme_combo.findData(s.theme)))
        self.theme_combo.currentIndexChanged.connect(self._theme_changed)
        row.addWidget(self.theme_combo)
        row.addStretch()
        appearance.body.addLayout(row)
        root.addWidget(appearance)

        # --- Dependencies ------------------------------------------------------------
        deps = Card("Dependencies",
                    "FFmpeg converts audio (required for conversions and audio downloads). yt-dlp handles "
                    "online video sites. Both are detected automatically.")
        self.dep_grid = QGridLayout()
        self.dep_grid.setHorizontalSpacing(14)
        self.dep_grid.setVerticalSpacing(8)
        self.dep_rows: dict[str, tuple[QLabel, QLabel, QLabel]] = {}
        for i, key in enumerate(("ffmpeg", "ffprobe", "ytdlp")):
            icon_lbl, name_lbl, detail_lbl = QLabel(), label("", "field"), label("", "small", wrap=True)
            self.dep_grid.addWidget(icon_lbl, i, 0)
            self.dep_grid.addWidget(name_lbl, i, 1)
            self.dep_grid.addWidget(detail_lbl, i, 2)
            self.dep_rows[key] = (icon_lbl, name_lbl, detail_lbl)
        self.dep_grid.setColumnStretch(2, 1)
        deps.body.addLayout(self.dep_grid)
        custom = QHBoxLayout()
        custom.addWidget(field("Custom FFmpeg location"))
        self.ffmpeg_edit = QLineEdit(s.ffmpeg_path)
        self.ffmpeg_edit.setPlaceholderText("Optional: folder containing ffmpeg.exe (auto-detected if empty)")
        self.ffmpeg_edit.editingFinished.connect(self._ffmpeg_path_changed)
        browse = button("Browse", "folder")
        browse.clicked.connect(self._browse_ffmpeg)
        custom.addWidget(self.ffmpeg_edit, 1)
        custom.addWidget(browse)
        deps.body.addLayout(custom)
        actions = QHBoxLayout()
        self.recheck_btn = button("Re-check Dependencies", "retry")
        self.recheck_btn.clicked.connect(self.recheck)
        get_ffmpeg = button("Get FFmpeg for Windows", "open")
        get_ffmpeg.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(FFMPEG_HELP_URL)))
        actions.addWidget(self.recheck_btn)
        actions.addWidget(get_ffmpeg)
        actions.addStretch()
        deps.body.addLayout(actions)
        root.addWidget(deps)

        # --- About -------------------------------------------------------------------
        about = Card("About")
        about.body.addWidget(label(f"{APP_DISPLAY_NAME} — version {__version__}", None))
        about.body.addWidget(label(
            "Use this application only for media you own or have permission to download. It does not bypass "
            "DRM, logins, paywalls or other website restrictions, and never asks for website passwords.",
            "small", wrap=True))
        data_row = QHBoxLayout()
        data_btn = button("Open Data Folder (settings, history, logs)", "folder")
        data_btn.clicked.connect(lambda: open_folder(user_data_dir()))
        data_row.addWidget(data_btn)
        data_row.addStretch()
        about.body.addLayout(data_row)
        root.addWidget(about)
        root.addStretch()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(page_scroll(content))
        ctx.deps_changed.connect(self.show_dependencies)
        self.show_dependencies()

    # ---------------------------------------------------------------- handlers
    def _set(self, key: str, value) -> None:
        setattr(self.ctx.settings, key, value)
        self.ctx.settings.save()

    def _folder_changed(self, path: str) -> None:
        try:
            validate_output_dir(path)
        except ValidationError as exc:
            show_error(self, "Invalid folder", str(exc))
            self.folder.set_path(self.ctx.settings.download_dir)
            return
        self.ctx.remember_output_dir(os.path.normpath(path))

    def _concurrency_changed(self, value: int) -> None:
        self._set("max_concurrent", value)
        self.ctx.manager.set_max_concurrent(value)

    def _theme_changed(self) -> None:
        theme = self.theme_combo.currentData()
        self._set("theme", theme)
        self._apply_theme(theme)

    def _browse_ffmpeg(self) -> None:
        exe = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
        path, _ = QFileDialog.getOpenFileName(self, "Locate ffmpeg executable", self.ffmpeg_edit.text(),
                                              f"FFmpeg ({exe});;All files (*)")
        if path:
            self.ffmpeg_edit.setText(os.path.normpath(os.path.dirname(path)))
            self._ffmpeg_path_changed()

    def _ffmpeg_path_changed(self) -> None:
        value = self.ffmpeg_edit.text().strip()
        if value != self.ctx.settings.ffmpeg_path:
            self._set("ffmpeg_path", value)
            self.recheck()

    def recheck(self) -> None:
        self.recheck_btn.setEnabled(False)
        self.recheck_btn.setText("Checking…")

        def done():
            self.recheck_btn.setEnabled(True)
            self.recheck_btn.setText("Re-check Dependencies")

        self.ctx.refresh_dependencies(done)

    def show_dependencies(self) -> None:
        d = self.ctx.deps
        for key, status in (("ffmpeg", d.ffmpeg), ("ffprobe", d.ffprobe), ("ytdlp", d.ytdlp)):
            self._show_dep(key, status)

    def _show_dep(self, key: str, st: DependencyStatus) -> None:
        icon_lbl, name_lbl, detail_lbl = self.dep_rows[key]
        optional = key == "ffprobe"
        if st.found:
            icon_lbl.setPixmap(icons.pixmap("check", 20, "#22C55E"))
            name_lbl.setText(f"{st.name}  ✓ Found")
            detail_lbl.setText(f"Version {st.version}  ·  {st.source}")
            detail_lbl.setToolTip(st.path or "")
        else:
            icon_lbl.setPixmap(icons.pixmap("alert", 20, "#F59E0B" if optional else "#EF4444"))
            name_lbl.setText(f"{st.name}  {'(optional)' if optional else '✗ Missing'}")
            detail_lbl.setText(st.detail or "Not found.")
            detail_lbl.setToolTip("")
