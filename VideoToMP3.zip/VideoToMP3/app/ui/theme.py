"""Dark / light themes: a Fusion palette plus a Qt stylesheet with blue accents."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

from app.core.paths import user_data_dir

PALETTES = {
    "dark": {
        "bg": "#0E131D", "surface": "#161C29", "surface2": "#1D2435", "input": "#111724",
        "border": "#283149", "border_strong": "#36405B", "text": "#E7EBF3", "muted": "#8C95AB",
        "accent": "#3B82F6", "accent_hover": "#2F6FE0", "accent_pressed": "#2459BD",
        "accent_soft": "rgba(59,130,246,0.16)", "success": "#22C55E", "danger": "#EF4444",
        "warning": "#F59E0B", "selection": "#2B4C86",
    },
    "light": {
        "bg": "#F3F5FA", "surface": "#FFFFFF", "surface2": "#EEF1F7", "input": "#FFFFFF",
        "border": "#D9DFEA", "border_strong": "#C3CBDB", "text": "#18202F", "muted": "#5D6880",
        "accent": "#2F6FE0", "accent_hover": "#2459BD", "accent_pressed": "#1D4A9E",
        "accent_soft": "rgba(47,111,224,0.12)", "success": "#16A34A", "danger": "#DC2626",
        "warning": "#D97706", "selection": "#CFE0FF",
    },
}


def colors(theme: str) -> dict:
    return PALETTES.get(theme, PALETTES["dark"])


_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{color}" ' \
       'stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round"><path d="{path}"/></svg>'


def _theme_images(theme: str) -> dict[str, str]:
    """Write small SVGs (arrows, check mark) used by the stylesheet; returns QSS-ready paths."""
    c = colors(theme)
    folder = user_data_dir() / "theme"
    folder.mkdir(parents=True, exist_ok=True)
    specs = {"down": ("m6 9 6 6 6-6", c["muted"], 2.2), "up": ("m18 15-6-6-6 6", c["muted"], 2.2),
             "check": ("M20 6 9 17l-5-5", "#FFFFFF", 3)}
    paths = {}
    for name, (d, color, width) in specs.items():
        file = Path(folder) / f"{theme}-{name}.svg"
        content = _SVG.format(color=color, width=width, path=d)
        try:
            if not file.exists() or file.read_text(encoding="utf-8") != content:
                file.write_text(content, encoding="utf-8")
        except OSError:
            pass
        paths[name] = file.as_posix()
    return paths


def stylesheet(theme: str) -> str:
    c = colors(theme)
    img = _theme_images(theme)
    return f"""
* {{ font-family: "Segoe UI Variable Text", "Segoe UI", "Noto Sans", sans-serif; font-size: 10pt; }}
QMainWindow, QDialog {{ background: {c['bg']}; }}
QWidget {{ color: {c['text']}; }}
QWidget#page, QScrollArea#pageScroll, QScrollArea#pageScroll > QWidget > QWidget {{ background: {c['bg']}; }}
QToolTip {{ background: {c['surface2']}; color: {c['text']}; border: 1px solid {c['border']}; padding: 6px; border-radius: 6px; }}

/* Header */
QFrame#header {{ background: {c['surface']}; border-bottom: 1px solid {c['border']}; }}
QLabel#appTitle {{ font-size: 15pt; font-weight: 700; letter-spacing: 0.5px; }}
QLabel#appSubtitle {{ color: {c['muted']}; }}
QPushButton#depBadge {{ border-radius: 13px; padding: 4px 12px; font-weight: 600; background: {c['surface2']}; border: 1px solid {c['border']}; }}
QPushButton#depBadge[ok="true"] {{ color: {c['success']}; }}
QPushButton#depBadge[ok="false"] {{ color: {c['warning']}; }}

/* Main tabs */
QTabWidget#mainTabs::pane {{ border: none; background: {c['bg']}; }}
QTabWidget#mainTabs > QTabBar {{ qproperty-drawBase: 0; }}
QTabWidget#mainTabs > QTabBar::tab {{ background: transparent; color: {c['muted']}; padding: 10px 18px; margin: 8px 4px 6px 4px;
    border-radius: 10px; font-weight: 600; }}
QTabWidget#mainTabs > QTabBar::tab:hover {{ background: {c['surface2']}; color: {c['text']}; }}
QTabWidget#mainTabs > QTabBar::tab:selected {{ background: {c['accent_soft']}; color: {c['accent']}; }}

/* Secondary tabs */
QTabWidget#subTabs::pane {{ border: 1px solid {c['border']}; border-radius: 12px; background: {c['surface']}; top: -1px; }}
QTabWidget#subTabs > QTabBar::tab {{ background: transparent; color: {c['muted']}; padding: 8px 16px; border: none;
    border-bottom: 2px solid transparent; font-weight: 600; }}
QTabWidget#subTabs > QTabBar::tab:selected {{ color: {c['accent']}; border-bottom: 2px solid {c['accent']}; }}
QTabWidget#subTabs > QTabBar::tab:hover {{ color: {c['text']}; }}

/* Cards */
QFrame#card {{ background: {c['surface']}; border: 1px solid {c['border']}; border-radius: 14px; }}
QFrame#card QLabel, QFrame#jobCard QLabel {{ background: transparent; }}
QLabel[role="heading"] {{ font-size: 12pt; font-weight: 700; }}
QLabel[role="title"] {{ font-size: 13pt; font-weight: 700; }}
QLabel[role="muted"] {{ color: {c['muted']}; }}
QLabel[role="small"] {{ color: {c['muted']}; font-size: 9pt; }}
QLabel[role="field"] {{ color: {c['muted']}; font-weight: 600; }}
QLabel[role="error"] {{ color: {c['danger']}; }}
QLabel[role="success"] {{ color: {c['success']}; }}
QFrame#card QLabel#thumbnail {{ background: {c['surface2']}; border-radius: 10px; color: {c['muted']}; }}

QFrame#dropArea {{ background: {c['surface']}; border: 2px dashed {c['border_strong']}; border-radius: 16px; }}
QFrame#dropArea[hover="true"] {{ border-color: {c['accent']}; background: {c['accent_soft']}; }}

QFrame#jobCard {{ background: {c['surface2']}; border: 1px solid {c['border']}; border-radius: 12px; }}
QFrame#jobCard[status="Failed"] {{ border-color: {c['danger']}; }}
QFrame#jobCard[status="Completed"] {{ border-color: {c['border']}; }}
QLabel[status="Failed"] {{ color: {c['danger']}; }}
QLabel[status="Completed"] {{ color: {c['success']}; }}
QLabel[status="Cancelled"] {{ color: {c['warning']}; }}
QLabel[status="Running"] {{ color: {c['accent']}; }}

/* Inputs */
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit {{ background: {c['input']}; border: 1px solid {c['border']}; border-radius: 8px;
    padding: 7px 10px; selection-background-color: {c['selection']}; min-height: 20px; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus {{ border: 1px solid {c['accent']}; }}
QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled {{ color: {c['muted']}; background: {c['surface2']}; }}
QLineEdit[invalid="true"] {{ border: 1px solid {c['danger']}; }}
QComboBox::drop-down {{ border: none; width: 28px; subcontrol-origin: padding; subcontrol-position: center right; }}
QComboBox::down-arrow {{ image: url("{img['down']}"); width: 14px; height: 14px; }}
QSpinBox {{ padding-right: 26px; }}
QSpinBox::up-button, QSpinBox::down-button {{ subcontrol-origin: border; width: 24px; border: none; background: transparent; }}
QSpinBox::up-button {{ subcontrol-position: top right; margin-top: 3px; }}
QSpinBox::down-button {{ subcontrol-position: bottom right; margin-bottom: 3px; }}
QSpinBox::up-arrow {{ image: url("{img['up']}"); width: 12px; height: 12px; }}
QSpinBox::down-arrow {{ image: url("{img['down']}"); width: 12px; height: 12px; }}
QSpinBox::up-button:hover, QSpinBox::down-button:hover {{ background: {c['surface2']}; border-radius: 4px; }}
QComboBox QAbstractItemView {{ background: {c['surface']}; border: 1px solid {c['border']}; border-radius: 8px; padding: 4px;
    selection-background-color: {c['accent_soft']}; selection-color: {c['text']}; outline: none; }}
QCheckBox {{ spacing: 9px; background: transparent; }}
QCheckBox::indicator {{ width: 18px; height: 18px; border: 1px solid {c['border_strong']}; border-radius: 5px; background: {c['input']}; }}
QCheckBox::indicator:hover {{ border-color: {c['accent']}; }}
QCheckBox::indicator:checked {{ background: {c['accent']}; border-color: {c['accent']}; image: url("{img['check']}"); }}

/* Buttons */
QPushButton {{ background: {c['surface2']}; border: 1px solid {c['border']}; border-radius: 9px; padding: 8px 16px; font-weight: 600; }}
QPushButton:hover {{ border-color: {c['border_strong']}; background: {c['border']}; }}
QPushButton:pressed {{ background: {c['border_strong']}; }}
QPushButton:disabled {{ color: {c['muted']}; background: {c['surface2']}; border-color: {c['border']}; }}
QPushButton[variant="accent"] {{ background: {c['accent']}; color: white; border: 1px solid {c['accent']}; }}
QPushButton[variant="accent"]:hover {{ background: {c['accent_hover']}; }}
QPushButton[variant="accent"]:pressed {{ background: {c['accent_pressed']}; }}
QPushButton[variant="accent"]:disabled {{ background: {c['border_strong']}; border-color: {c['border_strong']}; color: {c['muted']}; }}
QPushButton[variant="large"] {{ padding: 11px 22px; font-size: 11pt; }}
QPushButton[variant="ghost"] {{ background: transparent; border: 1px solid transparent; padding: 6px 10px; }}
QPushButton[variant="ghost"]:hover {{ background: {c['border']}; }}
QPushButton[variant="danger"]:hover {{ color: {c['danger']}; border-color: {c['danger']}; }}

/* Progress */
QProgressBar {{ background: {c['input']}; border: none; border-radius: 4px; height: 8px; max-height: 8px; text-align: center; }}
QProgressBar::chunk {{ background: {c['accent']}; border-radius: 4px; }}
QProgressBar[status="Completed"]::chunk {{ background: {c['success']}; }}
QProgressBar[status="Failed"]::chunk {{ background: {c['danger']}; }}
QProgressBar[status="Cancelled"]::chunk {{ background: {c['warning']}; }}

/* Tables */
QTableWidget {{ background: {c['surface']}; border: none; gridline-color: transparent; alternate-background-color: {c['surface2']};
    selection-background-color: {c['accent_soft']}; selection-color: {c['text']}; border-radius: 10px; }}
QTableWidget::item {{ padding: 6px; }}
QHeaderView::section {{ background: {c['surface']}; color: {c['muted']}; border: none; border-bottom: 1px solid {c['border']};
    padding: 8px 6px; font-weight: 600; }}
QTableCornerButton::section {{ background: {c['surface']}; border: none; }}

/* Scrollbars */
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c['border_strong']}; border-radius: 4px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c['border_strong']}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none; width: 0; height: 0; }}

QStatusBar {{ background: {c['surface']}; color: {c['muted']}; border-top: 1px solid {c['border']}; }}
QMessageBox QLabel {{ background: transparent; }}
QMenu {{ background: {c['surface']}; border: 1px solid {c['border']}; border-radius: 8px; padding: 4px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 6px; }}
QMenu::item:selected {{ background: {c['accent_soft']}; }}
"""


def apply_theme(app: QApplication, theme: str) -> None:
    c = colors(theme)
    app.setStyle("Fusion")
    pal = QPalette()
    role = QPalette.ColorRole
    for r, key in ((role.Window, "bg"), (role.Base, "input"), (role.AlternateBase, "surface2"),
                   (role.Button, "surface2"), (role.Text, "text"), (role.WindowText, "text"),
                   (role.ButtonText, "text"), (role.ToolTipBase, "surface2"), (role.ToolTipText, "text"),
                   (role.Highlight, "accent"), (role.PlaceholderText, "muted"), (role.Mid, "border"),
                   (role.Dark, "border_strong"), (role.Light, "surface")):
        pal.setColor(r, QColor(c[key]))
    pal.setColor(role.HighlightedText, QColor("white"))
    pal.setColor(QPalette.ColorGroup.Disabled, role.Text, QColor(c["muted"]))
    pal.setColor(QPalette.ColorGroup.Disabled, role.ButtonText, QColor(c["muted"]))
    app.setPalette(pal)
    app.setStyleSheet(stylesheet(theme))
