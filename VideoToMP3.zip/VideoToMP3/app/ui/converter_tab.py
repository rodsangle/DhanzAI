"""Tab 2: convert local video files to audio (batch)."""

from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QGridLayout, QHBoxLayout, QHeaderView,
                               QLineEdit, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app.core.ffmpeg import probe
from app.core.jobs import Job, JobKind, JobOptions
from app.core.utils import format_bytes, format_duration, sanitize_filename
from app.core.validators import (VIDEO_EXTENSIONS, ValidationError, collect_video_files, validate_input_file,
                                 validate_output_dir)
from app.ui.bridge import run_async
from app.ui.context import AppContext
from app.ui.dialogs import confirm_overwrites, show_error, show_warning
from app.ui.widgets import (Card, DropArea, FolderPicker, TimeEdit, button, format_combo, label, page_scroll,
                            quality_combo, sync_quality_enabled)

COL_FILE, COL_DURATION, COL_SIZE, COL_AUDIO, COL_NAME = range(5)


class ConverterTab(QWidget):
    def __init__(self, ctx: AppContext):
        super().__init__()
        self.ctx = ctx
        self._files: list[Path] = []

        content = QWidget()
        root = QVBoxLayout(content)
        root.setContentsMargins(24, 16, 24, 24)
        root.setSpacing(16)

        self.drop = DropArea()
        self.drop.files_dropped.connect(self._on_dropped)
        self.drop.browse_requested.connect(self.browse)
        root.addWidget(self.drop)

        # --- File list ---------------------------------------------------------------
        files_card = Card()
        head = QHBoxLayout()
        self.count_lbl = label("Selected files (0)", "heading")
        head.addWidget(self.count_lbl)
        head.addStretch()
        self.remove_btn = button("Remove Selected", "x")
        self.remove_btn.clicked.connect(self.remove_selected)
        self.clear_btn = button("Clear All", "trash")
        self.clear_btn.clicked.connect(self.clear)
        head.addWidget(self.remove_btn)
        head.addWidget(self.clear_btn)
        files_card.body.addLayout(head)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["File", "Duration", "Size", "Audio", "Output name (editable)"])
        self.table.verticalHeader().hide()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked
                                   | QAbstractItemView.EditTrigger.EditKeyPressed
                                   | QAbstractItemView.EditTrigger.SelectedClicked)
        self.table.setMinimumHeight(190)
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(COL_FILE, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(COL_NAME, QHeaderView.ResizeMode.Stretch)
        for col in (COL_DURATION, COL_SIZE, COL_AUDIO):
            hdr.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        self.empty_lbl = label("No files yet. Drop videos above or click Browse Files.", "muted")
        self.empty_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        files_card.body.addWidget(self.table)
        files_card.body.addWidget(self.empty_lbl)
        root.addWidget(files_card)

        # --- Options -----------------------------------------------------------------
        opts = Card("Output settings")
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        s = ctx.settings
        self.format_combo = format_combo(s.default_format)
        self.quality_combo = quality_combo(s.default_quality)
        self.format_combo.currentIndexChanged.connect(self._format_changed)
        self.folder = FolderPicker(s.download_dir)
        ctx.output_dir_changed.connect(self.folder.set_path)
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Blank = use each output name")
        self.artist_edit = QLineEdit()
        self.album_edit = QLineEdit()
        self.start_edit = TimeEdit("Start (e.g. 1:05)")
        self.end_edit = TimeEdit("End (blank = end)")
        self.cover_edit = QLineEdit()
        self.cover_edit.setPlaceholderText("Optional cover image (JPG/PNG) for MP3, M4A, FLAC")
        self.cover_edit.setReadOnly(True)
        cover_btn = button("Choose…", "image")
        cover_btn.clicked.connect(self._choose_cover)
        cover_clear = button("", "x", "ghost", "Remove cover image")
        cover_clear.clicked.connect(self.cover_edit.clear)

        def field(text):
            return label(text, "field")

        grid.addWidget(field("Output format"), 0, 0)
        grid.addWidget(self.format_combo, 0, 1)
        grid.addWidget(field("Audio quality"), 0, 2)
        grid.addWidget(self.quality_combo, 0, 3)
        grid.addWidget(field("Save to"), 1, 0)
        grid.addWidget(self.folder, 1, 1, 1, 3)
        grid.addWidget(field("Title"), 2, 0)
        grid.addWidget(self.title_edit, 2, 1)
        grid.addWidget(field("Artist"), 2, 2)
        grid.addWidget(self.artist_edit, 2, 3)
        grid.addWidget(field("Album"), 3, 0)
        grid.addWidget(self.album_edit, 3, 1)
        trim = QHBoxLayout()
        trim.addWidget(self.start_edit)
        trim.addWidget(label("→", "muted"))
        trim.addWidget(self.end_edit)
        trim.addStretch()
        grid.addWidget(field("Trim (all files)"), 3, 2)
        grid.addLayout(trim, 3, 3)
        cover_row = QHBoxLayout()
        cover_row.addWidget(self.cover_edit, 1)
        cover_row.addWidget(cover_btn)
        cover_row.addWidget(cover_clear)
        grid.addWidget(field("Cover art"), 4, 0)
        grid.addLayout(cover_row, 4, 1, 1, 3)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        opts.body.addLayout(grid)

        bottom = QHBoxLayout()
        bottom.addWidget(label("Only the audio stream is processed — video is never re-encoded.", "small"))
        bottom.addStretch()
        self.convert_btn = button("Convert", "convert", "accent")
        self.convert_btn.setStyleSheet("padding: 11px 26px; font-size: 11pt;")
        self.convert_btn.clicked.connect(self.convert)
        bottom.addWidget(self.convert_btn)
        opts.body.addLayout(bottom)
        root.addWidget(opts)
        root.addStretch()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(page_scroll(content))
        self._format_changed()
        self._refresh()

    # ---------------------------------------------------------------- file list
    def browse(self) -> None:
        exts = " ".join(f"*{e}" for e in VIDEO_EXTENSIONS)
        start = self.ctx.settings.last_input_dir or str(Path.home())
        paths, _ = QFileDialog.getOpenFileNames(self, "Select video files", start,
                                                f"Video files ({exts});;All files (*.*)")
        if paths:
            self.ctx.settings.last_input_dir = os.path.dirname(paths[0])
            self.ctx.settings.save()
            files, rejected = collect_video_files(paths)
            self.add_files([str(f) for f in files], rejected)

    def _on_dropped(self, files: list, rejected: list) -> None:
        self.add_files(files, rejected)

    def add_files(self, paths: list[str], rejected: list[str] | None = None) -> None:
        rejected = list(rejected or [])
        known = {p.resolve() for p in self._files}
        for raw in paths:
            try:
                path = validate_input_file(raw)
            except ValidationError as exc:
                rejected.append(f"{Path(raw).name} — {exc}")
                continue
            if path.resolve() in known:
                continue
            known.add(path.resolve())
            self._files.append(path)
            self._add_row(path)
        if rejected:
            show_warning(self, "Some files were skipped",
                         "These items are not supported video files and were skipped:\n\n"
                         + "\n".join(f"• {r}" for r in rejected[:12]))
        self._refresh()

    def _add_row(self, path: Path) -> None:
        row = self.table.rowCount()
        self.table.insertRow(row)
        item = QTableWidgetItem(path.name)
        item.setToolTip(str(path))
        item.setData(Qt.ItemDataRole.UserRole, str(path))
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.table.setItem(row, COL_FILE, item)
        for col, text in ((COL_DURATION, "…"), (COL_SIZE, format_bytes(path.stat().st_size)), (COL_AUDIO, "…")):
            cell = QTableWidgetItem(text)
            cell.setFlags(cell.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.table.setItem(row, col, cell)
        self.table.setItem(row, COL_NAME, QTableWidgetItem(sanitize_filename(path.stem)))

        ffmpeg, ffprobe = self.ctx.deps.ffmpeg_path, self.ctx.deps.ffprobe_path
        if ffmpeg:
            run_async(lambda: probe(path, ffmpeg, ffprobe),
                      lambda info: self._probed(str(path), info),
                      lambda _exc: self._probed(str(path), None))
        else:
            self._set_cell(str(path), COL_DURATION, "?")
            self._set_cell(str(path), COL_AUDIO, "FFmpeg missing")

    def _row_of(self, path: str) -> int:
        for row in range(self.table.rowCount()):
            if self.table.item(row, COL_FILE).data(Qt.ItemDataRole.UserRole) == path:
                return row
        return -1

    def _set_cell(self, path: str, col: int, text: str) -> None:
        row = self._row_of(path)
        if row >= 0:
            self.table.item(row, col).setText(text)

    def _probed(self, path: str, info) -> None:
        if info is None:
            self._set_cell(path, COL_DURATION, "?")
            self._set_cell(path, COL_AUDIO, "Unreadable")
            return
        self._set_cell(path, COL_DURATION, format_duration(info.duration))
        if info.has_audio:
            kbps = f" {info.audio_bitrate // 1000}k" if info.audio_bitrate else ""
            self._set_cell(path, COL_AUDIO, f"{(info.audio_codec or '?').upper()}{kbps}")
        else:
            self._set_cell(path, COL_AUDIO, "No audio!")

    def remove_selected(self) -> None:
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for row in rows:
            path = self.table.item(row, COL_FILE).data(Qt.ItemDataRole.UserRole)
            self._files = [p for p in self._files if str(p) != path]
            self.table.removeRow(row)
        self._refresh()

    def clear(self) -> None:
        self._files.clear()
        self.table.setRowCount(0)
        self._refresh()

    def _refresh(self) -> None:
        n = len(self._files)
        self.count_lbl.setText(f"Selected files ({n})")
        self.table.setVisible(n > 0)
        self.empty_lbl.setVisible(n == 0)
        self.remove_btn.setEnabled(n > 0)
        self.clear_btn.setEnabled(n > 0)
        self.convert_btn.setEnabled(n > 0)
        fmt = self.format_combo.currentData().upper()
        self.convert_btn.setText(f"Convert {n} file{'s' if n != 1 else ''} to {fmt}" if n else "Convert")

    def _format_changed(self) -> None:
        sync_quality_enabled(self.format_combo, self.quality_combo)
        if hasattr(self, "convert_btn"):
            self._refresh()

    def _choose_cover(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose cover image", self.ctx.settings.last_input_dir,
                                              "Images (*.jpg *.jpeg *.png *.webp *.bmp)")
        if path:
            self.cover_edit.setText(os.path.normpath(path))

    # ---------------------------------------------------------------- convert
    def convert(self) -> None:
        if not self._files:
            return
        if not self.ctx.deps.ffmpeg.found:
            show_error(self, "FFmpeg required",
                       "FFmpeg was not found, so files cannot be converted.\n\n"
                       "Install FFmpeg (see README / Settings tab) or set its location in Settings, "
                       "then try again.")
            return
        try:
            out_dir = str(validate_output_dir(self.folder.path()))
            start, end = self.start_edit.seconds(), self.end_edit.seconds()
        except (ValidationError, ValueError) as exc:
            show_error(self, "Check your settings", str(exc))
            return
        if start is not None and end is not None and end <= start:
            show_error(self, "Invalid trim", "The end time must be later than the start time.")
            return
        cover = self.cover_edit.text().strip() or None
        if cover and not Path(cover).is_file():
            show_error(self, "Cover image missing", f"The cover image no longer exists:\n{cover}")
            return

        jobs: list[Job] = []
        for row in range(self.table.rowCount()):
            src = self.table.item(row, COL_FILE).data(Qt.ItemDataRole.UserRole)
            name = sanitize_filename(self.table.item(row, COL_NAME).text().strip() or Path(src).stem)
            opts = JobOptions(
                output_dir=out_dir, output_name=name, fmt=self.format_combo.currentData(),
                quality=self.quality_combo.currentData(), start=start, end=end,
                title=self.title_edit.text().strip() or name,
                artist=self.artist_edit.text().strip() or None,
                album=self.album_edit.text().strip() or None,
                cover_path=cover,
            )
            jobs.append(Job(JobKind.CONVERT, src, Path(src).name, opts))
        if not confirm_overwrites(self, jobs, self.ctx.manager):
            return
        self.ctx.remember_output_dir(out_dir)
        for job in jobs:
            self.ctx.manager.add(job)
        self.window().statusBar().showMessage(f"Queued {len(jobs)} conversion(s)", 5000)
        self.clear()
        self.ctx.show_tab.emit(2)
