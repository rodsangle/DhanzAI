"""Main application window: header, four tabs, tray notifications and shutdown handling."""

from __future__ import annotations

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPushButton,
                               QSystemTrayIcon, QTabWidget, QVBoxLayout, QWidget)

from app import APP_DISPLAY_NAME, APP_TITLE
from app.core.jobs import Job, JobKind, JobStatus
from app.ui import icons, theme
from app.ui.context import AppContext
from app.ui.converter_tab import ConverterTab
from app.ui.manager_tab import ManagerTab
from app.ui.settings_tab import SettingsTab
from app.ui.url_tab import UrlTab
from app.ui.widgets import repolish


class MainWindow(QMainWindow):
    def __init__(self, ctx: AppContext):
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle(APP_DISPLAY_NAME)
        self.setWindowIcon(icons.app_icon())
        self.setMinimumSize(900, 640)
        self.resize(1180, 860)

        central = QWidget()
        lay = QVBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self._build_header())

        self.tabs = QTabWidget()
        self.tabs.setObjectName("mainTabs")
        self.tabs.setDocumentMode(True)
        self.url_tab = UrlTab(ctx)
        self.converter_tab = ConverterTab(ctx)
        self.manager_tab = ManagerTab(ctx)
        self.settings_tab = SettingsTab(ctx, self.apply_theme)
        for widget, text, icon_name in ((self.url_tab, "URL Downloader", "link"),
                                        (self.converter_tab, "Video Converter", "convert"),
                                        (self.manager_tab, "Download Manager", "list"),
                                        (self.settings_tab, "Settings", "settings")):
            self.tabs.addTab(widget, icons.icon(icon_name, "#8C95AB"), text)
        self.tabs.tabBar().setCursor(Qt.CursorShape.PointingHandCursor)
        lay.addWidget(self.tabs, 1)
        self.setCentralWidget(central)
        self.statusBar().showMessage("Ready")

        ctx.show_tab.connect(self.tabs.setCurrentIndex)
        ctx.deps_changed.connect(self._update_dep_badge)
        ctx.bridge.job_changed.connect(self._on_job_changed)
        self._notified: set[tuple[int, int]] = set()
        self._setup_tray()
        self._update_dep_badge()
        if ctx.settings.window_geometry:
            self.restoreGeometry(QByteArray.fromBase64(ctx.settings.window_geometry.encode()))

    # ---------------------------------------------------------------- header
    def _build_header(self) -> QWidget:
        header = QFrame()
        header.setObjectName("header")
        row = QHBoxLayout(header)
        row.setContentsMargins(24, 14, 24, 14)
        row.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(icons.app_icon().pixmap(44, 44))
        row.addWidget(logo)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        title = QLabel(APP_TITLE)
        title.setObjectName("appTitle")
        subtitle = QLabel("Convert videos to high-quality audio and download permitted online media")
        subtitle.setObjectName("appSubtitle")
        titles.addWidget(title)
        titles.addWidget(subtitle)
        row.addLayout(titles, 1)
        self.dep_badge = QPushButton()
        self.dep_badge.setObjectName("depBadge")
        self.dep_badge.setCursor(Qt.CursorShape.PointingHandCursor)
        self.dep_badge.clicked.connect(lambda: self.tabs.setCurrentWidget(self.settings_tab))
        row.addWidget(self.dep_badge)
        return header

    def _update_dep_badge(self) -> None:
        d = self.ctx.deps
        ok = d.ffmpeg.found and d.ytdlp.found
        if ok:
            text, tip = "●  FFmpeg && yt-dlp ready", f"FFmpeg {d.ffmpeg.version} · yt-dlp {d.ytdlp.version}"
        else:
            missing = [s.name for s in (d.ffmpeg, d.ytdlp) if not s.found]
            text, tip = f"●  {' && '.join(missing)} missing", "Click to open Settings for details"
        self.dep_badge.setText(text)
        self.dep_badge.setToolTip(tip)
        self.dep_badge.setProperty("ok", ok)
        repolish(self.dep_badge)
        if not d.ffmpeg.found:
            self.statusBar().showMessage("FFmpeg was not found — conversions are disabled until it is installed. "
                                         "See Settings.")

    # ---------------------------------------------------------------- theme
    def apply_theme(self, name: str) -> None:
        app = QApplication.instance()
        theme.apply_theme(app, name)
        icons.set_theme_color(theme.colors(name)["text"])

    # ---------------------------------------------------------------- notifications
    def _setup_tray(self) -> None:
        self.tray = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray = QSystemTrayIcon(icons.app_icon(), self)
            self.tray.setToolTip(APP_DISPLAY_NAME)
            self.tray.activated.connect(lambda *_: (self.showNormal(), self.activateWindow()))
            self.tray.messageClicked.connect(lambda: (self.showNormal(), self.activateWindow(),
                                                      self.tabs.setCurrentWidget(self.manager_tab)))
            self.tray.show()

    def _on_job_changed(self, job: Job) -> None:
        running = sum(1 for j in self.ctx.manager.jobs if j.status == JobStatus.RUNNING)
        queued = sum(1 for j in self.ctx.manager.jobs if j.status == JobStatus.QUEUED)
        self.tabs.setTabText(2, f"Download Manager ({running + queued})" if running + queued else "Download Manager")
        if not job.status.finished or job.status == JobStatus.CANCELLED:
            return
        key = (job.id, job.attempts)
        if key in self._notified:
            return
        self._notified.add(key)
        verb = "Download" if job.kind == JobKind.DOWNLOAD else "Conversion"
        if job.status == JobStatus.COMPLETED:
            title, msg, kind = f"{verb} complete", job.output_path, QSystemTrayIcon.MessageIcon.Information
        else:
            title, msg, kind = f"{verb} failed", f"{job.display_name}\n{job.error}", QSystemTrayIcon.MessageIcon.Warning
        self.statusBar().showMessage(f"{title}: {job.display_name}", 8000)
        if self.ctx.settings.notifications and self.tray is not None:
            self.tray.showMessage(title, msg, kind, 6000)

    # ---------------------------------------------------------------- shutdown
    def closeEvent(self, event):  # noqa: N802
        active = self.ctx.manager.active_count()
        if active:
            answer = QMessageBox.question(
                self, "Tasks in progress",
                f"{active} download/conversion task(s) are still running or queued.\n\n"
                "Cancel them and exit?")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        self.ctx.settings.window_geometry = bytes(self.saveGeometry().toBase64()).decode()
        self.ctx.settings.save()
        self.ctx.manager.shutdown(timeout=5)
        if self.tray is not None:
            self.tray.hide()
        event.accept()
