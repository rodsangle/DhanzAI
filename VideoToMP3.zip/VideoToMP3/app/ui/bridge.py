"""Thread-safe glue between background work and the Qt main thread."""

from __future__ import annotations

import logging
from typing import Any, Callable

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

from app.core.jobs import Job, JobManager

log = logging.getLogger(__name__)


class JobBridge(QObject):
    """Re-emits JobManager callbacks (from worker threads) as a Qt signal on the GUI thread."""

    job_changed = Signal(object)
    _from_worker = Signal(object)

    def __init__(self, manager: JobManager, parent: QObject | None = None):
        super().__init__(parent)
        # Receiver lives in the GUI thread -> AutoConnection becomes a queued connection.
        self._from_worker.connect(self._deliver)
        manager.add_listener(self._from_worker.emit)

    @Slot(object)
    def _deliver(self, job: Job) -> None:
        self.job_changed.emit(job)


class _Relay(QObject):
    finished = Signal(bool, object)

    def __init__(self, on_done: Callable[[Any], None] | None, on_error: Callable[[Exception], None] | None):
        super().__init__()
        self._on_done, self._on_error = on_done, on_error
        self.finished.connect(self._deliver)

    @Slot(bool, object)
    def _deliver(self, ok: bool, value: Any) -> None:
        _active.discard(self)
        try:
            if ok and self._on_done:
                self._on_done(value)
            elif not ok and self._on_error:
                self._on_error(value)
        except RuntimeError:  # target widget was deleted meanwhile
            pass


class _Task(QRunnable):
    def __init__(self, fn: Callable[[], Any], relay: _Relay):
        super().__init__()
        self.fn, self.relay = fn, relay

    def run(self) -> None:
        try:
            result = self.fn()
        except Exception as exc:  # noqa: BLE001
            log.debug("Background task failed: %s", exc)
            self.relay.finished.emit(False, exc)
        else:
            self.relay.finished.emit(True, result)


_active: set[_Relay] = set()


def run_async(fn: Callable[[], Any], on_done: Callable[[Any], None] | None = None,
              on_error: Callable[[Exception], None] | None = None) -> None:
    """Run ``fn`` on the global thread pool; callbacks run on the GUI thread. Must be called from the GUI thread."""
    relay = _Relay(on_done, on_error)
    _active.add(relay)
    QThreadPool.globalInstance().start(_Task(fn, relay))
