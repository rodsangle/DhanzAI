"""Tab 3: download / conversion queue, completed items and persistent history."""

from __future__ import annotations

import datetime as dt
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QHBoxLayout, QHeaderView, QMessageBox, QScrollArea,
                               QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from app.core.jobs import Job, JobStatus
from app.core.utils import format_bytes
from app.ui.context import AppContext
from app.ui.widgets import JobCard, button, label, open_folder


class _JobList(QScrollArea):
    """Scrollable vertical list of JobCards with an empty-state message."""

    def __init__(self, empty_text: str):
        super().__init__()
        self.setWidgetResizable(True)
        inner = QWidget()
        inner.setStyleSheet("background: transparent;")
        self.lay = QVBoxLayout(inner)
        self.lay.setContentsMargins(12, 12, 12, 12)
        self.lay.setSpacing(10)
        self.empty = label(empty_text, "muted")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setMinimumHeight(120)
        self.lay.addWidget(self.empty)
        self.lay.addStretch()
        self.setWidget(inner)
        self.viewport().setStyleSheet("background: transparent;")
        self.cards: dict[int, JobCard] = {}

    def add(self, card: JobCard) -> None:
        self.cards[card.job_id] = card
        self.lay.insertWidget(self.lay.count() - 1, card)
        self.empty.hide()

    def take(self, job_id: int) -> JobCard | None:
        card = self.cards.pop(job_id, None)
        if card is not None:
            self.lay.removeWidget(card)
        self.empty.setVisible(not self.cards)
        return card


class ManagerTab(QWidget):
    def __init__(self, ctx: AppContext):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 16, 24, 24)
        root.setSpacing(14)

        bar = QHBoxLayout()
        self.summary = label("No active tasks", "muted")
        bar.addWidget(self.summary)
        bar.addStretch()
        self.retry_all_btn = button("Retry Failed", "retry")
        self.retry_all_btn.clicked.connect(self.retry_failed)
        self.cancel_all_btn = button("Cancel All", "stop", "danger")
        self.cancel_all_btn.clicked.connect(self.cancel_all)
        self.clear_btn = button("Clear Finished", "trash")
        self.clear_btn.clicked.connect(self.clear_finished)
        self.open_btn = button("Open Download Folder", "folder", "accent")
        self.open_btn.clicked.connect(lambda: open_folder(self.ctx.settings.download_dir))
        for b in (self.retry_all_btn, self.cancel_all_btn, self.clear_btn, self.open_btn):
            bar.addWidget(b)
        root.addLayout(bar)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("subTabs")
        self.tabs.setDocumentMode(False)
        self.active = _JobList("Nothing in the queue. Downloads and conversions you start appear here.")
        self.completed = _JobList("Completed downloads from this session appear here.")
        self.tabs.addTab(self.active, "Active && Queued")
        self.tabs.addTab(self.completed, "Completed")
        self.tabs.addTab(self._build_history(), "History")
        root.addWidget(self.tabs, 1)

        ctx.bridge.job_changed.connect(self.on_job_changed)
        self._update_summary()

    # ---------------------------------------------------------------- history
    def _build_history(self) -> QWidget:
        page = QWidget()
        page.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(12, 12, 12, 12)
        row = QHBoxLayout()
        row.addWidget(label("Log of all finished downloads and conversions. Double-click to open the file's folder.",
                            "small"))
        row.addStretch()
        refresh = button("Refresh", "retry")
        refresh.clicked.connect(self.load_history)
        clear = button("Clear History", "trash", "danger")
        clear.clicked.connect(self.clear_history)
        row.addWidget(refresh)
        row.addWidget(clear)
        lay.addLayout(row)
        self.history = QTableWidget(0, 6)
        self.history.setHorizontalHeaderLabels(["Date", "Title", "Type", "Format", "Status", "Output / Error"])
        self.history.verticalHeader().hide()
        self.history.setAlternatingRowColors(True)
        self.history.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        hdr = self.history.horizontalHeader()
        for col in (0, 2, 3, 4):
            hdr.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.history.cellDoubleClicked.connect(self._history_open)
        lay.addWidget(self.history)
        self.load_history()
        return page

    def load_history(self) -> None:
        entries = self.ctx.history.entries()
        self.history.setRowCount(len(entries))
        for row, e in enumerate(entries):
            when = dt.datetime.fromtimestamp(e.finished_at).strftime("%Y-%m-%d %H:%M")
            detail = e.output_path or e.error or ""
            if e.size:
                detail = f"{detail}  ({format_bytes(e.size)})"
            values = [when, e.title, "Download" if e.kind == "download" else "Conversion",
                      e.format or "", e.status, detail]
            for col, text in enumerate(values):
                item = QTableWidgetItem(text)
                item.setToolTip(e.source if col == 1 else text)
                if col == 4:
                    item.setData(Qt.ItemDataRole.UserRole, e.output_path)
                self.history.setItem(row, col, item)

    def _history_open(self, row: int, _col: int) -> None:
        path = self.history.item(row, 4).data(Qt.ItemDataRole.UserRole)
        if path:
            open_folder(Path(path).parent, path)

    def clear_history(self) -> None:
        if QMessageBox.question(self, "Clear history", "Delete the entire download and conversion history?\n"
                                "(Your audio/video files are not deleted.)") == QMessageBox.StandardButton.Yes:
            self.ctx.history.clear()
            self.load_history()

    # ---------------------------------------------------------------- jobs
    def _card_for(self, job: Job) -> JobCard:
        card = self.active.cards.get(job.id) or self.completed.cards.get(job.id)
        if card is None:
            card = JobCard(job)
            card.cancel_requested.connect(self.ctx.manager.cancel)
            card.retry_requested.connect(self.ctx.manager.retry)
            card.remove_requested.connect(self.remove_job)
            self.active.add(card)
        return card

    def on_job_changed(self, job: Job) -> None:
        if self.ctx.manager.get(job.id) is None:
            return
        card = self._card_for(job)
        card.update_job(job)
        in_completed = job.id in self.completed.cards
        if job.status == JobStatus.COMPLETED and not in_completed:
            self.active.take(job.id)
            self.completed.add(card)
        elif job.status != JobStatus.COMPLETED and in_completed:
            self.completed.take(job.id)
            self.active.add(card)
        if job.status.finished:
            self.load_history()
        self._update_summary()

    def remove_job(self, job_id: int) -> None:
        self.ctx.manager.remove(job_id)
        for lst in (self.active, self.completed):
            card = lst.take(job_id)
            if card is not None:
                card.deleteLater()
        self._update_summary()

    def clear_finished(self) -> None:
        for job in self.ctx.manager.jobs:
            if job.status.finished:
                self.remove_job(job.id)

    def retry_failed(self) -> None:
        for job in self.ctx.manager.jobs:
            if job.status in (JobStatus.FAILED, JobStatus.CANCELLED):
                self.ctx.manager.retry(job.id)

    def cancel_all(self) -> None:
        if self.ctx.manager.active_count() and QMessageBox.question(
                self, "Cancel all", "Cancel all running and queued tasks?") == QMessageBox.StandardButton.Yes:
            self.ctx.manager.cancel_all()

    def _update_summary(self) -> None:
        jobs = self.ctx.manager.jobs
        running = sum(j.status == JobStatus.RUNNING for j in jobs)
        queued = sum(j.status == JobStatus.QUEUED for j in jobs)
        failed = sum(j.status == JobStatus.FAILED for j in jobs)
        done = sum(j.status == JobStatus.COMPLETED for j in jobs)
        parts = []
        if running:
            parts.append(f"{running} running")
        if queued:
            parts.append(f"{queued} queued")
        if failed:
            parts.append(f"{failed} failed")
        if done:
            parts.append(f"{done} completed")
        self.summary.setText(" · ".join(parts) if parts else "No active tasks")
        self.tabs.setTabText(0, f"Active && Queued ({len(self.active.cards)})")
        self.tabs.setTabText(1, f"Completed ({len(self.completed.cards)})")
        self.retry_all_btn.setEnabled(any(j.status in (JobStatus.FAILED, JobStatus.CANCELLED) for j in jobs))
        self.cancel_all_btn.setEnabled(running + queued > 0)
        self.clear_btn.setEnabled(any(j.status.finished for j in jobs))
