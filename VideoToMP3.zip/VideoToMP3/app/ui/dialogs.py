"""Dialogs: overwrite confirmation and error display."""

from __future__ import annotations

from PySide6.QtWidgets import QMessageBox, QWidget

from app.core.jobs import Job, JobManager


def confirm_overwrites(parent: QWidget, jobs: list[Job], manager: JobManager) -> bool:
    """Ask before overwriting existing files. Returns False if the user cancelled.

    "Overwrite" marks the first job per existing target as allowed to overwrite;
    "Keep both" leaves overwrite off so the file is saved as "name (1).ext".
    """
    busy = {j.target_path for j in manager.jobs if not j.status.finished}
    seen: set = set()
    conflicts: list[Job] = []
    for job in jobs:
        target = job.target_path
        if target.exists() or target in busy or target in seen:
            conflicts.append(job)
        seen.add(target)
    if not conflicts:
        return True

    names = "\n".join(f"  • {j.target_path.name}" for j in conflicts[:8])
    if len(conflicts) > 8:
        names += f"\n  … and {len(conflicts) - 8} more"
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("File already exists")
    box.setText(f"{len(conflicts)} output file(s) already exist or would be created twice:")
    box.setInformativeText(names + "\n\nWhat would you like to do?")
    overwrite = box.addButton("Overwrite", QMessageBox.ButtonRole.DestructiveRole)
    keep = box.addButton("Keep Both (auto-rename)", QMessageBox.ButtonRole.AcceptRole)
    box.addButton(QMessageBox.StandardButton.Cancel)
    box.setDefaultButton(keep)
    box.exec()
    clicked = box.clickedButton()
    if clicked is overwrite:
        claimed: set = set(busy)
        for job in jobs:
            target = job.target_path
            job.options.overwrite = target.exists() and target not in claimed
            claimed.add(target)
        return True
    if clicked is keep:
        for job in jobs:
            job.options.overwrite = False
        return True
    return False


def show_error(parent: QWidget, title: str, message: str) -> None:
    QMessageBox.critical(parent, title, message)


def show_warning(parent: QWidget, title: str, message: str) -> None:
    QMessageBox.warning(parent, title, message)
