"""Tab 1: analyse a video URL and queue an audio (MP3 etc.) or MP4 download."""

from __future__ import annotations

import urllib.request

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QVBoxLayout, QWidget)

from app.core import downloader
from app.core.ffmpeg import AUDIO_FORMATS
from app.core.jobs import Job, JobKind, JobOptions
from app.core.utils import format_bytes, format_duration, sanitize_filename
from app.core.validators import ValidationError, validate_output_dir, validate_url
from app.ui import icons
from app.ui.bridge import run_async
from app.ui.context import AppContext
from app.ui.dialogs import confirm_overwrites, show_error
from app.ui.widgets import (Card, FolderPicker, TimeEdit, button, format_combo, label, page_scroll,
                            quality_combo, sync_quality_enabled)

THUMB_W, THUMB_H = 320, 180


def _fetch_thumbnail(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:  # noqa: S310 - http(s) URL from yt-dlp
        return resp.read(5_000_000)


class UrlTab(QWidget):
    def __init__(self, ctx: AppContext):
        super().__init__()
        self.ctx = ctx
        self.info: downloader.VideoInfo | None = None
        self._analyzed_url = ""
        self._analysis_seq = 0

        content = QWidget()
        root = QVBoxLayout(content)
        root.setContentsMargins(24, 16, 24, 24)
        root.setSpacing(16)

        # --- URL input ---------------------------------------------------------------
        card = Card("Paste a video link",
                    "Works with YouTube, Vimeo, Facebook, Instagram, TikTok and many other sites supported by "
                    "yt-dlp. Only publicly accessible media you are allowed to download — content that needs "
                    "a login, is private/paid, or is DRM-protected is not supported.")
        row = QHBoxLayout()
        row.setSpacing(8)
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("https://www.youtube.com/watch?v=…")
        self.url_edit.setClearButtonEnabled(True)
        self.url_edit.addAction(icons.icon("link", "#8C95AB"), QLineEdit.ActionPosition.LeadingPosition)
        self.url_edit.returnPressed.connect(self.analyze)
        self.url_edit.textChanged.connect(self._url_changed)
        self.paste_btn = button("Paste", "clipboard", tooltip="Paste URL from clipboard")
        self.paste_btn.clicked.connect(self.paste)
        self.analyze_btn = button("Analyze URL", "search", "accent")
        self.analyze_btn.clicked.connect(self.analyze)
        row.addWidget(self.url_edit, 1)
        row.addWidget(self.paste_btn)
        row.addWidget(self.analyze_btn)
        card.body.addLayout(row)
        self.message = label("", "muted", wrap=True)
        self.message.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.message.hide()
        card.body.addWidget(self.message)
        root.addWidget(card)

        # --- Video info --------------------------------------------------------------
        self.info_card = Card()
        info_row = QHBoxLayout()
        info_row.setSpacing(18)
        self.thumb = QLabel("No preview")
        self.thumb.setObjectName("thumbnail")
        self.thumb.setFixedSize(THUMB_W, THUMB_H)
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_row.addWidget(self.thumb, 0, Qt.AlignmentFlag.AlignTop)
        meta = QVBoxLayout()
        meta.setSpacing(6)
        self.title_lbl = label("", "title", wrap=True)
        self.title_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.meta_lbl = label("", "muted", wrap=True)
        self.formats_lbl = label("", "small", wrap=True)
        meta.addWidget(self.title_lbl)
        meta.addWidget(self.meta_lbl)
        meta.addWidget(self.formats_lbl)
        meta.addStretch()
        info_row.addLayout(meta, 1)
        self.info_card.body.addLayout(info_row)
        self.info_card.hide()
        root.addWidget(self.info_card)

        # --- Output options ----------------------------------------------------------
        self.options_card = Card("Output")
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        s = ctx.settings
        self.format_combo = format_combo(s.default_format)
        self.quality_combo = quality_combo(s.default_quality)
        self.format_combo.currentIndexChanged.connect(self._format_changed)
        self.res_combo = QComboBox()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("File name (without extension)")
        self.folder = FolderPicker(s.download_dir)
        ctx.output_dir_changed.connect(self.folder.set_path)
        self.title_edit = QLineEdit()
        self.artist_edit = QLineEdit()
        self.album_edit = QLineEdit()
        self.start_edit = TimeEdit("Start (e.g. 0:30)")
        self.end_edit = TimeEdit("End (blank = end)")
        self.cover_check = QCheckBox("Embed video thumbnail as cover art (MP3, M4A, FLAC)")
        self.cover_check.setChecked(s.embed_cover)

        def field(text):
            return label(text, "field")

        grid.addWidget(field("Audio format"), 0, 0)
        grid.addWidget(self.format_combo, 0, 1)
        grid.addWidget(field("Audio quality"), 0, 2)
        grid.addWidget(self.quality_combo, 0, 3)
        grid.addWidget(field("Video resolution (MP4)"), 1, 0)
        grid.addWidget(self.res_combo, 1, 1)
        trim = QHBoxLayout()
        trim.addWidget(self.start_edit)
        trim.addWidget(label("→", "muted"))
        trim.addWidget(self.end_edit)
        trim.addStretch()
        grid.addWidget(field("Trim audio"), 1, 2)
        grid.addLayout(trim, 1, 3)
        grid.addWidget(field("File name"), 2, 0)
        grid.addWidget(self.name_edit, 2, 1, 1, 3)
        grid.addWidget(field("Save to"), 3, 0)
        grid.addWidget(self.folder, 3, 1, 1, 3)
        grid.addWidget(field("Title"), 4, 0)
        grid.addWidget(self.title_edit, 4, 1)
        grid.addWidget(field("Artist"), 4, 2)
        grid.addWidget(self.artist_edit, 4, 3)
        grid.addWidget(field("Album"), 5, 0)
        grid.addWidget(self.album_edit, 5, 1)
        grid.addWidget(self.cover_check, 5, 2, 1, 2)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        self.options_card.body.addLayout(grid)

        buttons = QHBoxLayout()
        buttons.addWidget(label("Audio metadata and trimming apply to audio downloads.", "small"))
        buttons.addStretch()
        self.mp4_btn = button("Download MP4", "film", "large")
        self.mp4_btn.clicked.connect(lambda: self.queue_download(video=True))
        self.audio_btn = button("Download MP3", "download", "accent")
        self.audio_btn.setProperty("variant", "accent")
        self.audio_btn.setStyleSheet("padding: 11px 22px; font-size: 11pt;")
        self.audio_btn.clicked.connect(lambda: self.queue_download(video=False))
        buttons.addWidget(self.mp4_btn)
        buttons.addWidget(self.audio_btn)
        self.options_card.body.addLayout(buttons)
        root.addWidget(self.options_card)
        root.addStretch()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(page_scroll(content))
        self._format_changed()
        self._set_ready(False)

    # ---------------------------------------------------------------- helpers
    def _show_message(self, text: str, role: str = "muted") -> None:
        self.message.setText(text)
        self.message.setProperty("role", role)
        self.message.style().unpolish(self.message)
        self.message.style().polish(self.message)
        self.message.setVisible(bool(text))

    def _set_ready(self, ready: bool) -> None:
        for w in (self.audio_btn, self.mp4_btn):
            w.setEnabled(ready)
        self.options_card.setEnabled(True)
        if ready and self.info and self.info.heights:
            self.mp4_btn.setToolTip("Download the video as MP4")
        tip = "" if ready else "Analyze a URL first"
        if not ready:
            self.audio_btn.setToolTip(tip)
            self.mp4_btn.setToolTip(tip)

    def _format_changed(self) -> None:
        fmt = self.format_combo.currentData()
        sync_quality_enabled(self.format_combo, self.quality_combo)
        self.audio_btn.setText(f"Download {fmt.upper()}")

    def _url_changed(self, text: str) -> None:
        if self.info and text.strip() != self._analyzed_url:
            self._set_ready(False)
            self._show_message("The link changed — press Analyze URL again.", "muted")

    # ---------------------------------------------------------------- actions
    def paste(self) -> None:
        text = QGuiApplication.clipboard().text().strip()
        if not text:
            self._show_message("The clipboard is empty or does not contain text.", "error")
            return
        self.url_edit.setText(text)
        self.analyze()

    def analyze(self) -> None:
        if not self.ctx.deps.ytdlp.found:
            show_error(self, "yt-dlp missing", "yt-dlp is not installed, so URL downloads are unavailable.\n"
                       "Run: pip install -U yt-dlp")
            return
        try:
            url = validate_url(self.url_edit.text())
        except ValidationError as exc:
            self._show_message(str(exc), "error")
            return
        self.url_edit.setText(url)
        self._analysis_seq += 1
        seq = self._analysis_seq
        self.analyze_btn.setEnabled(False)
        self.analyze_btn.setText("Analyzing…")
        self._set_ready(False)
        self._show_message("Fetching video information…", "muted")
        run_async(lambda: downloader.analyze_url(url),
                  lambda info: self._analysis_done(seq, url, info),
                  lambda exc: self._analysis_failed(seq, exc))

    def _analysis_failed(self, seq: int, exc: Exception) -> None:
        if seq != self._analysis_seq:
            return
        self.analyze_btn.setEnabled(True)
        self.analyze_btn.setText("Analyze URL")
        self.info = None
        self.info_card.hide()
        msg = str(exc) if isinstance(exc, downloader.DownloadError) else downloader.friendly_error(str(exc))
        self._show_message(msg, "error")

    def _analysis_done(self, seq: int, url: str, info: downloader.VideoInfo) -> None:
        if seq != self._analysis_seq:
            return
        self.analyze_btn.setEnabled(True)
        self.analyze_btn.setText("Analyze URL")
        self.info = info
        self._analyzed_url = url
        self.title_lbl.setText(info.title)
        bits = [b for b in (info.uploader, info.site, format_duration(info.duration) if info.duration else None) if b]
        self.meta_lbl.setText("  ·  ".join(bits))
        res = ", ".join(f"{h}p" for h in info.heights) or "single format"
        size = f"  ·  up to ~{format_bytes(info.filesize_hint)}" if info.filesize_hint else ""
        self.formats_lbl.setText(f"Available video resolutions: {res}{size}")
        self.res_combo.clear()
        self.res_combo.addItem("Best available", None)
        for h in info.heights:
            self.res_combo.addItem(f"{h}p", h)
        preferred = self.res_combo.findData(self.ctx.settings.video_height)
        if preferred > 0:
            self.res_combo.setCurrentIndex(preferred)
        self.name_edit.setText(sanitize_filename(info.title))
        self.title_edit.setText(info.title)
        self.artist_edit.setText(info.uploader or "")
        self.album_edit.clear()
        self.start_edit.clear()
        self.end_edit.clear()
        self.thumb.setPixmap(QPixmap())
        self.thumb.setText("Loading preview…")
        self.info_card.show()
        self._set_ready(True)
        if not info.has_audio:
            self._show_message("Note: no audio track was detected for this video.", "error")
        else:
            self._show_message("Ready. Choose your options and download.", "success")
        if info.thumbnail:
            run_async(lambda: _fetch_thumbnail(info.thumbnail),
                      lambda data: self._thumb_loaded(seq, data),
                      lambda _exc: self.thumb.setText("Preview unavailable"))
        else:
            self.thumb.setText("No preview available")

    def _thumb_loaded(self, seq: int, data: bytes) -> None:
        if seq != self._analysis_seq:
            return
        pm = QPixmap()
        if pm.loadFromData(data):
            self.thumb.setPixmap(pm.scaled(THUMB_W, THUMB_H, Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation))
        else:
            self.thumb.setText("Preview unavailable")

    def queue_download(self, video: bool) -> None:
        if not self.info:
            return
        deps = self.ctx.deps
        fmt = "mp4" if video else self.format_combo.currentData()
        if not video and not deps.ffmpeg.found:
            show_error(self, "FFmpeg required",
                       "Audio downloads need FFmpeg to convert the audio, but FFmpeg was not found.\n\n"
                       "Open Settings to check the dependency status and installation help.")
            return
        try:
            out_dir = str(validate_output_dir(self.folder.path()))
            start, end = self.start_edit.seconds(), self.end_edit.seconds()
        except (ValidationError, ValueError) as exc:
            show_error(self, "Check your settings", str(exc))
            return
        if not video and start is not None and end is not None and end <= start:
            show_error(self, "Invalid trim", "The end time must be later than the start time.")
            return
        if not video and self.info.duration and start and start >= self.info.duration:
            show_error(self, "Invalid trim", "The start time is beyond the end of the video.")
            return
        name = sanitize_filename(self.name_edit.text().strip() or self.info.title)
        opts = JobOptions(
            output_dir=out_dir, output_name=name, fmt=fmt,
            quality=self.quality_combo.currentData(),
            video_height=self.res_combo.currentData() if video else None,
            start=None if video else start, end=None if video else end,
            title=None if video else (self.title_edit.text().strip() or None),
            artist=None if video else (self.artist_edit.text().strip() or None),
            album=None if video else (self.album_edit.text().strip() or None),
            embed_thumbnail=self.cover_check.isChecked(),
        )
        job = Job(JobKind.DOWNLOAD, self._analyzed_url, self.info.title, opts)
        if not confirm_overwrites(self, [job], self.ctx.manager):
            return
        self.ctx.remember_output_dir(out_dir)
        self.ctx.manager.add(job)
        label_fmt = "MP4 video" if video else AUDIO_FORMATS[fmt].label
        self._show_message(f"Added to the Download Manager: {name} ({label_fmt}).", "success")
        self.window().statusBar().showMessage(f"Queued download: {name}", 5000)
