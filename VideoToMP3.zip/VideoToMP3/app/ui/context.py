"""Application-wide state shared by all tabs."""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from app.core.dependencies import Dependencies, detect_all
from app.core.history import History
from app.core.jobs import JobManager
from app.core.settings import Settings
from app.ui.bridge import JobBridge, run_async


class AppContext(QObject):
    deps_changed = Signal()
    output_dir_changed = Signal(str)
    show_tab = Signal(int)

    def __init__(self, settings: Settings, history: History, deps: Dependencies | None = None):
        super().__init__()
        self.settings = settings
        self.history = history
        self.deps = deps or detect_all(settings.ffmpeg_path)
        self.manager = JobManager(lambda: self.deps, settings.max_concurrent, history)
        self.bridge = JobBridge(self.manager, self)

    def refresh_dependencies(self, on_done=None) -> None:
        def done(deps: Dependencies) -> None:
            self.deps = deps
            self.deps_changed.emit()
            if on_done:
                on_done()

        run_async(lambda: detect_all(self.settings.ffmpeg_path), done)

    def remember_output_dir(self, path: str) -> None:
        if path and path != self.settings.download_dir:
            self.settings.download_dir = path
            self.settings.save()
            self.output_dir_changed.emit(path)
