"""Core (GUI-independent) logic: conversion, downloading, jobs, settings and history."""
