"""Automatic detection of FFmpeg / FFprobe and yt-dlp."""

from __future__ import annotations

import glob
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from app.core.paths import app_base_dir, resource_dir
from app.core.utils import subprocess_kwargs

log = logging.getLogger(__name__)

EXE = ".exe" if sys.platform == "win32" else ""


@dataclass
class DependencyStatus:
    name: str
    found: bool
    path: str | None = None
    version: str | None = None
    source: str | None = None  # e.g. "Custom path", "Bundled", "System PATH"
    detail: str | None = None


@dataclass
class Dependencies:
    ffmpeg: DependencyStatus
    ffprobe: DependencyStatus
    ytdlp: DependencyStatus

    @property
    def ffmpeg_path(self) -> str | None:
        return self.ffmpeg.path if self.ffmpeg.found else None

    @property
    def ffprobe_path(self) -> str | None:
        return self.ffprobe.path if self.ffprobe.found else None


def _version_of(binary: str) -> str | None:
    try:
        out = subprocess.run(
            [binary, "-hide_banner", "-version"], capture_output=True, timeout=15,
            **subprocess_kwargs(),
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    first = out.stdout.decode("utf-8", "replace").splitlines()[:1]
    match = re.search(r"version\s+(\S+)", first[0]) if first else None
    return match.group(1) if match else "unknown"


def _candidate_dirs() -> list[tuple[Path, str]]:
    base, res = app_base_dir(), resource_dir()
    dirs = [
        (base / "ffmpeg" / "bin", "Bundled"),
        (base / "ffmpeg", "Bundled"),
        (base / "vendor" / "ffmpeg" / "bin", "Bundled"),
        (base, "Bundled"),
        (res / "ffmpeg" / "bin", "Bundled"),
    ]
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA", "")
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        extra = [
            r"C:\ffmpeg\bin",
            os.path.join(program_files, "ffmpeg", "bin"),
            os.path.join(local, "Microsoft", "WinGet", "Links"),
            os.path.join(os.environ.get("ChocolateyInstall", r"C:\ProgramData\chocolatey"), "bin"),
            os.path.join(os.path.expanduser("~"), "scoop", "shims"),
        ]
        extra += glob.glob(os.path.join(local, "Microsoft", "WinGet", "Packages", "*FFmpeg*", "*", "bin"))
        dirs += [(Path(d), "Common install location") for d in extra if d]
    return dirs


def _find_binary(name: str, custom_dir: Path | None) -> tuple[str | None, str | None]:
    """Search order: custom folder, bundled folders, PATH, common install locations."""
    exe_name = name + EXE
    if custom_dir is not None and (custom_dir / exe_name).is_file():
        return str(custom_dir / exe_name), "Custom path"
    candidates = _candidate_dirs()
    bundled = [c for c in candidates if c[1] == "Bundled"]
    others = [c for c in candidates if c[1] != "Bundled"]
    for directory, source in bundled:
        if (directory / exe_name).is_file():
            return str(directory / exe_name), source
    on_path = shutil.which(name)
    if on_path:
        return on_path, "System PATH"
    for directory, source in others:
        if (directory / exe_name).is_file():
            return str(directory / exe_name), source
    return None, None


def detect_ffmpeg(custom_path: str = "") -> tuple[DependencyStatus, DependencyStatus]:
    custom_dir: Path | None = None
    if custom_path:
        cp = Path(custom_path)
        custom_dir = cp if cp.is_dir() else cp.parent

    ffmpeg_path, source = _find_binary("ffmpeg", custom_dir)
    if ffmpeg_path is None:
        try:  # Fallback: FFmpeg binary shipped with the imageio-ffmpeg wheel (no ffprobe).
            import imageio_ffmpeg

            candidate = imageio_ffmpeg.get_ffmpeg_exe()
            if candidate and Path(candidate).is_file():
                ffmpeg_path, source = candidate, "imageio-ffmpeg package"
        except Exception:  # noqa: BLE001 - package missing or broken
            pass

    ffmpeg = DependencyStatus("FFmpeg", False, detail="FFmpeg was not found.")
    if ffmpeg_path:
        version = _version_of(ffmpeg_path)
        if version:
            ffmpeg = DependencyStatus("FFmpeg", True, ffmpeg_path, version, source)
        else:
            ffmpeg = DependencyStatus("FFmpeg", False, ffmpeg_path, detail="FFmpeg was found but could not be started.")

    ffprobe = DependencyStatus("FFprobe", False, detail="Optional. Durations are read with FFmpeg instead.")
    probe_path = None
    if ffmpeg.found:
        sibling = Path(ffmpeg.path).with_name("ffprobe" + EXE)
        if sibling.is_file():
            probe_path, probe_source = str(sibling), ffmpeg.source
    if probe_path is None:
        probe_path, probe_source = _find_binary("ffprobe", custom_dir)
    if probe_path and (ver := _version_of(probe_path)):
        ffprobe = DependencyStatus("FFprobe", True, probe_path, ver, probe_source)
    return ffmpeg, ffprobe


def detect_ytdlp() -> DependencyStatus:
    try:
        import yt_dlp  # noqa: F401
        from yt_dlp.version import __version__ as version

        return DependencyStatus("yt-dlp", True, getattr(yt_dlp, "__file__", None), version, "Python package")
    except Exception as exc:  # noqa: BLE001
        return DependencyStatus("yt-dlp", False, detail=f"yt-dlp is not installed ({exc}).")


def detect_all(custom_ffmpeg: str = "") -> Dependencies:
    ffmpeg, ffprobe = detect_ffmpeg(custom_ffmpeg)
    deps = Dependencies(ffmpeg, ffprobe, detect_ytdlp())
    log.info("FFmpeg: %s | FFprobe: %s | yt-dlp: %s", ffmpeg, ffprobe, deps.ytdlp)
    return deps
