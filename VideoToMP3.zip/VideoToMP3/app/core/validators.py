"""Validation of URLs, input files and output folders."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from urllib.parse import urlparse

VIDEO_EXTENSIONS = (".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm")


class ValidationError(ValueError):
    """Raised with a user-readable message when input is invalid."""


def validate_url(url: str) -> str:
    """Return a normalised http(s) URL or raise ValidationError."""
    url = (url or "").strip()
    if not url:
        raise ValidationError("Please paste a video URL first.")
    if " " in url:
        raise ValidationError("The URL contains spaces. Paste a single, complete link.")
    if "://" not in url:
        url = "https://" + url
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValidationError("Only http:// and https:// links are supported.")
    host = parsed.hostname or ""
    if not host or ("." not in host and host != "localhost"):
        raise ValidationError("This does not look like a valid web address.")
    return url


def is_supported_video(path: str | Path) -> bool:
    return Path(path).suffix.lower() in VIDEO_EXTENSIONS


def validate_input_file(path: str | Path) -> Path:
    p = Path(path)
    if not p.exists():
        raise ValidationError(f"File not found: {p}")
    if not p.is_file():
        raise ValidationError(f"Not a file: {p}")
    if not is_supported_video(p):
        raise ValidationError(
            f"Unsupported file type '{p.suffix or '(none)'}'. Supported: "
            + ", ".join(e[1:].upper() for e in VIDEO_EXTENSIONS)
        )
    if not os.access(p, os.R_OK):
        raise ValidationError(f"The file cannot be read (permission denied): {p}")
    if p.stat().st_size == 0:
        raise ValidationError(f"The file is empty: {p.name}")
    return p


def validate_output_dir(path: str | Path) -> Path:
    """Ensure the folder exists (creating it if needed) and is writable."""
    if not str(path).strip():
        raise ValidationError("Please choose an output folder.")
    p = Path(path).expanduser()
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise ValidationError(f"Cannot create the output folder '{p}': {exc.strerror or exc}") from exc
    if not p.is_dir():
        raise ValidationError(f"The output location is not a folder: {p}")
    try:
        with tempfile.NamedTemporaryFile(dir=p, prefix=".vtm_write_test_", delete=True):
            pass
    except OSError as exc:
        raise ValidationError(f"The output folder is not writable: {p}") from exc
    return p


def collect_video_files(paths) -> tuple[list[Path], list[str]]:
    """Expand files/folders into supported video files. Returns (files, rejected_names)."""
    files: list[Path] = []
    rejected: list[str] = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file() and is_supported_video(child):
                    files.append(child)
        elif p.is_file() and is_supported_video(p):
            files.append(p)
        else:
            rejected.append(p.name or str(p))
    return files, rejected
