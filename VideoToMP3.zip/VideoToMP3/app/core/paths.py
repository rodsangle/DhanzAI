"""Filesystem locations used by the application."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from app import APP_NAME


def is_frozen() -> bool:
    """True when running from a PyInstaller bundle."""
    return bool(getattr(sys, "frozen", False))


def app_base_dir() -> Path:
    """Directory containing the executable (frozen) or the project root (source)."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def resource_dir() -> Path:
    """Directory containing bundled read-only resources (assets)."""
    if is_frozen():
        return Path(getattr(sys, "_MEIPASS", app_base_dir()))
    return app_base_dir()


def asset_path(name: str) -> Path:
    return resource_dir() / "assets" / name


def user_data_dir() -> Path:
    """Per-user writable directory for settings, history and logs."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    path = base / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def default_download_dir() -> Path:
    """Default output folder: <Music or Downloads>/VideoToMP3."""
    home = Path.home()
    for candidate in (home / "Music", home / "Downloads"):
        if candidate.is_dir():
            return candidate / APP_NAME
    return home / APP_NAME
