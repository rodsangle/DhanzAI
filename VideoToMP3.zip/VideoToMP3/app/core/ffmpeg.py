"""FFmpeg integration: media probing, audio extraction commands and progress-aware execution."""

from __future__ import annotations

import collections
import json
import logging
import re
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from app.core.utils import subprocess_kwargs

log = logging.getLogger(__name__)


class ConversionError(Exception):
    """A conversion failed; the message is suitable for display to the user."""


class Cancelled(Exception):
    """The operation was cancelled by the user."""


@dataclass(frozen=True)
class AudioFormat:
    key: str
    label: str
    ext: str
    muxer: str
    codec: str
    lossless: bool
    supports_cover: bool
    copy_codecs: tuple[str, ...]  # source codecs that can be stream-copied losslessly


AUDIO_FORMATS: dict[str, AudioFormat] = {
    "mp3": AudioFormat("mp3", "MP3", ".mp3", "mp3", "libmp3lame", False, True, ("mp3",)),
    "m4a": AudioFormat("m4a", "M4A (AAC)", ".m4a", "ipod", "aac", False, True, ("aac", "alac")),
    "aac": AudioFormat("aac", "AAC", ".aac", "adts", "aac", False, False, ("aac",)),
    "wav": AudioFormat("wav", "WAV (lossless)", ".wav", "wav", "pcm_s16le", True, False, ("pcm_s16le",)),
    "flac": AudioFormat("flac", "FLAC (lossless)", ".flac", "flac", "flac", True, True, ("flac",)),
}

# Quality presets. "original" keeps the source audio stream untouched when the
# codec matches the output format (no re-encoding at all), otherwise uses the
# highest-quality encoder setting. "small" favours file size.
QUALITY_PRESETS: dict[str, str] = {
    "original": "Original quality (best)",
    "320": "320 kbps (high)",
    "256": "256 kbps",
    "192": "192 kbps (standard)",
    "128": "128 kbps",
    "small": "Smaller file size (96 kbps)",
}


@dataclass
class MediaInfo:
    duration: float | None = None
    has_audio: bool = False
    has_video: bool = False
    audio_codec: str | None = None
    audio_bitrate: int | None = None  # bits/s
    sample_rate: int | None = None
    channels: int | None = None
    tags: dict = field(default_factory=dict)


@dataclass
class ConvertOptions:
    fmt: str = "mp3"
    quality: str = "192"
    start: float | None = None
    end: float | None = None
    title: str | None = None
    artist: str | None = None
    album: str | None = None
    cover_path: str | None = None


@dataclass
class Progress:
    percent: float | None  # 0..100, None when unknown
    processed_seconds: float
    speed: float | None  # x realtime
    eta: float | None  # seconds


# --------------------------------------------------------------------------- probing

def _run_capture(cmd: list[str], timeout: float = 120) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, timeout=timeout, **subprocess_kwargs())


def probe(path: str | Path, ffmpeg: str, ffprobe: str | None = None) -> MediaInfo:
    """Inspect a media file. Uses ffprobe when available, otherwise parses ``ffmpeg -i``."""
    path = str(path)
    if ffprobe:
        try:
            result = _run_capture([ffprobe, "-v", "error", "-print_format", "json",
                                   "-show_format", "-show_streams", path])
            if result.returncode == 0:
                return _parse_ffprobe_json(json.loads(result.stdout.decode("utf-8", "replace")))
            log.warning("ffprobe failed for %s: %s", path, result.stderr[-500:])
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            log.warning("ffprobe error for %s: %s", path, exc)
    return _probe_with_ffmpeg(path, ffmpeg)


def _parse_ffprobe_json(data: dict) -> MediaInfo:
    info = MediaInfo()
    fmt = data.get("format", {})
    try:
        info.duration = float(fmt["duration"])
    except (KeyError, TypeError, ValueError):
        pass
    info.tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}
    for stream in data.get("streams", []):
        kind = stream.get("codec_type")
        disposition = stream.get("disposition") or {}
        if kind == "video" and not disposition.get("attached_pic"):
            info.has_video = True
        elif kind == "audio" and not info.has_audio:
            info.has_audio = True
            info.audio_codec = stream.get("codec_name")
            for key, attr in (("bit_rate", "audio_bitrate"), ("sample_rate", "sample_rate"),
                              ("channels", "channels")):
                try:
                    setattr(info, attr, int(stream[key]))
                except (KeyError, TypeError, ValueError):
                    pass
            if info.duration is None:
                try:
                    info.duration = float(stream["duration"])
                except (KeyError, TypeError, ValueError):
                    pass
    return info


_DURATION_RE = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)")
_AUDIO_RE = re.compile(r"Stream #\d+:\d+.*?: Audio: (\w+)[^\n]*?(\d+) Hz(?:, ([^,\n]+))?(?:[^\n]*?(\d+) kb/s)?")


def _probe_with_ffmpeg(path: str, ffmpeg: str) -> MediaInfo:
    try:
        result = _run_capture([ffmpeg, "-hide_banner", "-i", path])
    except (OSError, subprocess.SubprocessError) as exc:
        raise ConversionError(f"Could not start FFmpeg: {exc}") from exc
    text = result.stderr.decode("utf-8", "replace")
    if "Invalid data found" in text or "No such file" in text:
        raise ConversionError(_explain_ffmpeg_error(text) or "The file could not be read.")
    info = MediaInfo()
    if m := _DURATION_RE.search(text):
        info.duration = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    for line in text.splitlines():
        if ": Video:" in line and "attached pic" not in line:
            info.has_video = True
    if m := _AUDIO_RE.search(text):
        info.has_audio = True
        info.audio_codec = m.group(1)
        info.sample_rate = int(m.group(2))
        layout = (m.group(3) or "").strip()
        info.channels = {"mono": 1, "stereo": 2}.get(layout)
        if m.group(4):
            info.audio_bitrate = int(m.group(4)) * 1000
    return info


# --------------------------------------------------------------------------- commands

def needs_reencode(fmt: AudioFormat, quality: str, info: MediaInfo) -> bool:
    return not (quality == "original" and info.audio_codec in fmt.copy_codecs)


def _encoder_args(fmt: AudioFormat, quality: str, info: MediaInfo) -> list[str]:
    if not needs_reencode(fmt, quality, info):
        return ["-c:a", "copy"]
    if fmt.key == "wav":
        return ["-c:a", "pcm_s16le"]
    if fmt.key == "flac":
        return ["-c:a", "flac", "-compression_level", "8" if quality == "small" else "5"]
    if fmt.key == "mp3":
        if quality == "original":
            return ["-c:a", "libmp3lame", "-q:a", "0"]  # highest-quality VBR (~245 kbps)
        bitrate = "96" if quality == "small" else quality
        return ["-c:a", "libmp3lame", "-b:a", f"{bitrate}k"]
    # AAC / M4A
    if quality == "original":
        bitrate = "320" if not info.audio_bitrate or info.audio_bitrate > 256_000 else "256"
    else:
        bitrate = "96" if quality == "small" else quality
    return ["-c:a", "aac", "-b:a", f"{bitrate}k"]


def build_audio_command(ffmpeg: str, src: str | Path, dst: str | Path, opts: ConvertOptions,
                        info: MediaInfo) -> list[str]:
    """Build an FFmpeg command that extracts/convert only the audio stream (video is dropped, never re-encoded)."""
    fmt = AUDIO_FORMATS[opts.fmt]
    cmd = [ffmpeg, "-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-nostats",
           "-progress", "pipe:1"]
    if opts.start:
        cmd += ["-ss", f"{opts.start:.3f}"]
    cmd += ["-i", str(src)]
    cover = opts.cover_path if (opts.cover_path and fmt.supports_cover) else None
    if cover:
        cmd += ["-i", str(cover)]
    if opts.end is not None:
        cmd += ["-t", f"{max(0.0, opts.end - (opts.start or 0.0)):.3f}"]
    cmd += ["-map", "0:a:0"]
    if cover:
        cmd += ["-map", "1:v:0", "-c:v", "mjpeg" if fmt.key == "mp3" else "copy",
                "-disposition:v:0", "attached_pic",
                "-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)"]
    cmd += _encoder_args(fmt, opts.quality, info)
    for key, value in (("title", opts.title), ("artist", opts.artist), ("album", opts.album)):
        if value:
            cmd += ["-metadata", f"{key}={value}"]
    if fmt.key == "mp3":
        cmd += ["-id3v2_version", "3", "-write_id3v1", "1"]
    if fmt.key == "m4a":
        cmd += ["-movflags", "+faststart"]
    cmd += ["-f", fmt.muxer, str(dst)]
    return cmd


def output_duration(info: MediaInfo, opts: ConvertOptions) -> float | None:
    if info.duration is None and opts.end is None:
        return None
    end = opts.end if opts.end is not None else info.duration
    if info.duration is not None:
        end = min(end, info.duration)
    return max(0.0, end - (opts.start or 0.0))


# --------------------------------------------------------------------------- execution

def _explain_ffmpeg_error(stderr: str) -> str | None:
    text = stderr.lower()
    if "matches no streams" in text or "does not contain any stream" in text or "output file #0 does not contain" in text:
        return "This file has no audio track to extract."
    if "invalid data found" in text or "moov atom not found" in text:
        return "The file is damaged or not a valid video file."
    if "no space left" in text:
        return "Not enough free disk space for the output file."
    if "permission denied" in text:
        return "Permission denied while reading or writing the file."
    if "no such file" in text:
        return "The input file could not be found."
    if "unknown encoder" in text or "encoder not found" in text:
        return "Your FFmpeg build does not include the required audio encoder. Install a full FFmpeg build."
    return None


def run_ffmpeg(cmd: list[str], duration: float | None,
               on_progress: Callable[[Progress], None] | None = None,
               cancel_event: threading.Event | None = None) -> None:
    """Run FFmpeg with ``-progress pipe:1`` output, reporting progress and honouring cancellation."""
    log.debug("Running: %s", cmd)
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                stdin=subprocess.DEVNULL, **subprocess_kwargs())
    except OSError as exc:
        raise ConversionError(f"Could not start FFmpeg: {exc}") from exc

    stderr_tail: collections.deque[str] = collections.deque(maxlen=40)

    def drain_stderr() -> None:
        for raw in proc.stderr:
            stderr_tail.append(raw.decode("utf-8", "replace").rstrip())

    def watch_cancel() -> None:
        while proc.poll() is None:
            if cancel_event.wait(0.2):
                proc.kill()
                return

    threading.Thread(target=drain_stderr, daemon=True).start()
    if cancel_event is not None:
        threading.Thread(target=watch_cancel, daemon=True).start()

    started = time.monotonic()
    processed = 0.0
    speed: float | None = None
    for raw in proc.stdout:
        key, _, value = raw.decode("utf-8", "replace").strip().partition("=")
        if key in ("out_time_us", "out_time_ms"):
            try:
                processed = max(0.0, int(value) / 1_000_000)
            except ValueError:
                pass
        elif key == "speed":
            try:
                speed = float(value.rstrip("x")) or None
            except ValueError:
                speed = None
        elif key == "progress" and on_progress is not None:
            percent = eta = None
            if duration:
                percent = min(100.0, processed / duration * 100)
                if value == "end":
                    percent = 100.0
                elapsed = time.monotonic() - started
                if processed > 0:
                    eta = max(0.0, (duration - processed) * elapsed / processed)
            on_progress(Progress(percent, processed, speed, eta))
    proc.wait()

    if cancel_event is not None and cancel_event.is_set():
        raise Cancelled()
    if proc.returncode != 0:
        stderr = "\n".join(stderr_tail)
        log.error("FFmpeg failed (%s): %s", proc.returncode, stderr)
        friendly = _explain_ffmpeg_error(stderr)
        detail = stderr.strip().splitlines()[-1] if stderr.strip() else f"exit code {proc.returncode}"
        raise ConversionError(friendly or f"FFmpeg could not convert this file ({detail}).")


def prepare_cover(ffmpeg: str, src: str | Path, dst: str | Path) -> Path | None:
    """Convert any image (webp/png/jpg) to a square-safe JPEG suitable for embedding as cover art."""
    try:
        result = _run_capture([ffmpeg, "-hide_banner", "-nostdin", "-y", "-loglevel", "error",
                               "-i", str(src), "-frames:v", "1",
                               "-vf", "scale='min(1280,iw)':-2", "-q:v", "2", "-f", "image2",
                               "-c:v", "mjpeg", str(dst)], timeout=60)
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("Cover conversion failed: %s", exc)
        return None
    if result.returncode != 0 or not Path(dst).is_file():
        log.warning("Cover conversion failed: %s", result.stderr[-300:])
        return None
    return Path(dst)
