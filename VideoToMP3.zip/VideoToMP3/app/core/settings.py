"""User preferences persisted as JSON in the per-user data folder."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

from app.core.paths import default_download_dir, user_data_dir

log = logging.getLogger(__name__)


@dataclass
class Settings:
    download_dir: str = field(default_factory=lambda: str(default_download_dir()))
    last_input_dir: str = ""
    default_format: str = "mp3"
    default_quality: str = "192"
    max_concurrent: int = 2
    theme: str = "dark"
    notifications: bool = True
    embed_cover: bool = True
    ffmpeg_path: str = ""  # optional manual override
    video_height: int = 1080
    window_geometry: str = ""

    _path: Path | None = field(default=None, repr=False, compare=False)

    @classmethod
    def load(cls, path: Path | None = None) -> "Settings":
        path = path or user_data_dir() / "settings.json"
        settings = cls()
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                known = {f.name for f in fields(cls) if not f.name.startswith("_")}
                for key, value in data.items():
                    if key in known:
                        setattr(settings, key, value)
            except (OSError, ValueError) as exc:
                log.warning("Could not read settings (%s); using defaults", exc)
        settings._path = path
        settings._sanitize()
        return settings

    def _sanitize(self) -> None:
        from app.core.ffmpeg import AUDIO_FORMATS, QUALITY_PRESETS

        if self.default_format not in AUDIO_FORMATS:
            self.default_format = "mp3"
        if self.default_quality not in QUALITY_PRESETS:
            self.default_quality = "192"
        try:
            self.max_concurrent = max(1, min(5, int(self.max_concurrent)))
        except (TypeError, ValueError):
            self.max_concurrent = 2
        if self.theme not in ("dark", "light"):
            self.theme = "dark"
        if not self.download_dir:
            self.download_dir = str(default_download_dir())

    def save(self) -> None:
        if self._path is None:
            self._path = user_data_dir() / "settings.json"
        data = {k: v for k, v in asdict(self).items() if not k.startswith("_")}
        tmp = self._path.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self._path)
        except OSError as exc:
            log.error("Could not save settings: %s", exc)
