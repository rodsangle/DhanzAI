"""yt-dlp integration for analysing and downloading publicly accessible online media.

Policy: this module never passes credentials, cookies or DRM-bypass options to yt-dlp.
Content that requires a login, is private, paid, or DRM-protected is reported to the
user as unavailable instead of being worked around.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from app.core.ffmpeg import Cancelled

log = logging.getLogger(__name__)

VIDEO_HEIGHTS = (2160, 1440, 1080, 720, 480, 360, 240, 144)
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp")


class DownloadError(Exception):
    """A download or analysis failed; the message is suitable for display."""


@dataclass
class VideoInfo:
    url: str
    title: str
    uploader: str | None = None
    duration: float | None = None
    thumbnail: str | None = None
    site: str | None = None
    heights: list[int] = field(default_factory=list)
    has_audio: bool = True
    filesize_hint: int | None = None


@dataclass
class DownloadProgress:
    phase: str  # "Downloading", "Merging", ...
    percent: float | None
    speed: float | None  # bytes/s
    eta: float | None  # seconds
    downloaded: int | None = None
    total: int | None = None


@dataclass
class DownloadResult:
    media_path: Path
    thumbnail_path: Path | None
    info: dict


class _Logger:
    """Routes yt-dlp messages to the application log instead of stdout."""

    def debug(self, msg: str) -> None:
        if not msg.startswith("[debug] "):
            log.debug("yt-dlp: %s", msg)

    def info(self, msg: str) -> None:
        log.debug("yt-dlp: %s", msg)

    def warning(self, msg: str) -> None:
        log.warning("yt-dlp: %s", msg)

    def error(self, msg: str) -> None:
        log.error("yt-dlp: %s", msg)


def _base_options() -> dict:
    return {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "noplaylist": True,
        "logger": _Logger(),
        "socket_timeout": 30,
        "retries": 5,
        "fragment_retries": 10,
        "extractor_retries": 2,
        "color": {"stdout": "never", "stderr": "never"},
        # Never use credentials or browser cookies; never allow DRM-protected formats.
        "allow_unplayable_formats": False,
        "usenetrc": False,
    }


_ERROR_HINTS = (
    (("drm",), "This video is protected by DRM and cannot be downloaded."),
    (("sign in to confirm your age", "age-restricted", "age restricted"),
     "This video is age-restricted and requires signing in. It cannot be downloaded by this app."),
    (("sign in to confirm you", "not a bot"),
     "The website is asking for a sign-in / bot check for this video. Try again later; this app does not log in to websites."),
    (("private video", "this video is private", "is private"),
     "This video is private and cannot be downloaded."),
    (("login required", "log in", "login", "sign in", "cookies", "authentication", "account"),
     "This content requires signing in to the website. This app only downloads publicly accessible media."),
    (("members-only", "members only", "join this channel", "premium", "payment", "purchase", "rental"),
     "This content is restricted to paying members or subscribers and cannot be downloaded."),
    (("not available in your country", "geo restrict", "geo-restrict", "geoblock"),
     "This video is not available in your region."),
    (("unsupported url",), "This website or link type is not supported by yt-dlp."),
    (("video unavailable", "has been removed", "no longer available", "does not exist", "http error 404", "not found"),
     "The video is unavailable (it may have been removed or the link is wrong)."),
    (("unable to connect to proxy", "proxyerror", "tunnel connection failed"),
     "Could not connect through your network proxy/firewall. Check your connection or proxy settings."),
    (("http error 403", "forbidden"),
     "The website refused the download (HTTP 403). The media may be restricted, or yt-dlp may need an update."),
    (("http error 429", "too many requests"),
     "The website is rate-limiting requests (HTTP 429). Please wait a few minutes and try again."),
    (("live event will begin", "premieres in", "is_live", "live stream"),
     "Live streams and upcoming premieres cannot be downloaded."),
    (("getaddrinfo", "name or service not known", "nodename nor servname", "temporary failure in name resolution",
      "no address associated", "network is unreachable", "connection refused", "connection reset",
      "timed out", "timeout", "unable to download webpage", "urlopen error", "remote end closed"),
     "Network error: could not reach the website. Check your internet connection and try again."),
    (("requested format is not available", "no video formats found"),
     "No downloadable format was found for this link."),
    (("ffmpeg", "ffprobe"), "FFmpeg is required for this download but is not available. Check Settings."),
    (("no space left",), "Not enough free disk space."),
)


def friendly_error(message: str) -> str:
    text = (message or "").lower()
    for needles, hint in _ERROR_HINTS:
        if any(n in text for n in needles):
            return hint
    cleaned = (message or "Unknown error").replace("ERROR: ", "").strip()
    return f"Download failed: {cleaned[:300]}"


def analyze_url(url: str) -> VideoInfo:
    """Fetch title, duration, thumbnail and available resolutions without downloading."""
    import yt_dlp

    opts = _base_options() | {"skip_download": True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
    except yt_dlp.utils.DownloadError as exc:
        raise DownloadError(friendly_error(str(exc))) from exc
    except Exception as exc:  # noqa: BLE001 - yt-dlp may raise many types
        log.exception("Analysis failed")
        raise DownloadError(friendly_error(str(exc))) from exc

    if not info:
        raise DownloadError("No media information was returned for this link.")
    if info.get("_type") == "playlist" or info.get("entries") is not None:
        raise DownloadError("This link is a playlist or channel. Please paste the link of a single video.")
    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        raise DownloadError("Live streams and upcoming premieres cannot be downloaded.")
    if info.get("_has_drm") or info.get("has_drm"):
        raise DownloadError("This video is protected by DRM and cannot be downloaded.")

    formats = [f for f in (info.get("formats") or [info]) if not f.get("has_drm")]
    heights = sorted({int(f["height"]) for f in formats
                      if f.get("height") and f.get("vcodec") not in (None, "none")}, reverse=True)
    has_audio = not formats or any(f.get("acodec") != "none" for f in formats)
    sizes = [f.get("filesize") or f.get("filesize_approx") for f in formats]
    return VideoInfo(
        url=info.get("webpage_url") or url,
        title=info.get("title") or info.get("id") or "video",
        uploader=info.get("uploader") or info.get("channel") or info.get("creator"),
        duration=float(info["duration"]) if info.get("duration") else None,
        thumbnail=info.get("thumbnail"),
        site=info.get("extractor_key") or info.get("extractor"),
        heights=heights,
        has_audio=has_audio,
        filesize_hint=max((s for s in sizes if s), default=None),
    )


def video_format_selector(height: int | None, have_ffmpeg: bool) -> str:
    """Prefer MP4/M4A streams (no re-encode needed for MP4 output), capped at ``height``."""
    cap = f"[height<={height}]" if height else ""
    if not have_ffmpeg:  # merging separate streams needs FFmpeg; use pre-merged files only
        return f"b[ext=mp4]{cap}/b{cap}/b"
    return (f"bv*[ext=mp4]{cap}+ba[ext=m4a]/bv*{cap}+ba/b[ext=mp4]{cap}/b{cap}/bv*+ba/b")


def download(url: str, work_dir: Path, mode: str, *, height: int | None, ffmpeg_path: str | None,
             want_thumbnail: bool, on_progress: Callable[[DownloadProgress], None],
             cancel_event: threading.Event) -> DownloadResult:
    """Download ``url`` into ``work_dir``.

    mode == "audio": best audio-only stream (converted afterwards by the FFmpeg pipeline).
    mode == "video": MP4 video+audio at most ``height`` pixels tall.
    """
    import yt_dlp

    work_dir.mkdir(parents=True, exist_ok=True)

    def hook(d: dict) -> None:
        if cancel_event.is_set():
            raise yt_dlp.utils.DownloadCancelled("Cancelled by user")
        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes")
            percent = None
            if total and done is not None:
                percent = min(100.0, done / total * 100)
            elif d.get("fragment_count") and d.get("fragment_index"):
                percent = min(100.0, d["fragment_index"] / d["fragment_count"] * 100)
            on_progress(DownloadProgress("Downloading", percent, d.get("speed"), d.get("eta"), done, total))
        elif status == "finished":
            on_progress(DownloadProgress("Processing", 100.0, None, None))

    def pp_hook(d: dict) -> None:
        if cancel_event.is_set():
            raise yt_dlp.utils.DownloadCancelled("Cancelled by user")
        if d.get("status") == "started" and d.get("postprocessor") in ("Merger", "FFmpegMerger"):
            on_progress(DownloadProgress("Merging audio and video", None, None, None))

    opts = _base_options() | {
        "outtmpl": {"default": str(work_dir / "media.%(ext)s"),
                    "thumbnail": str(work_dir / "thumb.%(ext)s")},
        "paths": {"home": str(work_dir), "temp": str(work_dir)},
        "progress_hooks": [hook],
        "postprocessor_hooks": [pp_hook],
        "overwrites": True,
        "continuedl": False,
        "writethumbnail": want_thumbnail,
        "windowsfilenames": True,
    }
    if ffmpeg_path:
        opts["ffmpeg_location"] = ffmpeg_path
    if mode == "audio":
        opts["format"] = "bestaudio/best"
    else:
        opts["format"] = video_format_selector(height, bool(ffmpeg_path))
        if ffmpeg_path:
            opts["merge_output_format"] = "mp4"

    started = time.monotonic()
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
    except yt_dlp.utils.DownloadCancelled as exc:
        raise Cancelled() from exc
    except yt_dlp.utils.DownloadError as exc:
        if cancel_event.is_set():
            raise Cancelled() from exc
        raise DownloadError(friendly_error(str(exc))) from exc
    except Exception as exc:  # noqa: BLE001
        if cancel_event.is_set():
            raise Cancelled() from exc
        log.exception("Download failed")
        raise DownloadError(friendly_error(str(exc))) from exc

    if cancel_event.is_set():
        raise Cancelled()
    if info is None:
        raise DownloadError("The website returned no downloadable media.")

    media_path: Path | None = None
    for item in info.get("requested_downloads") or []:
        fp = item.get("filepath")
        if fp and Path(fp).is_file():
            media_path = Path(fp)
    if media_path is None:  # fallback: newest non-thumbnail file in the work dir
        files = [p for p in work_dir.glob("media.*")
                 if p.suffix.lower() not in IMAGE_EXTS and not p.name.endswith((".part", ".ytdl"))]
        if files:
            media_path = max(files, key=lambda p: p.stat().st_mtime)
    if media_path is None or media_path.stat().st_size == 0:
        raise DownloadError("The download finished but no media file was produced.")

    thumb = None
    if want_thumbnail:
        thumbs = [p for p in work_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS]
        thumb = thumbs[0] if thumbs else None
    log.info("Downloaded %s in %.1fs -> %s", url, time.monotonic() - started, media_path)
    return DownloadResult(media_path, thumb, info)
