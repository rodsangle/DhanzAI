"""Job model, background job queue and the conversion / download pipelines."""

from __future__ import annotations

import itertools
import logging
import os
import shutil
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable

from app.core import downloader
from app.core.dependencies import Dependencies
from app.core.ffmpeg import (AUDIO_FORMATS, Cancelled, ConversionError, ConvertOptions, Progress,
                             build_audio_command, output_duration, prepare_cover, probe, run_ffmpeg)
from app.core.history import History
from app.core.utils import format_eta, format_speed, sanitize_filename, unique_path

log = logging.getLogger(__name__)

VIDEO_FORMAT = "mp4"


class JobStatus(str, Enum):
    QUEUED = "Queued"
    RUNNING = "Running"
    COMPLETED = "Completed"
    FAILED = "Failed"
    CANCELLED = "Cancelled"

    @property
    def finished(self) -> bool:
        return self in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED)


class JobKind(str, Enum):
    CONVERT = "convert"
    DOWNLOAD = "download"


@dataclass
class JobOptions:
    output_dir: str
    output_name: str  # file stem without extension
    fmt: str = "mp3"  # audio format key or "mp4"
    quality: str = "192"
    video_height: int | None = None
    start: float | None = None
    end: float | None = None
    title: str | None = None
    artist: str | None = None
    album: str | None = None
    cover_path: str | None = None  # user-chosen cover image (local conversions)
    embed_thumbnail: bool = True  # URL downloads: embed the site's thumbnail
    overwrite: bool = False  # user explicitly confirmed overwriting an existing file

    @property
    def extension(self) -> str:
        return ".mp4" if self.fmt == VIDEO_FORMAT else AUDIO_FORMATS[self.fmt].ext


_ids = itertools.count(1)


@dataclass
class Job:
    kind: JobKind
    source: str  # file path or URL
    display_name: str
    options: JobOptions
    id: int = field(default_factory=lambda: next(_ids))
    status: JobStatus = JobStatus.QUEUED
    phase: str = "Waiting in queue"
    progress: float | None = 0.0
    speed: str = ""
    eta: str = ""
    error: str = ""
    output_path: str = ""
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    finished_at: float | None = None
    attempts: int = 0
    _cancel: threading.Event = field(default_factory=threading.Event, repr=False)

    @property
    def target_path(self) -> Path:
        o = self.options
        return Path(o.output_dir) / (sanitize_filename(o.output_name) + o.extension)

    @property
    def format_label(self) -> str:
        return "MP4 video" if self.options.fmt == VIDEO_FORMAT else AUDIO_FORMATS[self.options.fmt].label

    def reset(self) -> None:
        self.status = JobStatus.QUEUED
        self.phase, self.progress, self.speed, self.eta, self.error = "Waiting in queue", 0.0, "", "", ""
        self.output_path, self.started_at, self.finished_at = "", None, None
        self._cancel = threading.Event()


Listener = Callable[[Job], None]


class JobManager:
    """Runs jobs on worker threads with a configurable concurrency limit.

    Listener callbacks are invoked from worker threads; GUI code must marshal them
    to the main thread (see ``app.ui.bridge``).
    """

    _finalize_lock = threading.Lock()

    def __init__(self, deps_provider: Callable[[], Dependencies], max_concurrent: int = 2,
                 history: History | None = None):
        self._deps_provider = deps_provider
        self._max = max(1, max_concurrent)
        self._history = history
        self._lock = threading.RLock()
        self._jobs: dict[int, Job] = {}
        self._queue: list[int] = []
        self._threads: dict[int, threading.Thread] = {}
        self._listeners: list[Listener] = []
        self._last_emit: dict[int, float] = {}

    # -- listeners ---------------------------------------------------------
    def add_listener(self, fn: Listener) -> None:
        self._listeners.append(fn)

    def _emit(self, job: Job, force: bool = True) -> None:
        now = time.monotonic()
        if not force and now - self._last_emit.get(job.id, 0) < 0.15:
            return  # throttle very frequent progress updates
        self._last_emit[job.id] = now
        for fn in list(self._listeners):
            try:
                fn(job)
            except Exception:  # noqa: BLE001
                log.exception("Job listener failed")

    # -- queue API ---------------------------------------------------------
    @property
    def jobs(self) -> list[Job]:
        with self._lock:
            return list(self._jobs.values())

    def get(self, job_id: int) -> Job | None:
        return self._jobs.get(job_id)

    def active_count(self) -> int:
        with self._lock:
            return sum(1 for j in self._jobs.values() if not j.status.finished)

    def set_max_concurrent(self, value: int) -> None:
        with self._lock:
            self._max = max(1, int(value))
        self._schedule()

    def add(self, job: Job) -> Job:
        with self._lock:
            self._jobs[job.id] = job
            self._queue.append(job.id)
        self._emit(job)
        self._schedule()
        return job

    def cancel(self, job_id: int) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.status.finished:
                return
            job._cancel.set()
            if job.status == JobStatus.QUEUED:
                self._queue.remove(job_id)
                self._finish(job, JobStatus.CANCELLED, "Cancelled")
                return
            job.phase = "Cancelling..."
        self._emit(job)

    def cancel_all(self) -> None:
        for job in self.jobs:
            self.cancel(job.id)

    def retry(self, job_id: int) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None or job.status not in (JobStatus.FAILED, JobStatus.CANCELLED):
                return
            job.reset()
            self._queue.append(job.id)
        self._emit(job)
        self._schedule()

    def remove(self, job_id: int) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is not None and job.status.finished:
                del self._jobs[job_id]
                self._last_emit.pop(job_id, None)

    def wait_all(self, timeout: float | None = None) -> bool:
        """Block until every job has finished (used by tests and shutdown)."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            with self._lock:
                pending = [j for j in self._jobs.values() if not j.status.finished]
            if not pending:
                return True
            if deadline is not None and time.monotonic() > deadline:
                return False
            time.sleep(0.05)

    def shutdown(self, timeout: float = 5.0) -> None:
        self.cancel_all()
        for t in list(self._threads.values()):
            t.join(timeout)

    # -- scheduling --------------------------------------------------------
    def _schedule(self) -> None:
        with self._lock:
            while self._queue and len(self._threads) < self._max:
                job = self._jobs[self._queue.pop(0)]
                job.status = JobStatus.RUNNING
                job.started_at = time.time()
                job.attempts += 1
                job.phase = "Starting"
                job.progress = None
                thread = threading.Thread(target=self._run, args=(job,), daemon=True,
                                          name=f"job-{job.id}")
                self._threads[job.id] = thread
                thread.start()

    def _run(self, job: Job) -> None:
        self._emit(job)
        try:
            deps = self._deps_provider()
            if job.kind == JobKind.CONVERT:
                run_conversion(job, deps, lambda: self._emit(job, force=False))
            else:
                run_download(job, deps, lambda: self._emit(job, force=False))
            self._finish(job, JobStatus.COMPLETED, "Completed")
        except Cancelled:
            self._finish(job, JobStatus.CANCELLED, "Cancelled")
        except (ConversionError, downloader.DownloadError, ValueError) as exc:
            self._finish(job, JobStatus.FAILED, "Failed", str(exc))
        except OSError as exc:
            self._finish(job, JobStatus.FAILED, "Failed", f"File system error: {exc.strerror or exc}")
        except Exception as exc:  # noqa: BLE001 - never let a worker crash silently
            log.exception("Unexpected error in job %s", job.id)
            self._finish(job, JobStatus.FAILED, "Failed", f"Unexpected error: {exc}")
        finally:
            with self._lock:
                self._threads.pop(job.id, None)
            self._schedule()

    def _finish(self, job: Job, status: JobStatus, phase: str, error: str = "") -> None:
        job.status, job.phase, job.error = status, phase, error
        job.finished_at = time.time()
        job.speed = job.eta = ""
        if status == JobStatus.COMPLETED:
            job.progress = 100.0
        if self._history is not None:
            try:
                self._history.add(job.kind.value, job.display_name, job.source,
                                  job.output_path or None, job.format_label, status.value, error or None)
            except Exception:  # noqa: BLE001
                log.exception("Could not write history")
        self._emit(job)


# --------------------------------------------------------------------------- pipelines

def _require_ffmpeg(deps: Dependencies) -> str:
    if not deps.ffmpeg_path:
        raise ConversionError(
            "FFmpeg was not found. Install FFmpeg (see README) or set its location in Settings, "
            "then press Retry.")
    return deps.ffmpeg_path


def _work_dir(job: Job) -> Path:
    path = Path(job.options.output_dir) / f".vtm_work_{job.id}_{uuid.uuid4().hex[:6]}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def finalize_output(tmp: Path, job: Job, ext: str | None = None) -> Path:
    """Move a finished temp file to its final name without overwriting unexpectedly."""
    with JobManager._finalize_lock:
        target = job.target_path
        if ext and ext.lower() != target.suffix.lower():
            target = target.with_suffix(ext.lower())
        if target.exists() and not job.options.overwrite:
            target = unique_path(target)
        os.replace(tmp, target)
    job.output_path = str(target)
    return target


def _convert_file(job: Job, deps: Dependencies, src: Path, work: Path, cover: Path | None,
                  emit: Callable[[], None], progress_base: float = 0.0, progress_span: float = 100.0) -> Path:
    ffmpeg = _require_ffmpeg(deps)
    o = job.options
    info = probe(src, ffmpeg, deps.ffprobe_path)
    if not info.has_audio:
        raise ConversionError("This file has no audio track to extract.")
    if info.duration and o.start and o.start >= info.duration:
        raise ConversionError("The trim start time is beyond the end of the media.")
    if o.start is not None and o.end is not None and o.end <= o.start:
        raise ConversionError("The trim end time must be later than the start time.")

    copts = ConvertOptions(fmt=o.fmt, quality=o.quality, start=o.start, end=o.end,
                           title=o.title, artist=o.artist, album=o.album,
                           cover_path=str(cover) if cover else None)
    tmp = work / ("output" + AUDIO_FORMATS[o.fmt].ext)
    cmd = build_audio_command(ffmpeg, src, tmp, copts, info)
    duration = output_duration(info, copts)

    def on_progress(p: Progress) -> None:
        job.phase = "Converting"
        if p.percent is not None:
            job.progress = progress_base + p.percent * progress_span / 100
        job.speed = f"{p.speed:.1f}x" if p.speed else ""
        job.eta = format_eta(p.eta)
        emit()

    job.phase = "Converting"
    emit()
    run_ffmpeg(cmd, duration, on_progress, job._cancel)
    if not tmp.is_file() or tmp.stat().st_size == 0:
        raise ConversionError("FFmpeg finished but produced an empty file.")
    return finalize_output(tmp, job)


def run_conversion(job: Job, deps: Dependencies, emit: Callable[[], None]) -> None:
    src = Path(job.source)
    if not src.is_file():
        raise ConversionError(f"The source file no longer exists: {src}")
    _require_ffmpeg(deps)
    work = _work_dir(job)
    try:
        cover = None
        if job.options.cover_path and AUDIO_FORMATS[job.options.fmt].supports_cover:
            cover = prepare_cover(deps.ffmpeg_path, job.options.cover_path, work / "cover.jpg")
        _convert_file(job, deps, src, work, cover, emit)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def run_download(job: Job, deps: Dependencies, emit: Callable[[], None]) -> None:
    if not deps.ytdlp.found:
        raise downloader.DownloadError("yt-dlp is not installed, so online downloads are unavailable.")
    o = job.options
    audio = o.fmt != VIDEO_FORMAT
    if audio:
        _require_ffmpeg(deps)
    work = _work_dir(job)
    span = 90.0 if audio else 100.0

    def on_progress(p: downloader.DownloadProgress) -> None:
        job.phase = p.phase
        job.progress = None if p.percent is None else p.percent * span / 100
        job.speed = format_speed(p.speed)
        job.eta = format_eta(p.eta)
        emit()

    try:
        job.phase = "Connecting"
        emit()
        want_thumb = audio and o.embed_thumbnail and AUDIO_FORMATS[o.fmt].supports_cover
        result = downloader.download(job.source, work, "audio" if audio else "video",
                                     height=o.video_height, ffmpeg_path=deps.ffmpeg_path,
                                     want_thumbnail=want_thumb, on_progress=on_progress,
                                     cancel_event=job._cancel)
        if job._cancel.is_set():
            raise Cancelled()
        if audio:
            cover = None
            if result.thumbnail_path:
                cover = prepare_cover(deps.ffmpeg_path, result.thumbnail_path, work / "cover.jpg")
            job.speed = job.eta = ""
            _convert_file(job, deps, result.media_path, work, cover, emit,
                          progress_base=span, progress_span=100 - span)
        else:
            job.phase = "Saving"
            emit()
            # Without FFmpeg, a site may only offer e.g. WebM; keep the real extension.
            finalize_output(result.media_path, job, result.media_path.suffix)
    finally:
        shutil.rmtree(work, ignore_errors=True)
