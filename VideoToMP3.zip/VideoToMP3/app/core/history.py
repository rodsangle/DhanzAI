"""SQLite-backed download / conversion history log."""

from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from app.core.paths import user_data_dir

_SCHEMA = """
CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    source TEXT NOT NULL,
    output_path TEXT,
    format TEXT,
    status TEXT NOT NULL,
    error TEXT,
    size INTEGER,
    finished_at REAL NOT NULL
);
"""


@dataclass
class HistoryEntry:
    id: int
    kind: str
    title: str
    source: str
    output_path: str | None
    format: str | None
    status: str
    error: str | None
    size: int | None
    finished_at: float


class History:
    def __init__(self, path: Path | None = None):
        self.path = path or user_data_dir() / "history.db"
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.execute(_SCHEMA)
        self._conn.commit()

    def add(self, kind: str, title: str, source: str, output_path: str | None,
            fmt: str | None, status: str, error: str | None = None) -> None:
        size = None
        if output_path and Path(output_path).exists():
            size = Path(output_path).stat().st_size
        with self._lock:
            self._conn.execute(
                "INSERT INTO history (kind, title, source, output_path, format, status, error, size, finished_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (kind, title, source, output_path, fmt, status, error, size, time.time()),
            )
            self._conn.commit()

    def entries(self, limit: int = 500) -> list[HistoryEntry]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, kind, title, source, output_path, format, status, error, size, finished_at"
                " FROM history ORDER BY finished_at DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [HistoryEntry(*row) for row in rows]

    def clear(self) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM history")
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()
