"""Small helpers shared by the core modules (formatting, filenames, subprocess flags)."""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

_INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}
MAX_STEM_LENGTH = 150


def sanitize_filename(name: str, fallback: str = "output") -> str:
    """Return a Windows-safe file stem, keeping Unicode characters intact."""
    name = _INVALID_CHARS.sub("_", name or "")
    name = re.sub(r"\s+", " ", name).strip().rstrip(". ")
    if len(name) > MAX_STEM_LENGTH:
        name = name[:MAX_STEM_LENGTH].rstrip(". ")
    if not name or name.upper().split(".")[0] in _RESERVED_NAMES:
        name = f"{fallback}_{name}" if name else fallback
    return name


def unique_path(path: Path) -> Path:
    """Return ``path`` or the first free ``name (n).ext`` variant next to it."""
    if not path.exists():
        return path
    n = 1
    while True:
        candidate = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not candidate.exists():
            return candidate
        n += 1


def parse_time(text: str | None) -> float | None:
    """Parse ``SS``, ``MM:SS`` or ``HH:MM:SS(.ms)`` into seconds. Empty -> None.

    Raises ValueError for malformed input.
    """
    if text is None:
        return None
    text = text.strip().replace(",", ".")
    if not text:
        return None
    parts = text.split(":")
    if len(parts) > 3 or any(p.strip() == "" for p in parts):
        raise ValueError(f"Invalid time '{text}'. Use HH:MM:SS, MM:SS or seconds.")
    try:
        values = [float(p) for p in parts]
    except ValueError:
        raise ValueError(f"Invalid time '{text}'. Use HH:MM:SS, MM:SS or seconds.") from None
    if any(v < 0 for v in values) or any(v >= 60 for v in values[1:]):
        raise ValueError(f"Invalid time '{text}'. Minutes and seconds must be below 60.")
    seconds = 0.0
    for v in values:
        seconds = seconds * 60 + v
    return seconds


def format_duration(seconds: float | None) -> str:
    if seconds is None or seconds < 0:
        return "--:--"
    seconds = int(round(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def format_bytes(num: float | None) -> str:
    if num is None:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if abs(num) < 1024 or unit == "GB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"


def format_speed(bytes_per_sec: float | None) -> str:
    return f"{format_bytes(bytes_per_sec)}/s" if bytes_per_sec else ""


def format_eta(seconds: float | None) -> str:
    if seconds is None or seconds < 0:
        return ""
    return format_duration(seconds)


def subprocess_kwargs() -> dict:
    """Keyword args that hide console windows for child processes on Windows."""
    if sys.platform == "win32":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return {"creationflags": subprocess.CREATE_NO_WINDOW, "startupinfo": startupinfo}
    return {}
