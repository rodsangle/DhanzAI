# -*- mode: python ; coding: utf-8 -*-
# PyInstaller build configuration.  Build with:  pyinstaller --noconfirm --clean VideoToMP3.spec
# Produces dist\VideoToMP3\VideoToMP3.exe (one-folder build: fast start-up, fewer antivirus false positives).

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH)

datas = [(str(ROOT / "assets"), "assets")]
hiddenimports = collect_submodules("yt_dlp")

# Optional: bundle a full FFmpeg build placed in vendor\ffmpeg\bin (see tools\fetch_ffmpeg.ps1).
vendor = ROOT / "vendor" / "ffmpeg" / "bin"
bundled_ffmpeg = False
for name in ("ffmpeg.exe", "ffprobe.exe", "ffmpeg", "ffprobe"):
    if (vendor / name).is_file():
        datas.append((str(vendor / name), "ffmpeg/bin"))
        bundled_ffmpeg = True

# Otherwise ship the FFmpeg binary from the imageio-ffmpeg package as a fallback.
if not bundled_ffmpeg:
    try:
        datas += collect_data_files("imageio_ffmpeg", subdir="binaries")
        hiddenimports.append("imageio_ffmpeg")
    except Exception:
        pass

excludes = [
    "tkinter", "unittest", "pytest",
    "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtWebEngineQuick", "PySide6.QtWebChannel",
    "PySide6.QtQml", "PySide6.QtQuick", "PySide6.QtQuickWidgets", "PySide6.Qt3DCore", "PySide6.Qt3DRender",
    "PySide6.QtCharts", "PySide6.QtDataVisualization", "PySide6.QtGraphs", "PySide6.QtMultimedia",
    "PySide6.QtPdf", "PySide6.QtPdfWidgets", "PySide6.QtBluetooth", "PySide6.QtPositioning",
    "PySide6.QtSensors", "PySide6.QtSerialPort", "PySide6.QtSql", "PySide6.QtTest",
]

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="VideoToMP3",
    debug=False,
    strip=False,
    upx=False,
    console=False,  # GUI app: no console window
    icon=str(ROOT / "assets" / "app.ico"),
)

coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="VideoToMP3")
