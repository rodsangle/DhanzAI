# Video to MP3 Converter & Downloader

A Windows 11 desktop app (Python 3.12+ / PySide6) for two jobs:

- **Converting local video files** to MP3, M4A, AAC, WAV or FLAC, using FFmpeg.
- **Downloading publicly accessible online media** as audio or MP4, using yt-dlp.

It has a dark/light themed interface, batch processing, a download manager with queue, cancel and retry, metadata tagging, trimming, cover art, notifications and a history log.

> **Use responsibly.** Only download media that you own or have permission to download. The app does not bypass DRM, logins, paywalls or other website restrictions, and it never asks for website passwords or reads browser cookies.

---

## 1. Features

| Area | What it does |
|---|---|
| **URL Downloader** | Paste or Paste-from-clipboard a link, then **Analyze URL**. You see the title, thumbnail, uploader, duration and available resolutions. Pick the audio format, quality and MP4 resolution, then click **Download MP3** (or the chosen audio format) or **Download MP4**. You can rename the file, edit metadata (title/artist/album), trim, and embed the thumbnail as cover art. |
| **Video Converter** | Drag and drop files or whole folders, or click **Browse Files**. Inputs: MP4, MOV, AVI, MKV, WMV, FLV, WEBM. Batch conversion, an editable output name per file, MP3/M4A/AAC/WAV/FLAC output, 128/192/256/320 kbps, **Original quality** or **Smaller file size**, metadata, an optional cover image, and start/end trim. |
| **Download Manager** | Active and queued tasks, each with a progress bar, %, speed and ETA. **Cancel**, **Retry**, **Retry Failed**, **Cancel All**, **Clear Finished**, **Open Download Folder**. A **Completed** list for this session and a persistent **History** log stored in SQLite. |
| **Settings** | Default folder, default format and bitrate, max simultaneous tasks (1–5), preferred MP4 resolution, notifications, dark/light theme, live FFmpeg/FFprobe/yt-dlp status, a custom FFmpeg location, and a re-check button. |

### How it works
- **No unnecessary re-encoding.** Only the first audio stream is mapped (`-map 0:a:0`). Video is dropped, never re-encoded.
- **Original quality** stream-copies the audio when the source codec already matches the output (for example AAC→M4A or MP3→MP3). Otherwise it uses the encoder's highest-quality setting.
- **Safe output.** Each task writes to a temporary folder in the destination and is moved into place only when it finishes. Cancelled or failed tasks leave no partial files.
- **Overwrite protection.** If an output file exists, or two batch items would get the same name, you're asked to choose **Overwrite**, **Keep Both** (auto-renames to `name (1).mp3`) or **Cancel**.
- **Responsive UI.** All work runs on background threads. FFmpeg progress is streamed with `-progress`, so long videos (hours) work fine.
- **Unicode.** File names, folders and metadata support any language. Characters Windows forbids are replaced with `_`.
- **Automatic dependency detection.** FFmpeg is searched for in this order:
  1. The custom path from Settings.
  2. FFmpeg bundled next to the app.
  3. `PATH`.
  4. winget, Chocolatey, Scoop and `C:\ffmpeg\bin`.
  5. The FFmpeg binary shipped with the `imageio-ffmpeg` package (fallback).
- **Settings, history and logs** are stored in `%APPDATA%\VideoToMP3\`. You can open this folder from Settings → About.

---

## 2. Project structure

```
VideoToMP3/
├── main.py                  # Entry point (logging, theme, main window)
├── VideoToMP3.pyw           # Double-click launcher (pythonw, no console)
├── requirements.txt         # Runtime deps: PySide6, yt-dlp, imageio-ffmpeg
├── requirements-dev.txt     # pytest, pyinstaller, pillow
├── install.bat              # One-time setup from source + shortcuts
├── run.bat                  # Launch from source without console
├── build_exe.bat            # Build standalone dist\VideoToMP3\VideoToMP3.exe
├── VideoToMP3.spec          # PyInstaller configuration
├── installer/VideoToMP3.iss # Inno Setup script -> Setup.exe installer
├── assets/app.ico, app.png  # Application icon
├── app/
│   ├── core/                # GUI-independent logic (fully unit-tested)
│   │   ├── dependencies.py  # FFmpeg / FFprobe / yt-dlp detection
│   │   ├── ffmpeg.py        # probing, command building, progress, cancel
│   │   ├── downloader.py    # yt-dlp analyze/download, friendly errors
│   │   ├── jobs.py          # Job model, queue manager, pipelines
│   │   ├── history.py       # SQLite history log
│   │   ├── settings.py      # JSON preferences
│   │   ├── validators.py    # URL / file / folder validation
│   │   ├── utils.py         # filenames, time parsing, formatting
│   │   └── paths.py         # app/data folder locations
│   └── ui/                  # PySide6 interface
│       ├── main_window.py   # header, tabs, tray notifications, shutdown
│       ├── url_tab.py, converter_tab.py, manager_tab.py, settings_tab.py
│       ├── widgets.py, dialogs.py, theme.py, icons.py
│       ├── bridge.py        # thread-safe worker -> GUI signals
│       └── context.py       # shared app state
├── tests/                   # pytest suite (core + GUI)
├── tools/
│   ├── create_shortcut.ps1  # Desktop + Start Menu shortcuts
│   ├── fetch_ffmpeg.ps1     # Download FFmpeg to bundle into the .exe
│   ├── make_icon.py         # Regenerate assets/app.ico
│   └── manual_download_check.py  # Test a real URL end-to-end
└── vendor/                  # (optional) vendor\ffmpeg\bin\ffmpeg.exe, ffprobe.exe
```

---

## 3. Installation on Windows 11

### Option A: easy setup from source (recommended for personal use)
1. Install **Python 3.12 or newer** from <https://www.python.org/downloads/windows/>. Tick **"Add python.exe to PATH"**. Or run `winget install Python.Python.3.12`.
2. Unzip `VideoToMP3.zip` to a permanent folder, for example `C:\Apps\VideoToMP3`.
3. Double-click **`install.bat`**. It:
   - creates a private virtual environment (`.venv`);
   - installs PySide6, yt-dlp and imageio-ffmpeg;
   - optionally installs the full FFmpeg build with winget;
   - creates **Desktop** and **Start Menu** shortcuts.
4. Start the app from the **"Video to MP3 Converter"** desktop shortcut. No command prompt opens: it runs with `pythonw.exe`.

To launch it some other way, double-click `run.bat` or `VideoToMP3.pyw`.

### Option B: standalone `.exe` (no Python needed on the target PC)
On a build PC with Python 3.12+:
```bat
build_exe.bat                 :: bundles the imageio-ffmpeg FFmpeg binary
build_exe.bat --with-ffmpeg   :: downloads and bundles the full FFmpeg + FFprobe build
```
- Result: `dist\VideoToMP3\VideoToMP3.exe`, plus a desktop shortcut to it.
- You can copy the whole `dist\VideoToMP3` folder to any Windows 10/11 x64 PC.
- **Installer (optional):** install [Inno Setup](https://jrsoftware.org/isinfo.php), open `installer\VideoToMP3.iss` and press **Compile**. This produces `installer\Output\VideoToMP3-Setup-1.0.0.exe`, with Start Menu and Desktop shortcuts and an uninstaller.

The build commands run manually:
```bat
py -3 -m venv .venv
.venv\Scripts\pip install -r requirements.txt -r requirements-dev.txt
.venv\Scripts\pyinstaller --noconfirm --clean VideoToMP3.spec
```

### Creating a desktop shortcut manually
- **From source:** `powershell -ExecutionPolicy Bypass -File tools\create_shortcut.ps1 -Mode source`
- **For the .exe:** `powershell -ExecutionPolicy Bypass -File tools\create_shortcut.ps1 -Mode exe`
- **By hand:** right-click `dist\VideoToMP3\VideoToMP3.exe` → *Show more options* → *Send to* → *Desktop (create shortcut)*.

---

## 4. FFmpeg installation and configuration

FFmpeg is **required** for conversions and audio downloads. MP4 downloads need it to merge the best video and audio streams. Without it, only pre-merged formats are downloaded.

You usually don't need to do anything: `requirements.txt` includes **imageio-ffmpeg**, which ships a working `ffmpeg.exe` that the app detects automatically. A full install adds `ffprobe`, used for faster and more detailed media inspection. Pick any one of these:

1. **winget** (easiest): `winget install Gyan.FFmpeg`. Restart the app afterwards.
2. **Manual:**
   - Download *ffmpeg-release-essentials.zip* from <https://www.gyan.dev/ffmpeg/builds/>.
   - Extract it to `C:\ffmpeg` so that `C:\ffmpeg\bin\ffmpeg.exe` exists.
   - Either add `C:\ffmpeg\bin` to PATH (*Settings → System → About → Advanced system settings → Environment Variables → Path → New*) or set it in the app under **Settings → Custom FFmpeg location**.
3. **Bundled with the .exe:** run `build_exe.bat --with-ffmpeg`, or put `ffmpeg.exe`/`ffprobe.exe` in `vendor\ffmpeg\bin` before building.

To verify, open **Settings → Dependencies**. It shows the version, source and path, and has a **Re-check Dependencies** button. The header badge reads **"FFmpeg & yt-dlp ready"** when everything is found. If FFmpeg is missing, conversions are blocked with a clear message, and failed tasks can be **Retried** after installing it.

**yt-dlp** is installed as a Python package. Websites change often, so if downloads from a site start failing, update it:
- from source: `.venv\Scripts\pip install -U yt-dlp`;
- for the .exe: rebuild it with `build_exe.bat`.

---

## 5. What depends on external tools or website permissions

| Feature | Depends on |
|---|---|
| All conversions, audio downloads, trimming, metadata, cover art | **FFmpeg** (auto-detected or bundled) |
| URL analysis and downloads | **yt-dlp**, plus the website allowing public access to the media |
| YouTube / Facebook / Instagram / TikTok / Vimeo, etc. | Works only for **publicly accessible** videos that the site's yt-dlp extractor supports. Private, age-restricted, members-only, paid, geo-blocked or **DRM-protected** content is refused with an explanation. Sites sometimes add bot checks or change their pages; updating yt-dlp usually fixes this. |
| Thumbnail preview and cover art for URLs | Only if the site provides a thumbnail |
| MP4 resolution choice | The resolutions the site offers. Without FFmpeg, only pre-merged formats are available. |
| Desktop notifications | The Windows notification area (system tray). They can be turned off in Settings. |

---

## 6. Testing

```bat
.venv\Scripts\pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest
```
The suite has 50 tests and generates its own sample videos with FFmpeg. It covers:
- MP4→MP3, MKV→MP3, and every input type (MP4/MOV/AVI/MKV/WMV/FLV/WEBM) in one **batch** run.
- **320 kbps** export (bitrate checked with ffprobe), and stream copy in "Original quality" mode.
- WAV, AAC, FLAC and M4A outputs.
- Unicode file names, renaming, metadata and cover-art embedding, trimming.
- No overwrite without confirmation.
- **Downloads** through yt-dlp from a local HTTP server: MP3 and MP4, **cancellation mid-download**, 404 failure, then **retry**.
- Friendly error messages, plus corrupt, silent and missing input files.
- **Missing FFmpeg** handling and recovery after installing it; the imageio-ffmpeg fallback without ffprobe.
- **GUI tests** (offscreen):
  - batch conversion through the real window, checking that the event loop stays responsive (no block over 500 ms);
  - cancel from the Download Manager;
  - URL analysis and download;
  - the missing-FFmpeg warning;
  - theme switching.

To check a real website from your own PC:
```bat
.venv\Scripts\python tools\manual_download_check.py "https://vimeo.com/<public-video-id>"
```

---

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| "FFmpeg was not found" | See section 4, then go to Settings → **Re-check Dependencies** and press **Retry** on failed tasks. |
| "website refused (HTTP 403)" / "bot check" | Update yt-dlp. Some videos simply can't be downloaded without signing in, which this app deliberately doesn't do. |
| "This content requires signing in" / "DRM" | The content isn't publicly downloadable. This is intended behaviour. |
| Network / proxy errors | Check your internet connection, VPN, firewall or proxy. |
| Something else | Logs are in `%APPDATA%\VideoToMP3\logs\app.log`. |

## License notes
- This app's source is yours to use.
- **PySide6** is LGPLv3.
- **yt-dlp** is Unlicense.
- **FFmpeg** builds are LGPL/GPL. If you redistribute a bundled FFmpeg, include its license; `fetch_ffmpeg.ps1` copies it next to the binaries.
