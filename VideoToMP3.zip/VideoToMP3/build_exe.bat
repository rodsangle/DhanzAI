@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build VideoToMP3.exe

rem Usage:  build_exe.bat              -> uses imageio-ffmpeg as the bundled FFmpeg
rem         build_exe.bat --with-ffmpeg -> downloads a full FFmpeg build (ffmpeg + ffprobe) and bundles it

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY set "PY=python"
if not exist ".venv\Scripts\python.exe" (
    %PY% -m venv .venv || goto :fail
)
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt -r requirements-dev.txt || goto :fail

if /I "%~1"=="--with-ffmpeg" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\fetch_ffmpeg.ps1" || goto :fail
)

".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean VideoToMP3.spec || goto :fail

echo.
echo Build complete: %CD%\dist\VideoToMP3\VideoToMP3.exe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\create_shortcut.ps1" -Mode exe
echo A Desktop shortcut to the .exe was created.
echo Optional: compile installer\VideoToMP3.iss with Inno Setup to get a Setup.exe installer.
pause
exit /b 0

:fail
echo Build failed - see the messages above.
pause
exit /b 1
