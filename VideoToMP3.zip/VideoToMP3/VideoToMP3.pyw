"""Double-click launcher (runs with pythonw.exe, so no console window appears)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import main  # noqa: E402

sys.exit(main())
