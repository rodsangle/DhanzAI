@echo off
rem Launch from source without a console window (after running install.bat once).
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Please run install.bat first.
    pause
    exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" "%~dp0VideoToMP3.pyw"
