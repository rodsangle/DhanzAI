"""GUI tests (offscreen): drive the real main window end-to-end and check responsiveness."""

from __future__ import annotations

import os
import time
from pathlib import Path

import pytest

pytest.importorskip("PySide6")

from PySide6.QtCore import QElapsedTimer, QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.core.dependencies import Dependencies, DependencyStatus  # noqa: E402
from app.core.history import History  # noqa: E402
from app.core.jobs import JobStatus  # noqa: E402
from app.core.settings import Settings  # noqa: E402

SHOTS = os.environ.get("VTM_SCREENSHOT_DIR")


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture
def window(qapp, deps, tmp_path, monkeypatch):
    from app.ui import icons, theme
    from app.ui.context import AppContext
    from app.ui.main_window import MainWindow

    settings = Settings.load(tmp_path / "settings.json")
    settings.download_dir = str(tmp_path / "Music Out")
    theme.apply_theme(qapp, settings.theme)
    icons.set_theme_color(theme.colors(settings.theme)["text"])
    ctx = AppContext(settings, History(tmp_path / "history.db"), deps)
    win = MainWindow(ctx)
    win.resize(1180, 860)
    win.show()
    # Never block on modal dialogs during tests.
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    yield win
    ctx.manager.shutdown()
    win.close()


def pump(qapp, seconds: float, until=None) -> None:
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        qapp.processEvents()
        if until and until():
            return
        time.sleep(0.01)


def shot(win, name):
    if SHOTS:
        Path(SHOTS).mkdir(parents=True, exist_ok=True)
        win.grab().save(str(Path(SHOTS) / f"{name}.png"))


def test_tabs_exist(window):
    titles = [window.tabs.tabText(i) for i in range(window.tabs.count())]
    assert titles == ["URL Downloader", "Video Converter", "Download Manager", "Settings"]
    assert window.dep_badge.property("ok") is True


def test_gui_batch_conversion_and_responsiveness(qapp, window, media_dir):
    tab = window.converter_tab
    window.tabs.setCurrentWidget(tab)
    files = [str(media_dir / n) for n in ("sample.mp4", "sample.mkv", "Ünïcödé 日本語 ♫.mp4")]
    tab.add_files(files)
    tab.add_files([files[0]])  # duplicates are ignored
    assert tab.table.rowCount() == 3
    pump(qapp, 5, until=lambda: tab.table.item(0, 1).text() not in ("…", ""))
    assert tab.table.item(0, 1).text() == "0:06"
    tab.quality_combo.setCurrentIndex(tab.quality_combo.findData("320"))
    tab.table.item(1, 4).setText("Renamed output")
    shot(window, "2_converter")
    tab.convert()
    assert window.tabs.currentWidget() is window.manager_tab

    # Measure event-loop latency while conversions run: a 20 ms timer must keep firing.
    gaps, timer, clock = [], QTimer(), QElapsedTimer()
    clock.start()

    def tick():
        gaps.append(clock.restart())

    timer.timeout.connect(tick)
    timer.start(20)
    mgr = window.ctx.manager
    pump(qapp, 60, until=lambda: all(j.status.finished for j in mgr.jobs))
    timer.stop()
    assert all(j.status == JobStatus.COMPLETED for j in mgr.jobs), [j.error for j in mgr.jobs]
    assert len(gaps) > 5 and max(gaps) < 500, f"UI blocked for {max(gaps)} ms"
    out = Path(window.ctx.settings.download_dir)
    assert {p.name for p in out.glob("*.mp3")} == {"sample.mp3", "Renamed output.mp3", "Ünïcödé 日本語 ♫.mp3"}
    pump(qapp, 0.3)
    assert len(window.manager_tab.completed.cards) == 3
    assert window.manager_tab.history.rowCount() == 3
    window.manager_tab.tabs.setCurrentIndex(1)
    shot(window, "3_manager_completed")
    window.manager_tab.tabs.setCurrentIndex(2)
    shot(window, "3_manager_history")


def test_gui_cancel_and_retry(qapp, window, media_dir):
    tab = window.converter_tab
    tab.add_files([str(media_dir / "long.mkv")])
    tab.convert()
    mgr = window.ctx.manager
    job = mgr.jobs[0]
    pump(qapp, 20, until=lambda: (job.progress or 0) > 2)
    window.manager_tab.tabs.setCurrentIndex(0)
    pump(qapp, 0.3)
    shot(window, "3_manager_active")
    card = window.manager_tab.active.cards[job.id]
    assert card.btn_cancel.isVisible()
    card.btn_cancel.click()
    pump(qapp, 10, until=lambda: job.status.finished)
    pump(qapp, 0.3)
    assert job.status == JobStatus.CANCELLED
    assert card.btn_retry.isVisible() and not card.btn_cancel.isVisible()
    assert not list(Path(window.ctx.settings.download_dir).glob("*.mp3"))


def test_gui_missing_ffmpeg(qapp, window, media_dir, monkeypatch):
    ctx = window.ctx
    ctx.deps = Dependencies(DependencyStatus("FFmpeg", False, detail="FFmpeg was not found."),
                            DependencyStatus("FFprobe", False), ctx.deps.ytdlp)
    ctx.deps_changed.emit()
    assert window.dep_badge.property("ok") is False
    assert "FFmpeg missing" in window.dep_badge.text()
    errors = []
    monkeypatch.setattr("app.ui.converter_tab.show_error", lambda _p, title, msg: errors.append(title))
    window.converter_tab.add_files([str(media_dir / "sample.mp4")])
    window.converter_tab.convert()
    assert errors == ["FFmpeg required"] and not ctx.manager.jobs
    window.tabs.setCurrentWidget(window.settings_tab)
    shot(window, "4_settings_ffmpeg_missing")


def test_gui_url_tab_analyze(qapp, window, media_dir):
    import functools
    import http.server
    import threading

    httpd = http.server.ThreadingHTTPServer(
        ("127.0.0.1", 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(media_dir)))
    httpd.RequestHandlerClass.log_message = lambda *a: None
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        tab = window.url_tab
        window.tabs.setCurrentWidget(tab)
        assert not tab.audio_btn.isEnabled()
        tab.url_edit.setText("not a url")
        tab.analyze()
        assert tab.message.property("role") == "error"
        tab.url_edit.setText(f"http://127.0.0.1:{httpd.server_port}/sample.mp4")
        tab.analyze()
        pump(qapp, 20, until=lambda: tab.audio_btn.isEnabled())
        assert tab.info and tab.info.title == "sample"
        assert tab.name_edit.text() == "sample"
        tab.format_combo.setCurrentIndex(tab.format_combo.findData("m4a"))
        assert tab.audio_btn.text() == "Download M4A"
        pump(qapp, 0.3)
        shot(window, "1_url_analyzed")
        tab.queue_download(video=False)
        mgr = window.ctx.manager
        pump(qapp, 30, until=lambda: mgr.jobs and all(j.status.finished for j in mgr.jobs))
        assert mgr.jobs[0].status == JobStatus.COMPLETED, mgr.jobs[0].error
        assert Path(mgr.jobs[0].output_path).name == "sample.m4a"
    finally:
        httpd.shutdown()


def test_theme_switch(qapp, window):
    st = window.settings_tab
    st.theme_combo.setCurrentIndex(st.theme_combo.findData("light"))
    assert window.ctx.settings.theme == "light"
    window.tabs.setCurrentWidget(st)
    shot(window, "5_settings_light")
    window.tabs.setCurrentWidget(window.converter_tab)
    shot(window, "5_converter_light")
    st.theme_combo.setCurrentIndex(st.theme_combo.findData("dark"))
