"""Shared fixtures: generate small sample videos with FFmpeg and provide detected dependencies."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
# Local test servers must not go through any HTTP proxy.
for var in ("no_proxy", "NO_PROXY"):
    os.environ[var] = ",".join(filter(None, [os.environ.get(var, ""), "127.0.0.1", "localhost"]))

from app.core.dependencies import detect_all  # noqa: E402


@pytest.fixture(scope="session")
def deps():
    d = detect_all()
    if not d.ffmpeg.found:
        pytest.skip("FFmpeg is required for these tests")
    return d


def _make(ffmpeg: str, out: Path, seconds: float, vcodec: list[str], acodec: list[str]) -> Path:
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
           "-f", "lavfi", "-i", f"testsrc=size=320x240:rate=15:duration={seconds}",
           "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=44100:duration={seconds}",
           "-shortest", *vcodec, *acodec, str(out)]
    subprocess.run(cmd, check=True)
    return out


@pytest.fixture(scope="session")
def media_dir(tmp_path_factory, deps) -> Path:
    d = tmp_path_factory.mktemp("media")
    ff = deps.ffmpeg_path
    _make(ff, d / "sample.mp4", 6, ["-c:v", "mpeg4"], ["-c:a", "aac", "-b:a", "128k"])
    _make(ff, d / "sample.mkv", 6, ["-c:v", "mpeg4"], ["-c:a", "libmp3lame", "-b:a", "128k"])
    _make(ff, d / "sample.avi", 4, ["-c:v", "mpeg4"], ["-c:a", "libmp3lame"])
    _make(ff, d / "sample.mov", 4, ["-c:v", "mpeg4"], ["-c:a", "aac"])
    _make(ff, d / "sample.webm", 4, ["-c:v", "libvpx", "-b:v", "200k"], ["-c:a", "libopus"])
    _make(ff, d / "sample.flv", 4, ["-c:v", "flv"], ["-c:a", "libmp3lame", "-ar", "44100"])
    _make(ff, d / "sample.wmv", 4, ["-c:v", "wmv2"], ["-c:a", "wmav2"])
    _make(ff, d / "Ünïcödé 日本語 ♫.mp4", 3, ["-c:v", "mpeg4"], ["-c:a", "aac"])
    # Long-ish audio-only file used for cancellation tests (fast to generate, slow enough to convert).
    subprocess.run([ff, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                    "-i", "anoisesrc=d=1500:c=pink:r=44100", "-c:a", "flac", "-compression_level", "0",
                    str(d / "long.mkv")], check=True)
    # Video without audio and a corrupt file for error handling.
    subprocess.run([ff, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                    "-i", "testsrc=size=160x120:rate=10:duration=2", "-c:v", "mpeg4",
                    str(d / "silent.mp4")], check=True)
    (d / "corrupt.mp4").write_bytes(b"this is not a video" * 500)
    # A cover image.
    subprocess.run([ff, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                    "-i", "color=c=blue:s=300x300", "-frames:v", "1", str(d / "cover.png")], check=True)
    return d


@pytest.fixture
def out_dir(tmp_path) -> Path:
    d = tmp_path / "out ♪ folder"
    d.mkdir()
    return d


def ffprobe_json(deps, path):
    import json

    probe = deps.ffprobe_path or shutil.which("ffprobe")
    res = subprocess.run([probe, "-v", "error", "-print_format", "json", "-show_format",
                          "-show_streams", str(path)], capture_output=True, check=True)
    return json.loads(res.stdout)
