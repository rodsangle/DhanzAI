"""Download tests using a local HTTP server (generic yt-dlp extractor), so they are
reproducible offline. A real public website can be checked with tools/manual_download_check.py."""

from __future__ import annotations

import functools
import http.server
import threading
import time

import pytest

from app.core import downloader
from app.core.jobs import Job, JobKind, JobManager, JobOptions, JobStatus
from tests.conftest import ffprobe_json


class _Handler(http.server.SimpleHTTPRequestHandler):
    throttle = False

    def log_message(self, *args):
        pass

    def copyfile(self, source, outputfile):
        if not self.throttle:
            return super().copyfile(source, outputfile)
        while chunk := source.read(16 * 1024):  # ~160 KB/s: slow enough to cancel mid-download
            outputfile.write(chunk)
            time.sleep(0.1)


@pytest.fixture(scope="module")
def server(media_dir):
    def start(throttle):
        handler = type("H", (_Handler,), {"throttle": throttle})
        httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0),
                                                functools.partial(handler, directory=str(media_dir)))
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        return httpd

    fast, slow = start(False), start(True)
    yield {"fast": f"http://127.0.0.1:{fast.server_port}", "slow": f"http://127.0.0.1:{slow.server_port}"}
    fast.shutdown()
    slow.shutdown()


def url_job(url, out_dir, **opts):
    name = opts.pop("output_name", "Downloaded")
    return Job(JobKind.DOWNLOAD, url, name, JobOptions(str(out_dir), name, **opts))


def test_analyze(server):
    info = downloader.analyze_url(server["fast"] + "/sample.mp4")
    assert info.title == "sample"
    assert info.has_audio


def test_analyze_errors(server):
    with pytest.raises(downloader.DownloadError, match="unavailable"):
        downloader.analyze_url(server["fast"] + "/does-not-exist.mp4")
    with pytest.raises(downloader.DownloadError, match="(?i)network"):
        downloader.analyze_url("http://127.0.0.1:9/video.mp4")  # nothing listens on port 9


def test_download_mp3(deps, server, out_dir):
    job = url_job(server["fast"] + "/sample.mp4", out_dir, fmt="mp3", quality="320",
                  output_name="My Video ♫", title="My Video", artist="Uploader")
    mgr = JobManager(lambda: deps, 2)
    mgr.add(job)
    assert mgr.wait_all(60)
    assert job.status == JobStatus.COMPLETED, job.error
    out = out_dir / "My Video ♫.mp3"
    assert job.output_path == str(out)
    info = ffprobe_json(deps, out)
    assert [s["codec_name"] for s in info["streams"]] == ["mp3"]
    assert info["format"]["tags"]["title"] == "My Video"
    assert sorted(p.name for p in out_dir.iterdir()) == ["My Video ♫.mp3"]  # work dir cleaned


def test_download_mp4(deps, server, out_dir):
    job = url_job(server["fast"] + "/sample.mp4", out_dir, fmt="mp4", video_height=720)
    mgr = JobManager(lambda: deps, 2)
    mgr.add(job)
    assert mgr.wait_all(60)
    assert job.status == JobStatus.COMPLETED, job.error
    out = out_dir / "Downloaded.mp4"
    assert out.is_file()
    assert {s["codec_type"] for s in ffprobe_json(deps, out)["streams"]} == {"video", "audio"}


def test_download_cancel_then_retry(deps, server, out_dir):
    job = url_job(server["slow"] + "/long.mkv", out_dir, fmt="mp3")
    mgr = JobManager(lambda: deps, 1)
    mgr.add(job)
    deadline = time.monotonic() + 30
    while not (job.phase == "Downloading" and job.progress and job.speed) and time.monotonic() < deadline:
        time.sleep(0.05)
    assert job.phase == "Downloading" and job.speed  # speed is reported while downloading
    mgr.cancel(job.id)
    assert mgr.wait_all(20)
    assert job.status == JobStatus.CANCELLED
    assert not list(out_dir.iterdir()), "cancelled download must not leave files"
    # Failure recovery: retry runs the whole job again from scratch.
    job.source = server["fast"] + "/sample.mkv"
    mgr.retry(job.id)
    assert mgr.wait_all(60)
    assert job.status == JobStatus.COMPLETED, job.error
    assert (out_dir / "Downloaded.mp3").is_file()


def test_failed_download_reports_friendly_error(deps, server, out_dir):
    job = url_job(server["fast"] + "/gone.mp4", out_dir, fmt="mp3")
    mgr = JobManager(lambda: deps, 1)
    mgr.add(job)
    assert mgr.wait_all(30)
    assert job.status == JobStatus.FAILED
    assert "unavailable" in job.error
    assert not list(out_dir.iterdir())


def test_friendly_error_mapping():
    fe = downloader.friendly_error
    assert "DRM" in fe("ERROR: This video is DRM protected")
    assert "private" in fe("ERROR: [youtube] abc: Private video. Sign in if you've been granted access")
    assert "signing in" in fe("ERROR: [instagram] x: login required")
    assert "Network" in fe("ERROR: Unable to download webpage: <urlopen error [Errno 11001] getaddrinfo failed>")
    assert "not supported" in fe("ERROR: Unsupported URL: https://example.com")
    assert "proxy" in fe("ERROR: Unable to download JSON metadata: ('Unable to connect to proxy', "
                         "OSError('Tunnel connection failed: 403 Forbidden'))")


def test_format_selector():
    assert downloader.video_format_selector(720, True).startswith("bv*[ext=mp4][height<=720]+ba[ext=m4a]")
    assert "+" not in downloader.video_format_selector(720, False)  # no merging without FFmpeg
