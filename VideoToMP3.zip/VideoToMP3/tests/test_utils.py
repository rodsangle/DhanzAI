
import pytest

from app.core.utils import format_duration, parse_time, sanitize_filename, unique_path
from app.core.validators import (ValidationError, collect_video_files, validate_input_file,
                                 validate_output_dir, validate_url)


@pytest.mark.parametrize("text,expected", [
    ("", None), ("  ", None), ("90", 90.0), ("1:30", 90.0), ("01:02:03", 3723.0),
    ("0:00:01.5", 1.5), ("2,5", 2.5),
])
def test_parse_time(text, expected):
    assert parse_time(text) == expected


@pytest.mark.parametrize("bad", ["abc", "1:75", "1::2", "-5", "1:2:3:4"])
def test_parse_time_invalid(bad):
    with pytest.raises(ValueError):
        parse_time(bad)


def test_format_duration():
    assert format_duration(65) == "1:05"
    assert format_duration(3723) == "1:02:03"
    assert format_duration(None) == "--:--"


def test_sanitize_filename_keeps_unicode_and_strips_invalid():
    assert sanitize_filename('Café: "Live" <2024> / 日本語?') == "Café_ _Live_ _2024_ _ 日本語_"
    assert sanitize_filename("CON") == "output_CON"
    assert sanitize_filename("  trailing dots... ") == "trailing dots"
    assert sanitize_filename("") == "output"
    assert len(sanitize_filename("x" * 400)) == 150


def test_unique_path(tmp_path):
    p = tmp_path / "song.mp3"
    assert unique_path(p) == p
    p.write_text("x")
    assert unique_path(p).name == "song (1).mp3"
    (tmp_path / "song (1).mp3").write_text("x")
    assert unique_path(p).name == "song (2).mp3"


def test_validate_url():
    assert validate_url("youtube.com/watch?v=abc") == "https://youtube.com/watch?v=abc"
    assert validate_url(" https://vimeo.com/1 ") == "https://vimeo.com/1"
    for bad in ["", "ftp://x.com/a", "not a url", "http://", "javascript:alert(1)"]:
        with pytest.raises(ValidationError):
            validate_url(bad)


def test_validate_files(tmp_path):
    txt = tmp_path / "notes.txt"
    txt.write_text("hello")
    with pytest.raises(ValidationError, match="Unsupported"):
        validate_input_file(txt)
    with pytest.raises(ValidationError, match="not found"):
        validate_input_file(tmp_path / "missing.mp4")
    empty = tmp_path / "empty.mkv"
    empty.touch()
    with pytest.raises(ValidationError, match="empty"):
        validate_input_file(empty)
    vid = tmp_path / "Clip.MKV"
    vid.write_bytes(b"x")
    assert validate_input_file(vid) == vid
    files, rejected = collect_video_files([tmp_path])
    assert vid in files and empty in files
    files, rejected = collect_video_files([txt])
    assert rejected == ["notes.txt"]


def test_validate_output_dir(tmp_path):
    new = tmp_path / "a" / "b"
    assert validate_output_dir(new) == new and new.is_dir()
    f = tmp_path / "file"
    f.write_text("x")
    with pytest.raises(ValidationError):
        validate_output_dir(f)
    with pytest.raises(ValidationError):
        validate_output_dir("   ")
