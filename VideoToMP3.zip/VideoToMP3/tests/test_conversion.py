"""Conversion tests: real FFmpeg runs on generated sample videos."""

from __future__ import annotations

import time

import pytest

from app.core.dependencies import Dependencies, DependencyStatus
from app.core.ffmpeg import probe
from app.core.jobs import Job, JobKind, JobManager, JobOptions, JobStatus
from tests.conftest import ffprobe_json


def make_job(src, out_dir, **opts):
    name = opts.pop("output_name", src.stem)
    return Job(JobKind.CONVERT, str(src), src.name, JobOptions(str(out_dir), name, **opts))


def run_jobs(deps, *jobs, max_concurrent=2, timeout=120):
    mgr = JobManager(lambda: deps, max_concurrent)
    for j in jobs:
        mgr.add(j)
    assert mgr.wait_all(timeout), "jobs did not finish in time"
    return mgr


def audio_stream(info):
    return next(s for s in info["streams"] if s["codec_type"] == "audio")


def test_probe(deps, media_dir):
    info = probe(media_dir / "sample.mp4", deps.ffmpeg_path, deps.ffprobe_path)
    assert info.has_audio and info.has_video and info.audio_codec == "aac"
    assert info.duration == pytest.approx(6, abs=0.2)
    # Fallback parser (no ffprobe) gives the same essentials.
    info2 = probe(media_dir / "sample.mkv", deps.ffmpeg_path, None)
    assert info2.has_audio and info2.audio_codec == "mp3"
    assert info2.duration == pytest.approx(6, abs=0.2)


def test_mp4_to_mp3(deps, media_dir, out_dir):
    job = make_job(media_dir / "sample.mp4", out_dir, fmt="mp3", quality="192")
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    out = out_dir / "sample.mp3"
    assert job.output_path == str(out) and out.is_file()
    info = ffprobe_json(deps, out)
    assert [s["codec_type"] for s in info["streams"]] == ["audio"]  # video dropped
    assert audio_stream(info)["codec_name"] == "mp3"
    assert float(info["format"]["duration"]) == pytest.approx(6, abs=0.3)
    assert not list(out_dir.glob(".vtm_work_*"))  # temp folders cleaned up


def test_mkv_to_mp3_320kbps(deps, media_dir, out_dir):
    job = make_job(media_dir / "sample.mkv", out_dir, fmt="mp3", quality="320")
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    stream = audio_stream(ffprobe_json(deps, out_dir / "sample.mp3"))
    assert stream["codec_name"] == "mp3"
    assert int(stream["bit_rate"]) == 320000


def test_original_quality_stream_copy(deps, media_dir, out_dir):
    # MKV contains MP3 audio: "original" must copy it bit-for-bit (128 kbps preserved, no re-encode).
    job = make_job(media_dir / "sample.mkv", out_dir, fmt="mp3", quality="original")
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    assert int(audio_stream(ffprobe_json(deps, out_dir / "sample.mp3"))["bit_rate"]) == 128000


@pytest.mark.parametrize("fmt,codec", [("wav", "pcm_s16le"), ("aac", "aac"), ("flac", "flac"), ("m4a", "aac")])
def test_other_output_formats(deps, media_dir, out_dir, fmt, codec):
    job = make_job(media_dir / "sample.mp4", out_dir, fmt=fmt, quality="256")
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    out = out_dir / f"sample.{fmt}"
    assert audio_stream(ffprobe_json(deps, out))["codec_name"] == codec


def test_batch_all_input_types(deps, media_dir, out_dir):
    names = ["sample.mp4", "sample.mkv", "sample.avi", "sample.mov", "sample.webm", "sample.flv", "sample.wmv"]
    jobs = [make_job(media_dir / n, out_dir, fmt="mp3", quality="128", output_name=n.replace(".", "_"))
            for n in names]
    t0 = time.monotonic()
    mgr = run_jobs(deps, *jobs, max_concurrent=3)
    for j in jobs:
        assert j.status == JobStatus.COMPLETED, f"{j.source}: {j.error}"
        assert (out_dir / (j.options.output_name + ".mp3")).is_file()
    assert len(list(out_dir.glob("*.mp3"))) == len(names)
    assert mgr.active_count() == 0
    assert time.monotonic() - t0 < 60


def test_unicode_filename_metadata_cover_and_rename(deps, media_dir, out_dir):
    src = media_dir / "Ünïcödé 日本語 ♫.mp4"
    job = make_job(src, out_dir, fmt="mp3", quality="192", output_name="Mi canción: «remix»",
                   title="Título ♫", artist="Artista 日本", album="Álbum",
                   cover_path=str(media_dir / "cover.png"))
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    out = out_dir / "Mi canción_ «remix».mp3"
    assert out.is_file()
    info = ffprobe_json(deps, out)
    tags = {k.lower(): v for k, v in info["format"]["tags"].items()}
    assert tags["title"] == "Título ♫" and tags["artist"] == "Artista 日本" and tags["album"] == "Álbum"
    pics = [s for s in info["streams"] if s["codec_type"] == "video"]
    assert pics and pics[0]["disposition"]["attached_pic"] == 1


def test_trim(deps, media_dir, out_dir):
    job = make_job(media_dir / "sample.mp4", out_dir, fmt="mp3", start=1.0, end=3.5)
    run_jobs(deps, job)
    assert job.status == JobStatus.COMPLETED, job.error
    assert float(ffprobe_json(deps, out_dir / "sample.mp3")["format"]["duration"]) == pytest.approx(2.5, abs=0.15)


def test_invalid_trim_rejected(deps, media_dir, out_dir):
    job = make_job(media_dir / "sample.mp4", out_dir, start=4, end=2)
    run_jobs(deps, job)
    assert job.status == JobStatus.FAILED and "end time" in job.error


def test_no_overwrite_without_confirmation(deps, media_dir, out_dir):
    existing = out_dir / "sample.mp3"
    existing.write_bytes(b"keep me")
    job = make_job(media_dir / "sample.mp4", out_dir)
    run_jobs(deps, job)
    assert existing.read_bytes() == b"keep me"
    assert job.output_path.endswith("sample (1).mp3")
    # With explicit confirmation the file is replaced.
    job2 = make_job(media_dir / "sample.mp4", out_dir, overwrite=True)
    run_jobs(deps, job2)
    assert job2.output_path == str(existing) and existing.stat().st_size > 1000


def test_error_messages(deps, media_dir, out_dir):
    corrupt = make_job(media_dir / "corrupt.mp4", out_dir)
    silent = make_job(media_dir / "silent.mp4", out_dir)
    missing = make_job(media_dir / "missing.mp4", out_dir)
    run_jobs(deps, corrupt, silent, missing)
    assert corrupt.status == JobStatus.FAILED and "damaged" in corrupt.error
    assert silent.status == JobStatus.FAILED and "no audio" in silent.error
    assert missing.status == JobStatus.FAILED and "no longer exists" in missing.error
    assert not list(out_dir.iterdir())  # nothing half-written left behind


def test_cancel_and_retry(deps, media_dir, out_dir):
    mgr = JobManager(lambda: deps, 1)
    job = make_job(media_dir / "long.mkv", out_dir, fmt="mp3", quality="320")
    queued = make_job(media_dir / "sample.mp4", out_dir)
    mgr.add(job)
    mgr.add(queued)
    deadline = time.monotonic() + 30
    while not (job.progress or 0) > 1 and time.monotonic() < deadline:
        time.sleep(0.05)
    assert job.status == JobStatus.RUNNING and job.progress > 1 and job.eta
    assert queued.status == JobStatus.QUEUED  # concurrency limit respected
    mgr.cancel(queued.id)
    mgr.cancel(job.id)
    assert mgr.wait_all(15)
    assert job.status == JobStatus.CANCELLED and queued.status == JobStatus.CANCELLED
    assert not list(out_dir.iterdir()), "cancelled job must not leave partial files"
    mgr.retry(queued.id)
    assert mgr.wait_all(60)
    assert queued.status == JobStatus.COMPLETED and queued.attempts == 1


def test_missing_ffmpeg_reported_and_recoverable(deps, media_dir, out_dir):
    missing = Dependencies(DependencyStatus("FFmpeg", False), DependencyStatus("FFprobe", False), deps.ytdlp)
    current = {"deps": missing}
    mgr = JobManager(lambda: current["deps"], 1)
    job = mgr.add(make_job(media_dir / "sample.mp4", out_dir))
    assert mgr.wait_all(10)
    assert job.status == JobStatus.FAILED and "FFmpeg was not found" in job.error
    current["deps"] = deps  # user installs FFmpeg, then presses Retry
    mgr.retry(job.id)
    assert mgr.wait_all(60)
    assert job.status == JobStatus.COMPLETED


def test_history_records_jobs(deps, media_dir, out_dir, tmp_path):
    from app.core.history import History

    history = History(tmp_path / "h.db")
    mgr = JobManager(lambda: deps, 2, history)
    mgr.add(make_job(media_dir / "sample.mp4", out_dir))
    mgr.add(make_job(media_dir / "corrupt.mp4", out_dir))
    assert mgr.wait_all(60)
    entries = history.entries()
    assert sorted(e.status for e in entries) == ["Completed", "Failed"]
    ok = next(e for e in entries if e.status == "Completed")
    assert ok.size and ok.output_path.endswith("sample.mp3")
    history.clear()
    assert history.entries() == []


def test_imageio_ffmpeg_without_ffprobe(deps, media_dir, out_dir):
    """The pip-installed imageio-ffmpeg binary (no ffprobe) is a working fallback."""
    imageio_ffmpeg = pytest.importorskip("imageio_ffmpeg")
    ff = DependencyStatus("FFmpeg", True, imageio_ffmpeg.get_ffmpeg_exe(), "x", "imageio-ffmpeg package")
    fallback = Dependencies(ff, DependencyStatus("FFprobe", False), deps.ytdlp)
    job = make_job(media_dir / "sample.mkv", out_dir, fmt="mp3", quality="320", end=3)
    run_jobs(fallback, job)
    assert job.status == JobStatus.COMPLETED, job.error
    assert float(ffprobe_json(deps, out_dir / "sample.mp3")["format"]["duration"]) == pytest.approx(3, abs=0.15)
