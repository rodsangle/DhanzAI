@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Video to MP3 Converter ^& Downloader - Setup

echo ==============================================================
echo   VIDEO TO MP3 CONVERTER ^& DOWNLOADER - one-time setup
echo ==============================================================
echo.

rem --- Locate Python 3.12+ -------------------------------------------------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto :nopython
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" || goto :oldpython

rem --- Virtual environment + dependencies ----------------------------------
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PY% -m venv .venv || goto :fail
)
echo Installing dependencies (this can take a few minutes)...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :fail

rem --- Optional: system-wide FFmpeg via winget -------------------------------
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo.
    echo FFmpeg is not on your PATH. The app will use the FFmpeg binary bundled with
    echo the imageio-ffmpeg package, which works for all conversions.
    where winget >nul 2>nul && (
        choice /C YN /M "Also install the full FFmpeg build system-wide with winget (recommended)"
        if not errorlevel 2 winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
    )
)

rem --- Shortcuts -----------------------------------------------------------
echo Creating Desktop and Start Menu shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\create_shortcut.ps1" -Mode source

echo.
echo Setup complete. Start the app from the "Video to MP3 Converter" shortcut on your Desktop.
pause
exit /b 0

:nopython
echo Python 3.12 or newer was not found.
echo Install it from https://www.python.org/downloads/windows/ (tick "Add python.exe to PATH"),
echo or run:  winget install Python.Python.3.12
pause
exit /b 1

:oldpython
echo Your Python version is too old. Python 3.12 or newer is required.
pause
exit /b 1

:fail
echo.
echo Setup failed. Check your internet connection and the messages above.
pause
exit /b 1
