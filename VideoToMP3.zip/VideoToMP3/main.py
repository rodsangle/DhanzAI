"""Entry point for the Video to MP3 Converter & Downloader."""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys
import traceback


def _setup_logging() -> str:
    from app.core.paths import user_data_dir

    log_dir = user_data_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "app.log"
    handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    if sys.stderr is not None and not getattr(sys, "frozen", False):
        root.addHandler(logging.StreamHandler())
    return str(log_file)


def main() -> int:
    # pythonw.exe / windowed PyInstaller builds have no console streams.
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115

    from app import APP_DISPLAY_NAME, APP_NAME, __version__

    log_file = _setup_logging()
    log = logging.getLogger("main")
    log.info("Starting %s %s", APP_DISPLAY_NAME, __version__)

    if sys.platform == "win32":
        try:  # own taskbar icon/grouping and correct notification source on Windows 11
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"{APP_NAME}.Desktop.1")
        except Exception:  # noqa: BLE001
            pass

    from PySide6.QtWidgets import QApplication, QMessageBox

    from app.core.history import History
    from app.core.settings import Settings
    from app.ui import icons, theme
    from app.ui.context import AppContext
    from app.ui.main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_DISPLAY_NAME)
    app.setApplicationVersion(__version__)
    app.setWindowIcon(icons.app_icon())

    def excepthook(exc_type, exc, tb):
        log.error("Unhandled error:\n%s", "".join(traceback.format_exception(exc_type, exc, tb)))
        QMessageBox.critical(None, "Unexpected error",
                             f"An unexpected error occurred:\n\n{exc}\n\nDetails were written to:\n{log_file}")

    sys.excepthook = excepthook

    settings = Settings.load()
    theme.apply_theme(app, settings.theme)
    icons.set_theme_color(theme.colors(settings.theme)["text"])
    history = History()
    ctx = AppContext(settings, history)
    window = MainWindow(ctx)
    window.show()
    code = app.exec()
    history.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
