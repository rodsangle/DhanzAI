; Inno Setup script (https://jrsoftware.org/isinfo.php).
; 1) Run build_exe.bat   2) Open this file in Inno Setup and press Compile
; Output: installer\Output\VideoToMP3-Setup-1.0.0.exe

#define AppName "Video to MP3 Converter & Downloader"
#define AppVersion "1.0.0"
#define AppExe "VideoToMP3.exe"

[Setup]
AppId={{6C0E1A0B-8F64-4F5B-9E0A-2C5B7C9D1E31}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=VideoToMP3
DefaultDirName={autopf}\VideoToMP3
DefaultGroupName={#AppName}
UninstallDisplayIcon={app}\{#AppExe}
OutputDir=Output
OutputBaseFilename=VideoToMP3-Setup-{#AppVersion}
SetupIconFile=..\assets\app.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
MinVersion=10.0

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "..\dist\VideoToMP3\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Video to MP3 Converter"; Filename: "{app}\{#AppExe}"
Name: "{group}\Uninstall Video to MP3 Converter"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Video to MP3 Converter"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,Video to MP3 Converter}"; Flags: nowait postinstall skipifsilent
