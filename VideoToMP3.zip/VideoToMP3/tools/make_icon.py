"""Render the SVG logo to assets/app.ico and assets/app.png (run once; output is committed)."""

import io
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from PIL import Image  # noqa: E402
from PySide6.QtCore import QBuffer, QIODevice  # noqa: E402
from PySide6.QtGui import QGuiApplication  # noqa: E402

from app.ui.icons import LOGO_SVG, _render  # noqa: E402

app = QGuiApplication([])
buf = QBuffer()
buf.open(QIODevice.OpenModeFlag.WriteOnly)
_render(LOGO_SVG, 256).save(buf, "PNG")
img = Image.open(io.BytesIO(bytes(buf.data()))).convert("RGBA")
assets = ROOT / "assets"
assets.mkdir(exist_ok=True)
img.save(assets / "app.png")
img.save(assets / "app.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("wrote", assets / "app.ico")
