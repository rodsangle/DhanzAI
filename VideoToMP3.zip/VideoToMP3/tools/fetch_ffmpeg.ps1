<#
Downloads the "release essentials" FFmpeg build for Windows (gyan.dev) and copies
ffmpeg.exe + ffprobe.exe into vendor\ffmpeg\bin so build_exe.bat bundles them.
FFmpeg is licensed under the GPL/LGPL - see https://ffmpeg.org/legal.html
#>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $root "vendor\ffmpeg\bin"
$url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
$tmp = Join-Path $env:TEMP ("ffmpeg_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmp, $dest | Out-Null
try {
    Write-Host "Downloading FFmpeg from $url ..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $url -OutFile (Join-Path $tmp "ffmpeg.zip") -UseBasicParsing
    Expand-Archive -Path (Join-Path $tmp "ffmpeg.zip") -DestinationPath $tmp -Force
    $bin = Get-ChildItem -Path $tmp -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
    if (-not $bin) { throw "ffmpeg.exe not found in the archive" }
    Copy-Item (Join-Path $bin.DirectoryName "ffmpeg.exe"), (Join-Path $bin.DirectoryName "ffprobe.exe") $dest -Force
    $license = Get-ChildItem -Path $tmp -Recurse -Filter "LICENSE*" | Select-Object -First 1
    if ($license) { Copy-Item $license.FullName (Join-Path $dest "FFMPEG-LICENSE.txt") -Force }
    Write-Host "FFmpeg copied to $dest"
} finally {
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
}
