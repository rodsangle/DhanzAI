"""Manually verify a real, publicly accessible URL end-to-end (analyze + MP3 download).

Usage:  python tools/manual_download_check.py <url> [output_folder]
"""

from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.dependencies import detect_all  # noqa: E402
from app.core.downloader import DownloadError, analyze_url  # noqa: E402
from app.core.jobs import Job, JobKind, JobManager, JobOptions  # noqa: E402
from app.core.utils import format_duration, sanitize_filename  # noqa: E402


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    url = sys.argv[1]
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(tempfile.mkdtemp(prefix="vtm_check_"))
    deps = detect_all()
    print(f"FFmpeg: {deps.ffmpeg.found} ({deps.ffmpeg.version})  yt-dlp: {deps.ytdlp.version}")
    try:
        info = analyze_url(url)
    except DownloadError as exc:
        print(f"ANALYZE FAILED: {exc}")
        return 1
    print(f"Title: {info.title}\nUploader: {info.uploader}\nDuration: {format_duration(info.duration)}\n"
          f"Thumbnail: {info.thumbnail}\nResolutions: {info.heights}")
    mgr = JobManager(lambda: deps, 1)
    job = Job(JobKind.DOWNLOAD, info.url, info.title,
              JobOptions(str(out), sanitize_filename(info.title), fmt="mp3", quality="320",
                         title=info.title, artist=info.uploader))
    mgr.add(job)
    last = 0.0
    while not job.status.finished:
        if time.monotonic() - last > 1:
            print(f"  {job.phase:<12} {job.progress or 0:5.1f}%  {job.speed:>12}  ETA {job.eta}")
            last = time.monotonic()
        time.sleep(0.1)
    print(f"Result: {job.status.value} {job.error}\nOutput: {job.output_path}")
    return 0 if job.status.value == "Completed" else 1


if __name__ == "__main__":
    sys.exit(main())
