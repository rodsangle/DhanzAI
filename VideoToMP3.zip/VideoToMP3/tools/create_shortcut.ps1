<#
Creates "Video to MP3 Converter" shortcuts on the Desktop and in the Start Menu.

  -Mode source : runs the app from source with pythonw.exe (no console window)
  -Mode exe    : points to dist\VideoToMP3\VideoToMP3.exe (or -Target)
#>
param(
    [ValidateSet("source", "exe")] [string]$Mode = "exe",
    [string]$Target = ""
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$icon = Join-Path $root "assets\app.ico"

if ($Mode -eq "source") {
    $exe = Join-Path $root ".venv\Scripts\pythonw.exe"
    $arguments = '"' + (Join-Path $root "VideoToMP3.pyw") + '"'
    $workDir = $root
} else {
    $exe = if ($Target) { $Target } else { Join-Path $root "dist\VideoToMP3\VideoToMP3.exe" }
    $arguments = ""
    $workDir = Split-Path -Parent $exe
    $icon = $exe
}
if (-not (Test-Path $exe)) { throw "Target not found: $exe" }

$shell = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))
foreach ($dir in $places) {
    $lnk = $shell.CreateShortcut((Join-Path $dir "Video to MP3 Converter.lnk"))
    $lnk.TargetPath = $exe
    $lnk.Arguments = $arguments
    $lnk.WorkingDirectory = $workDir
    $lnk.IconLocation = "$icon,0"
    $lnk.Description = "Video to MP3 Converter & Downloader"
    $lnk.Save()
    Write-Host "Shortcut created: $($lnk.FullName)"
}
