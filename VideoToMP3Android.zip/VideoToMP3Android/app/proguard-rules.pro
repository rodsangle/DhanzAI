# --- youtubedl-android: VideoInfo/VideoFormat are filled by Jackson via reflection ---
-keep class com.yausername.** { *; }
-keepclassmembers class com.yausername.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-keepnames class com.fasterxml.jackson.** { *; }
-dontwarn com.fasterxml.jackson.databind.**
-dontwarn java.beans.**
-dontwarn org.w3c.dom.bootstrap.**
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod, RuntimeVisibleAnnotations

# --- Apache Commons (used by youtubedl-android to unzip bundled packages) ---
-dontwarn org.apache.commons.**
-keep class org.apache.commons.compress.archivers.zip.** { *; }

# --- OkHttp / Coil ---
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# --- Kotlin coroutines ---
-dontwarn kotlinx.coroutines.debug.**

# Enum names are stored in Room / DataStore.
-keepclassmembers enum com.videotomp3.** { *; }
