package com.videotomp3.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videotomp3.app.data.ThemeMode
import com.videotomp3.app.ui.components.InfoText
import com.videotomp3.app.ui.components.SectionCard
import com.videotomp3.app.ui.components.SelectorField
import com.videotomp3.app.ui.components.SwitchRow
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.TimeText

@Composable
fun SettingsScreen(snackbar: SnackbarHostState, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val folder by vm.folderLabel.collectAsStateWithLifecycle()
    val storage by vm.storageInfo.collectAsStateWithLifecycle()
    val outputBytes by vm.outputBytes.collectAsStateWithLifecycle()
    val engine by vm.engineInfo.collectAsStateWithLifecycle()
    val updating by vm.updating.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { vm.chooseFolder(it) }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        SectionCard(title = "Download folder", icon = Icons.Rounded.Folder) {
            Text(folder, style = MaterialTheme.typography.bodyLarge)
            InfoText("Default: Music/VideoToMP3 for audio and Movies/VideoToMP3 for video. Files are never overwritten – duplicates get \"(1)\", \"(2)\"… added.")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Choose folder") }
                if (s.outputFolderUri != null) TextButton(onClick = { vm.resetFolder() }) { Text("Use default") }
            }
        }

        SectionCard(title = "Conversion defaults", icon = Icons.Rounded.Tune) {
            SelectorField("Default output format", AudioFormat.entries, s.defaultFormat, { it.label }, { vm.setFormat(it) })
            SelectorField("Preferred MP3 bitrate", AudioQuality.entries, s.quality, { it.label }, { vm.setQuality(it) })
            SelectorField("Preferred video quality", listOf(2160, 1440, 1080, 720, 480, 360), s.videoHeight, { "${it}p" }, { vm.setVideoHeight(it) })
            SwitchRow("Embed album artwork", s.embedArtwork, { vm.setEmbedArtwork(it) }, subtitle = "Video frame or site thumbnail (MP3, M4A, FLAC)")
        }

        SectionCard(title = "Downloads", icon = Icons.Rounded.CloudDownload) {
            SwitchRow("Download over Wi-Fi only", s.wifiOnly, { vm.setWifiOnly(it) }, subtitle = "New downloads wait for an unmetered network")
            Text("Maximum concurrent downloads", style = MaterialTheme.typography.bodyLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { n -> FilterChip(selected = s.maxConcurrent == n, onClick = { vm.setMaxConcurrent(n) }, label = { Text("$n") }) }
            }
        }

        SectionCard(title = "Notifications", icon = Icons.Rounded.Notifications) {
            SwitchRow("Vibrate when a task finishes", s.vibrate, { vm.setVibrate(it) })
            SwitchRow("Play a sound when a task finishes", s.sound, { vm.setSound(it) })
        }

        SectionCard(title = "Appearance", icon = Icons.Rounded.Palette) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { t -> FilterChip(selected = s.theme == t, onClick = { vm.setTheme(t) }, label = { Text(t.label) }) }
            }
        }

        SectionCard(title = "Storage", icon = Icons.Rounded.SdStorage) {
            StorageRow("Saved by this app", TimeText.bytes(outputBytes))
            StorageRow("Temporary files", TimeText.bytes(storage.tempBytes))
            StorageRow("Free space on device", "${TimeText.bytes(storage.freeBytes)} of ${TimeText.bytes(storage.totalBytes)}")
            if (storage.totalBytes > 0) {
                LinearProgressIndicator(
                    progress = { 1f - storage.freeBytes.toFloat() / storage.totalBytes },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { vm.clearTemp() }) { Text("Clear temporary files") }
                OutlinedButton(onClick = { confirmClear = true }) { Text("Clear download history") }
            }
        }

        SectionCard(title = "Downloader engine", icon = Icons.Rounded.Info) {
            Text(engine)
            InfoText("Websites change often. If downloads from a site stop working, update yt-dlp (downloads ~3 MB from GitHub).")
            OutlinedButton(onClick = { vm.updateDownloader() }, enabled = !updating) {
                Text(if (updating) "Updating…" else "Update yt-dlp")
            }
        }

        SectionCard(title = "About") {
            Text("Video to MP3 Converter & Downloader ${vm.appVersion}")
            InfoText(
                "Only download media you own or have permission to save, and respect copyright and each platform's terms. " +
                    "This app never asks for social-media passwords, does not bypass DRM, logins or other restrictions, " +
                    "and contains no ads, subscriptions or tracking. Local conversions run entirely on your device.",
            )
            InfoText("Includes FFmpeg (LGPL/GPL), yt-dlp (Unlicense) and Python via youtubedl-android (GPL-3.0).")
        }
        Spacer(Modifier.size(8.dp))
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear download history?") },
        text = { Text("Finished, failed and cancelled entries are removed. Saved files stay on the device.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
    )
}

@Composable
private fun StorageRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
