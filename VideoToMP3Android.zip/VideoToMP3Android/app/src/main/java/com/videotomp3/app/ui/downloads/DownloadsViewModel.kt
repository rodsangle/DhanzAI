package com.videotomp3.app.ui.downloads

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videotomp3.app.data.StorageRepository
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskRepository
import com.videotomp3.app.data.TaskStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val repo: TaskRepository,
    private val storage: StorageRepository,
) : ViewModel() {
    val tasks: StateFlow<List<TaskEntity>> = repo.tasks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeCount: StateFlow<Int> = repo.tasks.map { list -> list.count { it.status == TaskStatus.RUNNING || it.status == TaskStatus.QUEUED } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    /** Task whose output is playing in the built-in player. */
    val playing = MutableStateFlow<TaskEntity?>(null)

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    fun pause(id: Long) = viewModelScope.launch { repo.pause(id) }
    fun resume(id: Long) = viewModelScope.launch { repo.resume(id) }
    fun cancel(id: Long) = viewModelScope.launch { repo.cancel(id) }
    fun retry(id: Long) = viewModelScope.launch { repo.retry(id) }

    fun delete(task: TaskEntity, deleteFile: Boolean) = viewModelScope.launch {
        if (playing.value?.id == task.id) playing.value = null
        val ok = repo.delete(task.id, deleteFile)
        _messages.send(
            when {
                !deleteFile -> "Removed from the list"
                ok -> "Deleted ${task.outputDisplayName ?: task.title}"
                else -> "Removed from the list. The file could not be deleted (it may have been moved or created before a reinstall)."
            },
        )
    }

    fun clearHistory() = viewModelScope.launch {
        repo.clearHistory()
        _messages.send("History cleared (files on the device are kept)")
    }

    fun folderIntent(task: TaskEntity): Intent =
        runCatching { storage.openFolderIntent(task.outputFolderUri, task.isVideo) }.getOrElse { storage.openFolderIntent(null, task.isVideo) }
}
