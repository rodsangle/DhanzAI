package com.videotomp3.app.data

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.videotomp3.core.FileNames
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class SourceMeta(val name: String, val size: Long?, val mime: String?)

data class SavedOutput(val uri: Uri, val displayName: String, val mime: String, val size: Long?)

/**
 * All file access goes through scoped-storage APIs:
 * input via content URIs (Storage Access Framework), output via MediaStore (default folder
 * Music/VideoToMP3 or Movies/VideoToMP3) or a SAF folder the user picked. No storage permission is needed.
 */
@Singleton
class StorageRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val resolver get() = context.contentResolver

    companion object {
        const val APP_FOLDER = "VideoToMP3"
    }

    fun queryMeta(uri: Uri): SourceMeta {
        var name: String? = null
        var size: Long? = null
        if (uri.scheme == "file") {
            val f = File(uri.path.orEmpty())
            return SourceMeta(f.name, f.length(), mimeFromName(f.name))
        }
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        }
        val mime = runCatching { resolver.getType(uri) }.getOrNull()
        val finalName = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "video"
        return SourceMeta(finalName, size, mime ?: mimeFromName(finalName))
    }

    private fun mimeFromName(name: String): String? =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())

    fun hasPersistedRead(uri: Uri): Boolean =
        uri.scheme == "file" || resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }

    /** Keeps read access to a picked document after the app restarts (needed for queued background work). */
    fun tryPersistRead(uri: Uri): Boolean = try {
        resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        true
    } catch (e: SecurityException) {
        false
    }

    fun persistFolder(uri: Uri) {
        resolver.takePersistableUriPermission(
            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )
    }

    fun releaseFolder(uri: Uri) {
        runCatching { resolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
    }

    /**
     * Copies a shared/dropped document (whose temporary permission would expire) into private
     * app storage so it can be processed later in the background.
     */
    suspend fun importToAppStorage(uri: Uri): Uri = withContext(Dispatchers.IO) {
        val meta = queryMeta(uri)
        val dir = File(context.filesDir, "imports").apply { mkdirs() }
        val ext = meta.name.substringAfterLast('.', "mp4").take(8)
        val dest = File(dir, "${UUID.randomUUID()}.$ext")
        copyToFile(uri, dest)
        Uri.fromFile(dest)
    }

    suspend fun copyToFile(uri: Uri, dest: File, onProgress: (Float) -> Unit = {}) = withContext(Dispatchers.IO) {
        val total = queryMeta(uri).size ?: -1L
        val input = resolver.openInputStream(uri) ?: throw IOException("The file could not be opened. It may have been moved or deleted.")
        dest.parentFile?.mkdirs()
        input.use { inp ->
            dest.outputStream().use { out ->
                val buf = ByteArray(256 * 1024)
                var copied = 0L
                var last = 0L
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    copied += n
                    if (total > 0 && copied - last > 4 * 1024 * 1024) {
                        coroutineContext.ensureActive()
                        onProgress((copied * 100f / total).coerceAtMost(100f))
                        last = copied
                    }
                }
            }
        }
    }

    fun workDir(taskId: Long): File = File(context.cacheDir, "tasks/$taskId")

    /** Saves a finished temp file to the user's chosen folder or the default MediaStore folder, never overwriting. */
    suspend fun saveOutput(temp: File, stem: String, ext: String, mime: String, folderUri: String?, isVideo: Boolean): SavedOutput =
        withContext(Dispatchers.IO) {
            if (folderUri != null) {
                val tree = DocumentFile.fromTreeUri(context, Uri.parse(folderUri))
                if (tree != null && tree.canWrite()) return@withContext saveToTree(tree, temp, stem, ext, mime)
                // Permission was revoked or the folder was removed: fall back to the default folder.
            }
            saveToMediaStore(temp, stem, ext, mime, isVideo)
        }

    private fun saveToTree(tree: DocumentFile, temp: File, stem: String, ext: String, mime: String): SavedOutput {
        val existing = tree.listFiles().mapNotNull { it.name?.lowercase() }.toSet()
        val name = FileNames.unique(stem, ext) { it.lowercase() in existing }
        val doc = tree.createFile(mime, name) ?: throw IOException("Could not create the file in the selected folder.")
        try {
            resolver.openOutputStream(doc.uri, "w")?.use { out -> temp.inputStream().use { it.copyTo(out, 256 * 1024) } }
                ?: throw IOException("Could not write to the selected folder.")
        } catch (e: Exception) {
            doc.delete()
            throw e
        }
        return SavedOutput(doc.uri, doc.name ?: name, mime, temp.length())
    }

    private fun saveToMediaStore(temp: File, stem: String, ext: String, mime: String, isVideo: Boolean): SavedOutput {
        val collection = if (isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val relPath = (if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC) + "/$APP_FOLDER/"
        val existing = mutableSetOf<String>()
        resolver.query(
            collection, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH} = ?", arrayOf(relPath), null,
        )?.use { c -> while (c.moveToNext()) existing += c.getString(0).lowercase() }
        val name = FileNames.unique(stem, ext) { it.lowercase() in existing }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Could not create the output file in $relPath.")
        try {
            resolver.openOutputStream(uri, "w")?.use { out -> temp.inputStream().use { it.copyTo(out, 256 * 1024) } }
                ?: throw IOException("Could not write the output file.")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        var finalName = name
        resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) finalName = c.getString(0) ?: name
        }
        return SavedOutput(uri, finalName, mime, temp.length())
    }

    /** Deletes an output file. Returns false when the file is not owned by the app anymore (e.g. after reinstall). */
    fun deleteOutput(uri: Uri): Boolean = try {
        if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.deleteDocument(resolver, uri)
        else resolver.delete(uri, null, null) > 0
    } catch (e: SecurityException) {
        false
    } catch (e: Exception) {
        false
    }

    fun outputExists(uri: Uri): Boolean = runCatching {
        resolver.openFileDescriptor(uri, "r")?.use { true } ?: false
    }.getOrDefault(false)

    fun folderLabel(folderUri: String?): String {
        if (folderUri == null) return "Music/$APP_FOLDER (audio) · Movies/$APP_FOLDER (video)"
        val tree = runCatching { DocumentFile.fromTreeUri(context, Uri.parse(folderUri)) }.getOrNull()
        val docId = runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(folderUri)) }.getOrNull()
        return docId?.substringAfter(':')?.takeIf { it.isNotBlank() }?.let { "Internal storage/$it" } ?: tree?.name ?: "Selected folder"
    }

    /** Intent that opens the folder containing the outputs in a file manager (best effort; not all devices support it). */
    fun openFolderIntent(folderUri: String?, isVideo: Boolean): Intent {
        val docUri = if (folderUri != null) {
            val tree = Uri.parse(folderUri)
            DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        } else {
            val dir = (if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC) + "/$APP_FOLDER"
            DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$dir")
        }
        return Intent(Intent.ACTION_VIEW).setDataAndType(docUri, DocumentsContract.Document.MIME_TYPE_DIR)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun tempBytes(): Long = listOf(File(context.cacheDir, "tasks"), File(context.filesDir, "imports"))
        .sumOf { dir -> dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } }

    fun freeBytes(): Long = runCatching { StatFs(Environment.getExternalStorageDirectory().path).availableBytes }.getOrDefault(0L)

    fun totalBytes(): Long = runCatching { StatFs(Environment.getExternalStorageDirectory().path).totalBytes }.getOrDefault(0L)

    /** Removes temporary work folders/imports that do not belong to [keepTaskIds] / [keepImports]. */
    fun clearTemp(keepTaskIds: Set<Long>, keepImports: Set<String>) {
        File(context.cacheDir, "tasks").listFiles()?.forEach { dir ->
            if (dir.name.toLongOrNull() !in keepTaskIds) dir.deleteRecursively()
        }
        File(context.filesDir, "imports").listFiles()?.forEach { f ->
            if (Uri.fromFile(f).toString() !in keepImports) f.delete()
        }
    }

    fun deleteImported(source: String) {
        val uri = Uri.parse(source)
        if (uri.scheme == "file") uri.path?.let { File(it).delete() }
    }
}
