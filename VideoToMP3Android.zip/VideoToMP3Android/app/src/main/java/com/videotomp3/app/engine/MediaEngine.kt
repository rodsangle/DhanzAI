package com.videotomp3.app.engine

import android.content.Context
import com.videotomp3.core.AudioConverter
import com.videotomp3.core.ErrorMessages
import com.videotomp3.core.FfmpegRunner
import com.videotomp3.core.YtDlpArgs
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import com.yausername.youtubedl_android.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.concurrent.thread
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import javax.inject.Inject
import javax.inject.Singleton

class DownloadException(message: String) : Exception(message)

data class VideoDetails(
    val url: String,
    val title: String,
    val uploader: String?,
    val durationSec: Double?,
    val thumbnail: String?,
    val site: String?,
    val heights: List<Int>,
    val hasAudio: Boolean,
    val sizeHint: Long?,
)

/**
 * Wraps the bundled native tools:
 *  - yt-dlp (+ Python, QuickJS) from youtubedl-android for permitted online media;
 *  - FFmpeg 7.1 / FFprobe executables for offline conversion (run directly through [FfmpegRunner]).
 */
@Singleton
class MediaEngine @Inject constructor(@ApplicationContext private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val initJob: Deferred<Result<Unit>> by lazy {
        scope.async {
            runCatching {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
            }
        }
    }

    /** Starts unpacking the bundled tools in the background (first launch takes a few seconds). */
    fun initializeAsync() {
        initJob
    }

    suspend fun ensureReady() {
        initJob.await().getOrElse {
            throw DownloadException("The media engine could not be initialised: ${it.message ?: it.javaClass.simpleName}")
        }
    }

    private val nativeDir get() = File(context.applicationInfo.nativeLibraryDir)
    private val packagesDir get() = File(context.noBackupFilesDir, "youtubedl-android/packages")

    fun ffmpegRunner(): FfmpegRunner {
        val ffprobe = File(nativeDir, "libffprobe.so").takeIf { it.exists() }?.absolutePath
        return FfmpegRunner(
            ffmpeg = File(nativeDir, "libffmpeg.so").absolutePath,
            ffprobe = ffprobe,
            environment = mapOf(
                "LD_LIBRARY_PATH" to File(packagesDir, "ffmpeg/usr/lib").absolutePath,
                "TMPDIR" to context.cacheDir.absolutePath,
            ),
        )
    }

    fun converter(): AudioConverter = AudioConverter(ffmpegRunner())

    suspend fun analyze(url: String): VideoDetails = withContext(Dispatchers.IO) {
        ensureReady()
        val request = YoutubeDLRequest(url).addCommands(YtDlpArgs.analyze())
        val info = try {
            YoutubeDL.getInstance().getInfo(request)
        } catch (e: YoutubeDLException) {
            throw DownloadException(ErrorMessages.download(e.message))
        } catch (e: CancellationException) {
            throw e
        } catch (e: YoutubeDL.CanceledException) {
            throw CancellationException("Analysis cancelled")
        } catch (e: Exception) {
            val msg = e.message.orEmpty()
            throw DownloadException(
                if ("json" in msg.lowercase() || "playlist" in msg.lowercase()) "This link is a playlist or channel. Paste the link of a single video."
                else ErrorMessages.download(msg),
            )
        }
        val formats = info.formats.orEmpty()
        val heights = formats.filter { it.vcodec != "none" && it.height > 0 }.map { it.height }.distinct().sortedDescending()
        val hasAudio = formats.isEmpty() || formats.any { it.acodec != "none" }
        val size = formats.maxOfOrNull { maxOf(it.fileSize, it.fileSizeApproximate) }?.takeIf { it > 0 }
        VideoDetails(
            url = info.webpageUrl ?: url,
            title = info.title ?: info.fulltitle ?: info.id ?: "video",
            uploader = info.uploader,
            durationSec = info.duration.takeIf { it > 0 }?.toDouble(),
            thumbnail = info.thumbnail,
            site = info.extractorKey,
            heights = heights,
            hasAudio = hasAudio,
            sizeHint = size,
        )
    }

    /**
     * Runs yt-dlp; [onLine] receives every output line (progress is parsed by the caller).
     * Cancelling the coroutine kills the yt-dlp process immediately.
     */
    suspend fun download(processId: String, url: String, args: List<String>, onLine: (String) -> Unit) {
        ensureReady()
        val request = YoutubeDLRequest(url).addCommands(args)
        try {
            suspendCancellableCoroutine<Unit> { cont ->
                thread(name = "yt-dlp-$processId", isDaemon = true) {
                    try {
                        YoutubeDL.getInstance().execute(request, processId) { _: Float, _: Long, line: String -> onLine(line) }
                        cont.resume(Unit)
                    } catch (t: Throwable) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                }
                cont.invokeOnCancellation { YoutubeDL.getInstance().destroyProcessById(processId) }
            }
        } catch (e: YoutubeDL.CanceledException) {
            throw CancellationException("Download cancelled")
        } catch (e: YoutubeDLException) {
            throw DownloadException(ErrorMessages.download(e.message))
        } catch (e: InterruptedException) {
            throw CancellationException("Download interrupted")
        }
    }

    suspend fun ytDlpVersion(): String? = withContext(Dispatchers.IO) {
        runCatching { ensureReady(); YoutubeDL.getInstance().version(context) }.getOrNull()
    }

    /** Updates the bundled yt-dlp to the latest stable release (sites change often). */
    suspend fun updateYtDlp(): String = withContext(Dispatchers.IO) {
        ensureReady()
        val status = YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE)
        when (status) {
            YoutubeDL.UpdateStatus.DONE -> "Updated to ${YoutubeDL.getInstance().version(context)}"
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "Already up to date (${YoutubeDL.getInstance().version(context)})"
            else -> "Update finished"
        }
    }
}
