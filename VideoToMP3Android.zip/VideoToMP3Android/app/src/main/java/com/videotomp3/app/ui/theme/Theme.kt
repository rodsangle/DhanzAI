package com.videotomp3.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AccentBlue = Color(0xFF3B82F6)
val AccentBlueLight = Color(0xFF60A5FA)
val Navy = Color(0xFF0B1220)
val SuccessGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)

private val DarkColors = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = AccentBlueLight,
    onSecondary = Navy,
    secondaryContainer = Color(0xFF1C2A44),
    onSecondaryContainer = Color(0xFFCFDDF5),
    tertiary = Color(0xFF22D3EE),
    background = Navy,
    onBackground = Color(0xFFE6EBF5),
    surface = Navy,
    onSurface = Color(0xFFE6EBF5),
    surfaceVariant = Color(0xFF1A2438),
    onSurfaceVariant = Color(0xFF9AA6BF),
    surfaceContainerLowest = Color(0xFF080E1A),
    surfaceContainerLow = Color(0xFF0F1727),
    surfaceContainer = Color(0xFF121B2E),
    surfaceContainerHigh = Color(0xFF182237),
    surfaceContainerHighest = Color(0xFF1F2A42),
    outline = Color(0xFF34425E),
    outlineVariant = Color(0xFF243049),
    error = Color(0xFFF87171),
    onError = Color(0xFF2B0A0A),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF0B2A6B),
    secondary = Color(0xFF3B82F6),
    secondaryContainer = Color(0xFFE3ECFB),
    onSecondaryContainer = Color(0xFF14284B),
    tertiary = Color(0xFF0891B2),
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF111827),
    surface = Color(0xFFF4F7FC),
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE6ECF6),
    onSurfaceVariant = Color(0xFF526079),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF9FBFE),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEEF2F9),
    surfaceContainerHighest = Color(0xFFE6ECF6),
    outline = Color(0xFFC3CDDD),
    outlineVariant = Color(0xFFDCE3EE),
    error = Color(0xFFDC2626),
)

private val AppTypography = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontWeight = FontWeight.Black, letterSpacing = 1.5.sp),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.Bold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 15.sp),
    )
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun VideoToMp3Theme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}

val MonoDigits = TextStyle(fontFeatureSettings = "tnum")
