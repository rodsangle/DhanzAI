package com.videotomp3.app.work

import com.videotomp3.app.data.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

/** Limits how many downloads/conversions run at once ("Maximum concurrent downloads" setting). */
@Singleton
class ConcurrencyGate @Inject constructor(private val settings: SettingsRepository) {
    private val running = MutableStateFlow(0)
    private val mutex = Mutex()

    suspend fun <T> withPermit(block: suspend () -> T): T {
        while (true) {
            val max = settings.current().maxConcurrent
            val acquired = mutex.withLock {
                if (running.value < max) {
                    running.value += 1
                    true
                } else {
                    false
                }
            }
            if (acquired) break
            combine(running, settings.settings.map { it.maxConcurrent }) { r, m -> r < m }.first { it }
        }
        try {
            return block()
        } finally {
            running.update { it - 1 }
        }
    }
}
