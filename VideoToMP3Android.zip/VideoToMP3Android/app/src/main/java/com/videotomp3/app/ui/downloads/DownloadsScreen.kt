package com.videotomp3.app.ui.downloads

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videotomp3.app.data.FORMAT_MP4
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskKind
import com.videotomp3.app.data.TaskStatus
import com.videotomp3.app.ui.player.AudioPlayerSheet
import com.videotomp3.app.ui.theme.SuccessGreen
import com.videotomp3.app.ui.theme.WarningAmber
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.TimeText
import java.text.DateFormat
import java.util.Date

@Composable
fun DownloadsScreen(vm: DownloadsViewModel, snackbar: SnackbarHostState) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val playing by vm.playing.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var deleting by remember { mutableStateOf<TaskEntity?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val active = tasks.filter { it.status.isActive || it.status == TaskStatus.FAILED }
    val completed = tasks.filter { it.status == TaskStatus.COMPLETED }

    Column(Modifier.fillMaxSize()) {
        Text("Downloads", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp))
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Active (${active.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Completed (${completed.size})") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("History") })
        }
        val list = when (tab) { 0 -> active; 1 -> completed; else -> tasks }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    when (tab) {
                        0 -> "No active downloads or conversions.\nQueued, running and paused tasks appear here."
                        1 -> "Completed downloads and conversions appear here."
                        else -> "No history yet."
                    },
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (tab == 2) item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${tasks.size} items", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { confirmClear = true }) {
                            Icon(Icons.Rounded.DeleteSweep, null)
                            Spacer(Modifier.size(6.dp))
                            Text("Clear history")
                        }
                    }
                }
                items(list, key = { it.id }) { task ->
                    TaskCard(
                        task, compact = tab == 2,
                        onPause = { vm.pause(task.id) }, onResume = { vm.resume(task.id) },
                        onCancel = { vm.cancel(task.id) }, onRetry = { vm.retry(task.id) },
                        onPlay = { vm.playing.value = task },
                        onShare = { share(context, task) }, onOpen = { open(context, task) },
                        onFolder = { start(context, vm.folderIntent(task), "No file manager could open the folder. Look in ${folderHint(task)}.") },
                        onDelete = { deleting = task },
                    )
                }
            }
        }
    }

    deleting?.let { task ->
        var deleteFile by remember(task.id) { mutableStateOf(task.outputUri != null) }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete") },
            text = {
                Column {
                    Text(task.outputDisplayName ?: task.title)
                    if (task.outputUri != null) Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = deleteFile, onCheckedChange = { deleteFile = it })
                        Text("Also delete the file from the device")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.delete(task, deleteFile); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear download history?") },
        text = { Text("Finished, failed and cancelled entries are removed from the list. Saved audio and video files stay on the device.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
    )

    playing?.let { task ->
        task.outputUri?.let { uri -> AudioPlayerSheet(Uri.parse(uri), task.outputDisplayName ?: task.title, onDismiss = { vm.playing.value = null }) }
    }
}

private fun folderHint(task: TaskEntity) = if (task.outputFolderUri != null) "the folder selected in Settings"
else if (task.isVideo) "Movies/VideoToMP3" else "Music/VideoToMP3"

private fun start(context: Context, intent: Intent, failure: String) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, failure, Toast.LENGTH_LONG).show()
    } catch (e: SecurityException) {
        Toast.makeText(context, failure, Toast.LENGTH_LONG).show()
    }
}

private fun share(context: Context, task: TaskEntity) {
    val uri = task.outputUri ?: return
    val send = Intent(Intent.ACTION_SEND)
        .setType(task.outputMime ?: "audio/*")
        .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
        .putExtra(Intent.EXTRA_TITLE, task.outputDisplayName)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    start(context, Intent.createChooser(send, "Share ${task.outputDisplayName ?: "file"}"), "No app available to share this file.")
}

private fun open(context: Context, task: TaskEntity) {
    val uri = task.outputUri ?: return
    val view = Intent(Intent.ACTION_VIEW)
        .setDataAndType(Uri.parse(uri), task.outputMime ?: "audio/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    start(context, Intent.createChooser(view, "Open with"), "No app can open this file type.")
}

private fun formatLabel(task: TaskEntity): String {
    if (task.format == FORMAT_MP4) return "MP4" + (task.videoHeight?.let { " · ${it}p" } ?: "")
    val f = AudioFormat.fromName(task.format)
    val q = AudioQuality.fromName(task.quality)
    return f.extension.uppercase() + if (f.lossless) "" else " · " + (q.kbps?.let { "$it kbps" } ?: "original")
}

@Composable
private fun TaskCard(
    task: TaskEntity, compact: Boolean,
    onPause: () -> Unit, onResume: () -> Unit, onCancel: () -> Unit, onRetry: () -> Unit,
    onPlay: () -> Unit, onShare: () -> Unit, onOpen: () -> Unit, onFolder: () -> Unit, onDelete: () -> Unit,
) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (task.isVideo) Icons.Rounded.Movie else Icons.Rounded.MusicNote, null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp),
                )
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(task.outputDisplayName ?: task.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val kind = if (task.kind == TaskKind.DOWNLOAD) "Download" else "Conversion"
                    val size = task.outputSize ?: task.totalBytes
                    Text(
                        listOfNotNull(kind, formatLabel(task), size?.let { TimeText.bytes(it) }).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            val statusColor = when (task.status) {
                TaskStatus.COMPLETED -> SuccessGreen
                TaskStatus.FAILED -> MaterialTheme.colorScheme.error
                TaskStatus.CANCELLED, TaskStatus.PAUSED -> WarningAmber
                else -> MaterialTheme.colorScheme.primary
            }
            if (task.status == TaskStatus.RUNNING || task.status == TaskStatus.QUEUED || task.status == TaskStatus.PAUSED) {
                if (task.status == TaskStatus.RUNNING && task.progress >= 0) {
                    LinearProgressIndicator(progress = { task.progress / 100f }, modifier = Modifier.fillMaxWidth())
                } else if (task.status == TaskStatus.PAUSED) {
                    LinearProgressIndicator(progress = { task.progress.coerceAtLeast(0f) / 100f }, modifier = Modifier.fillMaxWidth(), color = WarningAmber)
                } else {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            val statusText = when (task.status) {
                TaskStatus.RUNNING -> listOf(
                    task.phase,
                    if (task.progress >= 0) "${task.progress.toInt()}%" else "",
                    task.speed,
                    if (task.eta.isNotBlank()) "ETA ${task.eta}" else "",
                    task.totalBytes?.let { "of ${TimeText.bytes(it)}" } ?: "",
                ).filter { it.isNotBlank() }.joinToString(" · ")
                TaskStatus.FAILED -> "Failed: ${task.error ?: "unknown error"}"
                TaskStatus.COMPLETED -> "Completed " + (task.finishedAt?.let { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(it)) } ?: "")
                else -> task.phase
            }
            Text(statusText, style = MaterialTheme.typography.bodySmall, color = statusColor)

            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                when (task.status) {
                    TaskStatus.RUNNING, TaskStatus.QUEUED -> {
                        if (task.canPause) Action("Pause", Icons.Rounded.Pause, onPause)
                        Action("Cancel", Icons.Rounded.Cancel, onCancel)
                    }
                    TaskStatus.PAUSED -> {
                        Action("Resume", Icons.Rounded.PlayArrow, onResume)
                        Action("Cancel", Icons.Rounded.Cancel, onCancel)
                    }
                    TaskStatus.FAILED, TaskStatus.CANCELLED -> {
                        Action("Retry", Icons.Rounded.Refresh, onRetry)
                        Action("Delete", Icons.Rounded.Delete, onDelete)
                    }
                    TaskStatus.COMPLETED -> {
                        Action("Play", Icons.Rounded.PlayArrow, onPlay)
                        Action("Share", Icons.Rounded.Share, onShare)
                        if (!compact) Action("Open", Icons.Rounded.OpenInNew, onOpen)
                        if (!compact) Action("Folder", Icons.Rounded.Folder, onFolder)
                        Action("Delete", Icons.Rounded.Delete, onDelete)
                    }
                }
            }
        }
    }
}

@Composable
private fun Action(label: String, icon: ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) {
        Icon(icon, null, Modifier.size(18.dp))
        Spacer(Modifier.size(6.dp))
        Text(label)
    }
}
