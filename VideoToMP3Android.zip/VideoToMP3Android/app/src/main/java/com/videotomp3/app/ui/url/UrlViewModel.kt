package com.videotomp3.app.ui.url

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videotomp3.app.SharedContent
import com.videotomp3.app.data.FORMAT_MP4
import com.videotomp3.app.data.SettingsRepository
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskKind
import com.videotomp3.app.data.TaskRepository
import com.videotomp3.app.engine.DownloadException
import com.videotomp3.app.engine.MediaEngine
import com.videotomp3.app.engine.VideoDetails
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.ErrorMessages
import com.videotomp3.core.FileNames
import com.videotomp3.core.TimeText
import com.videotomp3.core.Urls
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UrlUiState(
    val url: String = "",
    val analyzing: Boolean = false,
    val error: String? = null,
    val info: VideoDetails? = null,
    val analyzedUrl: String? = null,
    val format: AudioFormat = AudioFormat.MP3,
    val quality: AudioQuality = AudioQuality.K192,
    /** null = best available. */
    val videoHeight: Int? = null,
    val fileName: String = "",
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val start: String = "",
    val end: String = "",
    val embedArtwork: Boolean = true,
) {
    val ready get() = info != null && analyzedUrl == url.trim() && !analyzing
}

@HiltViewModel
class UrlViewModel @Inject constructor(
    private val engine: MediaEngine,
    private val tasks: TaskRepository,
    private val settings: SettingsRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(UrlUiState())
    val state: StateFlow<UrlUiState> = _state.asStateFlow()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private var analyzeJob: Job? = null
    private var preferredHeight = 1080

    init {
        viewModelScope.launch {
            val s = settings.current()
            preferredHeight = s.videoHeight
            _state.update { it.copy(format = s.defaultFormat, quality = s.quality, embedArtwork = s.embedArtwork) }
        }
    }

    fun onUrlChange(value: String) = _state.update { it.copy(url = value, error = null) }

    /** Paste from clipboard text; analyses straight away. */
    fun paste(text: String?) {
        val url = Urls.extractFromText(text) ?: text?.trim()
        if (url.isNullOrBlank()) {
            _state.update { it.copy(error = "The clipboard does not contain a link.") }
            return
        }
        _state.update { it.copy(url = url, error = null) }
        analyze()
    }

    fun handleShared(content: SharedContent.Link) = paste(content.url)

    fun analyze() {
        val url = try {
            Urls.validate(_state.value.url)
        } catch (e: IllegalArgumentException) {
            _state.update { it.copy(error = e.message) }
            return
        }
        analyzeJob?.cancel()
        _state.update { it.copy(url = url, analyzing = true, error = null, info = null) }
        analyzeJob = viewModelScope.launch {
            try {
                val info = engine.analyze(url)
                val height = info.heights.firstOrNull { it <= preferredHeight }
                _state.update {
                    it.copy(
                        analyzing = false, info = info, analyzedUrl = url, videoHeight = height,
                        fileName = FileNames.sanitize(info.title), title = info.title, artist = info.uploader.orEmpty(),
                        album = "", start = "", end = "",
                        error = if (!info.hasAudio) "No audio track was detected for this video." else null,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: DownloadException) {
                _state.update { it.copy(analyzing = false, error = e.message) }
            } catch (e: Exception) {
                _state.update { it.copy(analyzing = false, error = ErrorMessages.download(e.message)) }
            }
        }
    }

    fun setFormat(f: AudioFormat) {
        _state.update { it.copy(format = f) }
        viewModelScope.launch { settings.setDefaultFormat(f) } // remember the choice
    }

    fun setQuality(q: AudioQuality) {
        _state.update { it.copy(quality = q) }
        viewModelScope.launch { settings.setQuality(q) }
    }

    fun setVideoHeight(h: Int?) = _state.update { it.copy(videoHeight = h) }
    fun setFileName(v: String) = _state.update { it.copy(fileName = v) }
    fun setTitle(v: String) = _state.update { it.copy(title = v) }
    fun setArtist(v: String) = _state.update { it.copy(artist = v) }
    fun setAlbum(v: String) = _state.update { it.copy(album = v) }
    fun setStart(v: String) = _state.update { it.copy(start = v) }
    fun setEnd(v: String) = _state.update { it.copy(end = v) }
    fun setEmbedArtwork(v: Boolean) = _state.update { it.copy(embedArtwork = v) }

    fun download(video: Boolean) {
        val s = _state.value
        val info = s.info ?: return
        if (!s.ready) {
            _state.update { it.copy(error = "The link changed. Tap Analyze Video again.") }
            return
        }
        val start: Double?
        val end: Double?
        try {
            start = if (video) null else TimeText.parse(s.start)
            end = if (video) null else TimeText.parse(s.end)
        } catch (e: IllegalArgumentException) {
            _state.update { it.copy(error = e.message) }
            return
        }
        if (start != null && end != null && end <= start) {
            _state.update { it.copy(error = "The trim end time must be later than the start time.") }
            return
        }
        if (start != null && info.durationSec != null && start >= info.durationSec) {
            _state.update { it.copy(error = "The trim start time is beyond the end of the video.") }
            return
        }
        viewModelScope.launch {
            val prefs = settings.current()
            val name = FileNames.sanitize(s.fileName.ifBlank { info.title })
            tasks.enqueue(
                TaskEntity(
                    kind = TaskKind.DOWNLOAD,
                    source = info.url,
                    title = info.title,
                    outputName = name,
                    format = if (video) FORMAT_MP4 else s.format.name,
                    quality = s.quality.name,
                    videoHeight = if (video) s.videoHeight else null,
                    startSec = start,
                    endSec = end,
                    metaTitle = if (video) null else s.title.ifBlank { null },
                    metaArtist = if (video) null else s.artist.ifBlank { null },
                    metaAlbum = if (video) null else s.album.ifBlank { null },
                    embedArtwork = s.embedArtwork,
                    outputFolderUri = prefs.outputFolderUri,
                    wifiOnly = prefs.wifiOnly,
                ),
            )
            val what = if (video) "MP4 video" else s.format.label
            _messages.send("Added to Downloads: $name ($what)" + if (prefs.wifiOnly) " · waits for Wi-Fi" else "")
        }
    }
}
