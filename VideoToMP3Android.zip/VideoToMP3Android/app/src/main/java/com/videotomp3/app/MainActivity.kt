package com.videotomp3.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.IntentCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videotomp3.app.data.AppSettings
import com.videotomp3.app.data.SettingsRepository
import com.videotomp3.app.data.ThemeMode
import com.videotomp3.app.ui.AppRoot
import com.videotomp3.app.ui.theme.VideoToMp3Theme
import com.videotomp3.core.InputFormats
import com.videotomp3.core.Urls
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_DOWNLOADS = "open_downloads"
    }

    @Inject lateinit var shareBus: ShareBus
    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            val settings by settingsRepository.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            val dark = when (settings.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
            }
            LaunchedEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                )
            }
            VideoToMp3Theme(darkTheme = dark) {
                AppRoot(shareBus = shareBus)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Accepts links shared as text, and video files shared/opened from other apps. */
    private fun handleIntent(intent: Intent?) {
        intent ?: return
        if (intent.getBooleanExtra(EXTRA_OPEN_DOWNLOADS, false)) shareBus.requestTab(AppTab.DOWNLOADS)
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val stream = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (stream != null && isVideo(intent.type, stream)) {
                    shareBus.publish(SharedContent.Videos(listOf(stream)))
                } else {
                    val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: intent.getStringExtra(Intent.EXTRA_SUBJECT)
                    val url = Urls.extractFromText(text)
                    if (url != null) shareBus.publish(SharedContent.Link(url))
                    else Toast.makeText(this, "No video link was found in the shared text.", Toast.LENGTH_LONG).show()
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val uris = IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
                if (uris.isNotEmpty()) shareBus.publish(SharedContent.Videos(uris))
            }
            Intent.ACTION_VIEW -> intent.data?.let { uri ->
                if (uri.scheme == "content" && isVideo(intent.type, uri)) shareBus.publish(SharedContent.Videos(listOf(uri)))
            }
        }
    }

    private fun isVideo(type: String?, uri: Uri): Boolean =
        InputFormats.isVideoMime(type) || InputFormats.isVideoMime(contentResolver.getType(uri)) ||
            InputFormats.isSupportedName(uri.lastPathSegment.orEmpty())
}
