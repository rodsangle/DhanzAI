package com.videotomp3.app.ui.url

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.videotomp3.app.SharedContent
import com.videotomp3.app.ShareBus
import com.videotomp3.app.ui.components.AppHeader
import com.videotomp3.app.ui.components.DashboardAction
import com.videotomp3.app.ui.components.InfoText
import com.videotomp3.app.ui.components.LargeButton
import com.videotomp3.app.ui.components.SectionCard
import com.videotomp3.app.ui.components.SelectorField
import com.videotomp3.app.ui.components.SwitchRow
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.TimeText

private fun readClipboard(context: Context): String? {
    val cm = context.getSystemService(ClipboardManager::class.java) ?: return null
    val clip = cm.primaryClip ?: return null
    if (clip.itemCount == 0) return null
    return clip.getItemAt(0).coerceToText(context)?.toString()
}

@Composable
fun UrlScreen(shareBus: ShareBus, snackbar: SnackbarHostState, wide: Boolean, vm: UrlViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val shared by shareBus.shared.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(shared) {
        if (shared is SharedContent.Link) (shareBus.consumeShared() as? SharedContent.Link)?.let(vm::handleShared)
    }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        AppHeader()
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DashboardAction(
                "CONVERT VIDEO", "Turn videos on this device into MP3 – works offline", Icons.Rounded.VideoLibrary,
                onClick = { shareBus.requestVideoPicker() }, modifier = Modifier.weight(1f),
            )
            DashboardAction(
                "PASTE VIDEO LINK", "Download permitted online media", Icons.Rounded.ContentPaste,
                onClick = { vm.paste(readClipboard(context)) }, modifier = Modifier.weight(1f), filled = false,
            )
        }

        SectionCard(title = "Video URL", icon = Icons.Rounded.Link) {
            OutlinedTextField(
                value = state.url,
                onValueChange = vm::onUrlChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("https://…") },
                leadingIcon = { Icon(Icons.Rounded.Link, null) },
                trailingIcon = {
                    if (state.url.isNotEmpty()) IconButton(onClick = { vm.onUrlChange("") }) { Icon(Icons.Rounded.Close, "Clear") }
                },
                singleLine = true,
                isError = state.error != null && state.info == null,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.analyze() }),
                shape = MaterialTheme.shapes.medium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { vm.paste(readClipboard(context)) }, modifier = Modifier.weight(1f).height(52.dp)) {
                    Icon(Icons.Rounded.ContentPaste, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Paste Link")
                }
                Button(onClick = vm::analyze, enabled = !state.analyzing, modifier = Modifier.weight(1f).height(52.dp)) {
                    Icon(Icons.Rounded.Search, null)
                    Spacer(Modifier.size(8.dp))
                    Text(if (state.analyzing) "Analyzing…" else "Analyze Video")
                }
            }
            AnimatedVisibility(state.analyzing) { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            state.error?.let { InfoText(it, color = MaterialTheme.colorScheme.error) }
            InfoText(
                "Works with publicly accessible media on YouTube, Facebook, Instagram, TikTok, Vimeo and many other sites, " +
                    "subject to each platform's rules. Only download media you own or are allowed to save. Private, " +
                    "login-only, paid and DRM-protected content is not supported.",
            )
        }

        val info = state.info
        AnimatedVisibility(info != null) {
            if (info != null) SectionCard {
                val thumbModifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(MaterialTheme.shapes.medium)
                if (wide) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Box(Modifier.widthIn(max = 360.dp).weight(1f)) { Thumbnail(info.thumbnail, thumbModifier) }
                        Box(Modifier.weight(1f)) { VideoMeta(state) }
                    }
                } else {
                    Thumbnail(info.thumbnail, thumbModifier)
                    VideoMeta(state)
                }
            }
        }

        AnimatedVisibility(info != null) {
            OutputOptions(state, vm)
        }
    }
}

@Composable
private fun Thumbnail(url: String?, modifier: Modifier) {
    if (url != null) {
        AsyncImage(model = url, contentDescription = "Video thumbnail", contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Movie, null, Modifier.size(48.dp)) }
    }
}

@Composable
private fun VideoMeta(state: UrlUiState) {
    val info = state.info ?: return
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(info.title, style = MaterialTheme.typography.titleLarge, maxLines = 3, overflow = TextOverflow.Ellipsis)
        val meta = listOfNotNull(info.uploader, info.site, info.durationSec?.let { TimeText.duration(it) })
        if (meta.isNotEmpty()) Text(meta.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (info.heights.isEmpty()) AssistChip(onClick = {}, label = { Text("Single quality") })
            info.heights.take(6).forEach { h -> AssistChip(onClick = {}, label = { Text("${h}p") }) }
            info.sizeHint?.let { AssistChip(onClick = {}, label = { Text("≈ ${TimeText.bytes(it)}") }, leadingIcon = { Icon(Icons.Rounded.Info, null) }) }
        }
    }
}

@Composable
private fun OutputOptions(state: UrlUiState, vm: UrlViewModel) {
    val info = state.info ?: return
    SectionCard(title = "Output", icon = Icons.Rounded.Tune) {
        SelectorField("Output format", AudioFormat.entries, state.format, { it.label }, vm::setFormat)
        SelectorField(
            "Audio quality", AudioQuality.entries, state.quality, { it.label }, vm::setQuality,
            enabled = !state.format.lossless,
            supportingText = if (state.format.lossless) "Lossless format – bitrate not needed" else null,
        )
        val heights: List<Int?> = listOf<Int?>(null) + info.heights
        SelectorField("Download quality (MP4)", heights, state.videoHeight, { it?.let { h -> "${h}p" } ?: "Best available" }, vm::setVideoHeight)
        OutlinedTextField(state.fileName, vm::setFileName, label = { Text("File name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Audio metadata & trimming", style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(state.title, vm::setTitle, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(state.artist, vm::setArtist, label = { Text("Artist") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(state.album, vm::setAlbum, label = { Text("Album") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(state.start, vm::setStart, label = { Text("Start (mm:ss)") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(state.end, vm::setEnd, label = { Text("End (mm:ss)") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        SwitchRow("Embed thumbnail as album artwork", state.embedArtwork, vm::setEmbedArtwork,
            subtitle = "MP3, M4A and FLAC, when the site provides a thumbnail")
        LargeButton(
            "Download ${state.format.extension.uppercase()}", Icons.Rounded.MusicNote,
            onClick = { vm.download(video = false) }, modifier = Modifier.fillMaxWidth(), enabled = state.ready,
        )
        FilledTonalButton(
            onClick = { vm.download(video = true) }, enabled = state.ready,
            modifier = Modifier.fillMaxWidth().height(56.dp), shape = MaterialTheme.shapes.large,
        ) {
            Icon(Icons.Rounded.Download, null)
            Spacer(Modifier.size(10.dp))
            Text("Download MP4")
        }
    }
}
