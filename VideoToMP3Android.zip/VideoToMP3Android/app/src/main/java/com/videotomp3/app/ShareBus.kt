package com.videotomp3.app

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

sealed interface SharedContent {
    data class Link(val url: String) : SharedContent
    data class Videos(val uris: List<Uri>) : SharedContent
}

enum class AppTab(val route: String) { URL("url"), CONVERT("convert"), DOWNLOADS("downloads"), SETTINGS("settings") }

/** Hands content shared from other apps (and navigation requests) to the screens. */
@Singleton
class ShareBus @Inject constructor() {
    private val _shared = MutableStateFlow<SharedContent?>(null)
    val shared: StateFlow<SharedContent?> = _shared.asStateFlow()

    private val _openTab = MutableStateFlow<AppTab?>(null)
    val openTab: StateFlow<AppTab?> = _openTab.asStateFlow()

    /** Set by the dashboard "CONVERT VIDEO" action; the converter screen opens the file picker. */
    private val _pickVideos = MutableStateFlow(false)
    val pickVideos: StateFlow<Boolean> = _pickVideos.asStateFlow()

    fun publish(content: SharedContent) {
        _shared.value = content
        _openTab.value = if (content is SharedContent.Link) AppTab.URL else AppTab.CONVERT
    }

    fun consumeShared(): SharedContent? = _shared.value.also { _shared.value = null }

    fun requestTab(tab: AppTab) { _openTab.value = tab }
    fun tabHandled() { _openTab.value = null }

    fun requestVideoPicker() {
        _pickVideos.value = true
        _openTab.value = AppTab.CONVERT
    }

    fun pickerHandled() { _pickVideos.value = false }
}
