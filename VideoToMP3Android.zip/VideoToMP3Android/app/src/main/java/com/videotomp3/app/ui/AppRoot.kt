package com.videotomp3.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.videotomp3.app.AppTab
import com.videotomp3.app.ShareBus
import com.videotomp3.app.ui.convert.ConvertScreen
import com.videotomp3.app.ui.downloads.DownloadsScreen
import com.videotomp3.app.ui.downloads.DownloadsViewModel
import com.videotomp3.app.ui.settings.SettingsScreen
import com.videotomp3.app.ui.url.UrlScreen

private data class TabSpec(val tab: AppTab, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabSpec(AppTab.URL, "Downloader", Icons.Rounded.Link),
    TabSpec(AppTab.CONVERT, "Converter", Icons.Rounded.LibraryMusic),
    TabSpec(AppTab.DOWNLOADS, "Downloads", Icons.Rounded.Download),
    TabSpec(AppTab.SETTINGS, "Settings", Icons.Rounded.Settings),
)

@Composable
fun AppRoot(shareBus: ShareBus) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val snackbar = remember { SnackbarHostState() }
    val downloadsVm: DownloadsViewModel = hiltViewModel()
    val activeCount by downloadsVm.activeCount.collectAsStateWithLifecycle()
    val openTab by shareBus.openTab.collectAsStateWithLifecycle()
    val wide = LocalConfiguration.current.screenWidthDp >= 600

    fun go(tab: AppTab) {
        if (current == tab.route) return
        nav.navigate(tab.route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    LaunchedEffect(openTab) {
        openTab?.let {
            go(it)
            shareBus.tabHandled()
        }
    }

    // Ask for notification permission (Android 13+ only) the first time a task is started.
    val context = LocalContext.current
    var asked by rememberSaveable { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(activeCount) {
        if (activeCount > 0 && !asked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            asked = true
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    @Composable
    fun TabIcon(spec: TabSpec) {
        if (spec.tab == AppTab.DOWNLOADS && activeCount > 0) {
            BadgedBox(badge = { Badge { Text("$activeCount") } }) { Icon(spec.icon, spec.label) }
        } else {
            Icon(spec.icon, spec.label)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (!wide) NavigationBar {
                tabs.forEach { spec ->
                    NavigationBarItem(
                        selected = current == spec.tab.route,
                        onClick = { go(spec.tab) },
                        icon = { TabIcon(spec) },
                        label = { Text(spec.label) },
                    )
                }
            }
        },
    ) { padding ->
        Row(Modifier.fillMaxSize().padding(padding)) {
            if (wide) NavigationRail {
                tabs.forEach { spec ->
                    NavigationRailItem(
                        selected = current == spec.tab.route,
                        onClick = { go(spec.tab) },
                        icon = { TabIcon(spec) },
                        label = { Text(spec.label) },
                    )
                }
            }
            NavHost(
                navController = nav,
                startDestination = AppTab.URL.route,
                modifier = Modifier.weight(1f),
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() },
            ) {
                composable(AppTab.URL.route) { UrlScreen(shareBus, snackbar, wide) }
                composable(AppTab.CONVERT.route) { ConvertScreen(shareBus, snackbar, wide) }
                composable(AppTab.DOWNLOADS.route) { DownloadsScreen(downloadsVm, snackbar) }
                composable(AppTab.SETTINGS.route) { SettingsScreen(snackbar) }
            }
        }
    }
}
