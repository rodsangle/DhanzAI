package com.videotomp3.app.work

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.videotomp3.app.data.SavedOutput
import com.videotomp3.app.data.SettingsRepository
import com.videotomp3.app.data.StorageRepository
import com.videotomp3.app.data.TaskDao
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskKind
import com.videotomp3.app.data.TaskStatus
import com.videotomp3.app.engine.DownloadException
import com.videotomp3.app.engine.MediaEngine
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.ConversionException
import com.videotomp3.core.ConversionSpec
import com.videotomp3.core.FileNames
import com.videotomp3.core.TimeText
import com.videotomp3.core.YtDlpArgs
import com.videotomp3.core.YtDlpProgress
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Locale

/**
 * Executes one download or conversion task. Runs as a foreground worker so long media
 * conversions keep going when the app is in the background (Android 14+ typed foreground service).
 */
@HiltWorker
class TaskWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val dao: TaskDao,
    private val storage: StorageRepository,
    private val engine: MediaEngine,
    private val settings: SettingsRepository,
    private val gate: ConcurrencyGate,
    private val notifier: TaskNotifier,
) : CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_TASK_ID = "task_id"
        const val TAG = "video_task"
        private const val LOG = "TaskWorker"
    }

    /** Latest progress written by FFmpeg / yt-dlp callbacks, flushed to Room + notification twice a second. */
    private class Progress {
        @Volatile var phase = "Starting"
        @Volatile var percent = -1f
        @Volatile var speed = ""
        @Volatile var eta = ""
        @Volatile var total: Long? = null
        @Volatile var dirty = true

        fun set(phase: String, percent: Float, speed: String = "", eta: String = "", total: Long? = null) {
            this.phase = phase
            this.percent = percent
            this.speed = speed
            this.eta = eta
            if (total != null) this.total = total
            dirty = true
        }
    }

    override suspend fun doWork(): Result {
        val id = inputData.getLong(KEY_TASK_ID, -1)
        val initial = dao.get(id) ?: return Result.success()
        if (initial.status != TaskStatus.QUEUED && initial.status != TaskStatus.RUNNING) return Result.success()

        try {
            setForeground(notifier.foregroundInfo(initial, "Waiting in queue", -1f))
        } catch (e: Exception) {
            // Starting a foreground service can be refused when the app is in the background
            // (Android 12+). The work still runs; it may be paused by the system if very long.
            Log.w(LOG, "Foreground not available: ${e.message}")
        }

        return try {
            gate.withPermit {
                if (dao.markRunning(id, System.currentTimeMillis()) == 0) return@withPermit
                val task = dao.get(id) ?: return@withPermit
                when (task.kind) {
                    TaskKind.CONVERT -> convert(task)
                    TaskKind.DOWNLOAD -> download(task)
                }
            }
            Result.success()
        } catch (e: CancellationException) {
            withContext(NonCancellable) { onStopped(id) }
            throw e
        } catch (e: Exception) {
            val message = when (e) {
                is ConversionException, is DownloadException -> e.message ?: "Failed"
                is SecurityException -> "Permission to read the file was lost. Select the video again."
                is IOException -> "Storage error: ${e.message}"
                else -> "Unexpected error: ${e.message ?: e.javaClass.simpleName}"
            }
            Log.e(LOG, "Task $id failed", e)
            withContext(NonCancellable) {
                dao.markFailed(id, message, System.currentTimeMillis())
                dao.get(id)?.let { notifier.failed(it, message) }
            }
            Result.success()
        }
    }

    /** Called when WorkManager stops the worker: user cancel, user pause, or a system stop. */
    private suspend fun onStopped(id: Long) {
        val task = dao.get(id) ?: return
        notifier.cancelProgress(id)
        when (task.status) {
            TaskStatus.CANCELLED -> storage.workDir(id).deleteRecursively()
            TaskStatus.PAUSED -> Unit // keep the partial download for Resume
            // Stopped by the system (constraints/quota): WorkManager reschedules it automatically.
            TaskStatus.RUNNING, TaskStatus.QUEUED -> dao.setStatus(id, TaskStatus.QUEUED, "Waiting to resume")
            else -> Unit
        }
    }

    private suspend fun <T> withProgress(task: TaskEntity, block: suspend (Progress) -> T): T = coroutineScope {
        val progress = Progress()
        var lastNotification = 0L
        val pump = launch {
            while (isActive) {
                delay(500)
                if (!progress.dirty) continue
                progress.dirty = false
                dao.updateProgress(task.id, progress.phase, progress.percent, progress.speed, progress.eta, progress.total)
                val now = SystemClock.elapsedRealtime()
                if (now - lastNotification > 1000) {
                    lastNotification = now
                    notifier.updateProgress(task, progress.phase, progress.percent, listOf(progress.speed, progress.eta.let { if (it.isBlank()) "" else "ETA $it" }).filter { it.isNotBlank() }.joinToString(" · "))
                }
            }
        }
        try {
            block(progress)
        } finally {
            withContext(NonCancellable) { pump.cancelAndJoin() }
        }
    }

    private fun speedText(x: Double?) = x?.let { String.format(Locale.US, "%.1fx", it) } ?: ""

    private fun TaskEntity.spec(format: AudioFormat, cover: File?, coverFromFrame: Boolean) = ConversionSpec(
        format = format,
        quality = AudioQuality.fromName(quality),
        startSec = startSec,
        endSec = endSec,
        title = metaTitle,
        artist = metaArtist,
        album = metaAlbum,
        coverImage = cover,
        coverFromVideoFrame = coverFromFrame,
    )

    private suspend fun finish(task: TaskEntity, temp: File, ext: String, mime: String, isVideo: Boolean, progress: Progress): SavedOutput {
        progress.set("Saving", -1f)
        val saved = storage.saveOutput(temp, FileNames.sanitize(task.outputName), ext, mime, task.outputFolderUri, isVideo)
        dao.markCompleted(task.id, saved.uri.toString(), saved.displayName, saved.mime, saved.size, System.currentTimeMillis())
        return saved
    }

    private suspend fun convert(task: TaskEntity) {
        val work = storage.workDir(task.id).apply { deleteRecursively(); mkdirs() }
        try {
            val saved = withProgress(task) { progress ->
                progress.set("Preparing", -1f)
                engine.ensureReady()
                val source = Uri.parse(task.source)
                val input = if (source.scheme == "file") {
                    File(source.path.orEmpty())
                } else {
                    val name = storage.queryMeta(source).name
                    File(work, "input." + name.substringAfterLast('.', "mp4").lowercase().take(8)).also { file ->
                        storage.copyToFile(source, file) { p -> progress.set("Reading video", p * 0.1f) }
                    }
                }
                val format = AudioFormat.fromName(task.format)
                val cover = task.coverUri?.takeIf { task.embedArtwork && format.supportsCover }?.let { uri ->
                    runCatching { File(work, "cover_source").also { storage.copyToFile(Uri.parse(uri), it) } }.getOrNull()
                }
                val output = File(work, "output.${format.extension}")
                progress.set("Converting", 10f)
                engine.converter().convert(
                    input, output, task.spec(format, cover, coverFromFrame = task.embedArtwork && cover == null), File(work, "tmp"),
                ) { p ->
                    progress.set("Converting", 10f + (p.percent ?: 0.0).toFloat() * 0.9f, speedText(p.speed), TimeText.duration(p.etaSec).takeIf { p.etaSec != null } ?: "")
                }
                finish(task, output, format.extension, format.mimeType, false, progress)
            }
            notifier.completed(task, saved.displayName, settings.current())
            if (task.sourceIsImported) storage.deleteImported(task.source)
        } finally {
            work.deleteRecursively()
        }
    }

    private suspend fun download(task: TaskEntity) {
        val work = storage.workDir(task.id).apply { mkdirs() } // keeps partial data from a paused download
        val audio = !task.isVideo
        val format = if (audio) AudioFormat.fromName(task.format) else null
        val span = if (audio) 90f else 100f
        val saved = withProgress(task) { progress ->
            progress.set("Connecting", -1f)
            val mode = if (audio) YtDlpArgs.Mode.AUDIO else YtDlpArgs.Mode.VIDEO
            val wantThumb = audio && task.embedArtwork && format!!.supportsCover
            engine.download("task-${task.id}", task.source, YtDlpArgs.download(work, mode, task.videoHeight, wantThumb)) { line ->
                val p = YtDlpProgress.parse(line)
                when {
                    p != null -> progress.set(
                        "Downloading", ((p.percent ?: 0.0).toFloat() * span / 100f),
                        TimeText.speed(p.speedBytesPerSec), p.etaSec?.let { TimeText.duration(it.toDouble()) } ?: "", p.totalBytes,
                    )
                    line.startsWith("[Merger]") -> progress.set("Merging audio and video", -1f)
                    line.startsWith("[ThumbnailsConvertor]") -> progress.set("Processing thumbnail", -1f)
                }
            }
            val (media, thumb) = YtDlpArgs.findOutputs(work)
            if (media == null) throw DownloadException("The download finished but no media file was found.")
            if (audio) {
                val output = File(work, "output.${format!!.extension}")
                progress.set("Converting", span)
                engine.converter().convert(media, output, task.spec(format, thumb, coverFromFrame = false), File(work, "tmp")) { p ->
                    progress.set("Converting", span + (p.percent ?: 0.0).toFloat() * (100f - span) / 100f, speedText(p.speed))
                }
                finish(task, output, format.extension, format.mimeType, false, progress)
            } else {
                val ext = media.extension.lowercase()
                val mime = when (ext) { "webm" -> "video/webm"; "mkv" -> "video/x-matroska"; else -> "video/mp4" }
                finish(task, media, ext, mime, true, progress)
            }
        }
        notifier.completed(task, saved.displayName, settings.current())
        work.deleteRecursively()
    }
}
