package com.videotomp3.app.work

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ForegroundInfo
import com.videotomp3.app.MainActivity
import com.videotomp3.app.R
import com.videotomp3.app.data.AppSettings
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskKind
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskNotifier @Inject constructor(@ApplicationContext private val context: Context) {
    companion object {
        const val CHANNEL_PROGRESS = "progress"
        const val CHANNEL_DONE = "completed"
        private const val PROGRESS_BASE = 10_000
        private const val DONE_BASE = 20_000
    }

    private val manager = NotificationManagerCompat.from(context)

    fun createChannels() {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROGRESS, context.getString(R.string.channel_progress), NotificationManager.IMPORTANCE_LOW).apply {
                description = context.getString(R.string.channel_progress_desc)
                setShowBadge(false)
            },
        )
        // Silent channel: vibration and sound are played by the app according to the user's settings.
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DONE, context.getString(R.string.channel_complete), NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = context.getString(R.string.channel_complete_desc)
                setSound(null, null)
                enableVibration(false)
            },
        )
    }

    private fun canNotify() = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openAppIntent(requestCode: Int): PendingIntent = PendingIntent.getActivity(
        context, requestCode,
        Intent(context, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_OPEN_DOWNLOADS, true)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun actionIntent(action: String, taskId: Long): PendingIntent = PendingIntent.getBroadcast(
        context, (taskId * 4 + action.hashCode() % 4).toInt(),
        Intent(context, NotificationActionReceiver::class.java).setAction(action).putExtra(NotificationActionReceiver.EXTRA_TASK_ID, taskId),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun progressNotification(task: TaskEntity, phase: String, progress: Float, detail: String = ""): Notification {
        val builder = NotificationCompat.Builder(context, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(task.title)
            .setContentText(listOf(phase, if (progress >= 0) "${progress.toInt()}%" else "", detail).filter { it.isNotBlank() }.joinToString(" · "))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(openAppIntent(task.id.toInt()))
            .setProgress(100, progress.coerceAtLeast(0f).toInt(), progress < 0)
            .addAction(0, "Cancel", actionIntent(NotificationActionReceiver.ACTION_CANCEL, task.id))
        if (task.canPause) builder.addAction(0, "Pause", actionIntent(NotificationActionReceiver.ACTION_PAUSE, task.id))
        return builder.build()
    }

    fun foregroundInfo(task: TaskEntity, phase: String, progress: Float): ForegroundInfo {
        val type = if (task.kind == TaskKind.CONVERT && Build.VERSION.SDK_INT >= 35) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
        } else {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        }
        return ForegroundInfo((PROGRESS_BASE + task.id).toInt(), progressNotification(task, phase, progress), type)
    }

    fun updateProgress(task: TaskEntity, phase: String, progress: Float, detail: String) {
        if (canNotify()) {
            @Suppress("MissingPermission")
            manager.notify((PROGRESS_BASE + task.id).toInt(), progressNotification(task, phase, progress, detail))
        }
    }

    fun cancelProgress(taskId: Long) = manager.cancel((PROGRESS_BASE + taskId).toInt())

    fun completed(task: TaskEntity, fileName: String, settings: AppSettings) {
        cancelProgress(task.id)
        val verb = if (task.kind == TaskKind.DOWNLOAD) "Download complete" else "Conversion complete"
        post(task, verb, fileName)
        playFeedback(settings)
    }

    fun failed(task: TaskEntity, error: String) {
        cancelProgress(task.id)
        val verb = if (task.kind == TaskKind.DOWNLOAD) "Download failed" else "Conversion failed"
        post(task, "$verb: ${task.title}", error)
    }

    private fun post(task: TaskEntity, title: String, text: String) {
        if (!canNotify()) return
        val n = NotificationCompat.Builder(context, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(DONE_BASE + task.id.toInt()))
            .build()
        @Suppress("MissingPermission")
        manager.notify((DONE_BASE + task.id).toInt(), n)
    }

    private fun playFeedback(settings: AppSettings) {
        if (settings.vibrate) runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Vibrator::class.java)
            }
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120), -1))
        }
        if (settings.sound) runCatching {
            RingtoneManager.getRingtone(context, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play()
        }
    }
}
