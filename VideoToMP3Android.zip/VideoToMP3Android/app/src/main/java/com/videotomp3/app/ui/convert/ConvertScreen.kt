package com.videotomp3.app.ui.convert

import androidx.activity.compose.LocalActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.mimeTypes
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videotomp3.app.SharedContent
import com.videotomp3.app.ShareBus
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskStatus
import com.videotomp3.app.ui.components.InfoText
import com.videotomp3.app.ui.components.LargeButton
import com.videotomp3.app.ui.components.SectionCard
import com.videotomp3.app.ui.components.SelectorField
import com.videotomp3.app.ui.components.SwitchRow
import com.videotomp3.app.ui.theme.SuccessGreen
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.InputFormats
import com.videotomp3.core.TimeText

@Composable
fun ConvertScreen(shareBus: ShareBus, snackbar: SnackbarHostState, wide: Boolean, vm: ConvertViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val conversions by vm.conversions.collectAsStateWithLifecycle()
    val folder by vm.folderLabel.collectAsStateWithLifecycle()
    val shared by shareBus.shared.collectAsStateWithLifecycle()
    val pickRequested by shareBus.pickVideos.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> vm.addFiles(uris) }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.setCover(uri) }
    val openPicker = { picker.launch(InputFormats.pickerMimeTypes) }

    LaunchedEffect(shared) {
        if (shared is SharedContent.Videos) (shareBus.consumeShared() as? SharedContent.Videos)?.let { vm.addFiles(it.uris) }
    }
    LaunchedEffect(pickRequested) {
        if (pickRequested) {
            shareBus.pickerHandled()
            openPicker()
        }
    }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    // Drag & drop (tablets, foldables, ChromeOS, split-screen): accept dropped video files.
    val activity = LocalActivity.current
    var dragHover by remember { mutableStateOf(false) }
    val dropTarget = remember(vm, activity) {
        object : DragAndDropTarget {
            override fun onDrop(event: DragAndDropEvent): Boolean {
                dragHover = false
                val dragEvent = event.toAndroidDragEvent()
                activity?.requestDragAndDropPermissions(dragEvent)
                val clip = dragEvent.clipData ?: return false
                val uris = (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
                vm.addFiles(uris)
                return uris.isNotEmpty()
            }
            override fun onEntered(event: DragAndDropEvent) { dragHover = true }
            override fun onExited(event: DragAndDropEvent) { dragHover = false }
            override fun onEnded(event: DragAndDropEvent) { dragHover = false }
        }
    }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Video Converter", style = MaterialTheme.typography.headlineSmall)

        Card(
            modifier = Modifier.fillMaxWidth().dragAndDropTarget(
                shouldStartDragAndDrop = { e -> e.mimeTypes().any { InputFormats.isVideoMime(it) || it == "application/octet-stream" } },
                target = dropTarget,
            ),
            shape = MaterialTheme.shapes.large,
            border = BorderStroke(2.dp, if (dragHover) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
            colors = CardDefaults.cardColors(
                containerColor = if (dragHover) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
            ),
            onClick = openPicker,
        ) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.UploadFile, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                Text("Select videos to convert", style = MaterialTheme.typography.titleMedium)
                Text(
                    "MP4, MOV, AVI, MKV, WEBM, FLV, 3GP · multiple files for batch conversion · works offline\nor drag & drop videos here",
                    style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = openPicker, modifier = Modifier.padding(top = 4.dp)) {
                    Icon(Icons.Rounded.VideoFile, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Select Video")
                }
            }
        }

        AnimatedVisibility(state.files.isNotEmpty()) {
            SectionCard(title = "Selected videos (${state.files.size})", icon = Icons.Rounded.VideoFile) {
                state.files.forEach { f -> SelectedVideoRow(f, vm) }
                TextButton(onClick = vm::clear) { Text("Clear all") }
            }
        }

        SectionCard(title = "Output settings", icon = Icons.Rounded.Tune) {
            SelectorField("Output format", AudioFormat.entries, state.format, { it.label }, vm::setFormat)
            SelectorField(
                "Audio bitrate", AudioQuality.entries, state.quality, { it.label }, vm::setQuality,
                enabled = !state.format.lossless,
                supportingText = if (state.format.lossless) "Lossless format – bitrate not needed" else "Original keeps the source audio untouched when possible",
            )
            OutlinedTextField(state.title, vm::setTitle, label = { Text("Title (blank = file name)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(state.artist, vm::setArtist, label = { Text("Artist") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(state.album, vm::setAlbum, label = { Text("Album") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(state.start, vm::setStart, label = { Text("Trim start (mm:ss)") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(state.end, vm::setEnd, label = { Text("Trim end (mm:ss)") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            SwitchRow(
                "Embed album artwork", state.embedArtwork, vm::setEmbedArtwork,
                subtitle = state.coverName?.let { "Image: $it" } ?: "Uses a frame from the video (MP3, M4A, FLAC)",
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Icon(Icons.Rounded.Image, null)
                    Spacer(Modifier.size(6.dp))
                    Text("Choose artwork")
                }
                if (state.coverUri != null) TextButton(onClick = { vm.setCover(null) }) { Text("Remove") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                InfoText("Saved to: $folder (change in Settings)")
            }
            state.error?.let { InfoText(it, color = MaterialTheme.colorScheme.error) }
            LargeButton(
                if (state.starting) "Starting…" else "Start Conversion" + if (state.files.size > 1) " (${state.files.size})" else "",
                Icons.Rounded.PlayArrow, onClick = vm::startConversion,
                modifier = Modifier.fillMaxWidth(), enabled = state.files.isNotEmpty() && !state.starting,
            )
        }

        AnimatedVisibility(conversions.isNotEmpty()) {
            SectionCard(title = "Conversion progress", icon = Icons.Rounded.AudioFile) {
                conversions.forEach { ConversionRow(it, onCancel = { vm.cancel(it.id) }) }
            }
        }
    }
}

@Composable
private fun SelectedVideoRow(f: SelectedVideo, vm: ConvertViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VideoFile, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val details = listOfNotNull(
                    f.size?.let { TimeText.bytes(it) },
                    f.durationSec?.let { TimeText.duration(it) },
                    if (f.width != null && f.height != null) "${f.width}×${f.height}" else null,
                    when (f.hasAudio) { true -> "audio ✓"; false -> "no audio track!"; null -> if (f.loading) "reading…" else null },
                )
                Text(details.joinToString(" · "), style = MaterialTheme.typography.bodySmall,
                    color = if (f.hasAudio == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { vm.remove(f.uri) }) { Icon(Icons.Rounded.Close, "Remove") }
        }
        OutlinedTextField(
            f.outputName, { vm.setOutputName(f.uri, it) }, label = { Text("Output file name") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ConversionRow(task: TaskEntity, onCancel: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(task.outputDisplayName ?: task.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (task.status.isActive) TextButton(onClick = onCancel) { Text("Cancel") }
        }
        when (task.status) {
            TaskStatus.RUNNING, TaskStatus.QUEUED, TaskStatus.PAUSED -> {
                if (task.progress < 0 || task.status != TaskStatus.RUNNING) LinearProgressIndicator(Modifier.fillMaxWidth())
                else LinearProgressIndicator(progress = { task.progress / 100f }, modifier = Modifier.fillMaxWidth())
                InfoText(listOf(task.phase, if (task.progress >= 0 && task.status == TaskStatus.RUNNING) "${task.progress.toInt()}%" else "", task.speed, task.eta.let { if (it.isBlank()) "" else "ETA $it" })
                    .filter { it.isNotBlank() }.joinToString(" · "))
            }
            TaskStatus.COMPLETED -> InfoText("✓ Completed · ${task.outputDisplayName}", color = SuccessGreen)
            TaskStatus.FAILED -> InfoText("Failed: ${task.error}", color = MaterialTheme.colorScheme.error)
            TaskStatus.CANCELLED -> InfoText("Cancelled")
        }
    }
}

