package com.videotomp3.app.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videotomp3.app.BuildConfig
import com.videotomp3.app.data.AppSettings
import com.videotomp3.app.data.SettingsRepository
import com.videotomp3.app.data.StorageRepository
import com.videotomp3.app.data.TaskRepository
import com.videotomp3.app.data.ThemeMode
import com.videotomp3.app.engine.MediaEngine
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class StorageInfo(val outputBytes: Long = 0, val tempBytes: Long = 0, val freeBytes: Long = 0, val totalBytes: Long = 0)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val storage: StorageRepository,
    private val tasks: TaskRepository,
    private val engine: MediaEngine,
) : ViewModel() {
    val state: StateFlow<AppSettings> = settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val folderLabel: StateFlow<String> = settings.settings.map { storage.folderLabel(it.outputFolderUri) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val outputBytes: StateFlow<Long> = tasks.outputBytes.stateIn(viewModelScope, SharingStarted.Eagerly, 0L)

    private val _storage = MutableStateFlow(StorageInfo())
    val storageInfo: StateFlow<StorageInfo> = _storage.asStateFlow()

    private val _engine = MutableStateFlow("Checking…")
    val engineInfo: StateFlow<String> = _engine.asStateFlow()
    private val _updating = MutableStateFlow(false)
    val updating: StateFlow<Boolean> = _updating.asStateFlow()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    val appVersion = BuildConfig.VERSION_NAME

    init {
        refreshStorage()
        viewModelScope.launch { _engine.value = engine.ytDlpVersion()?.let { "yt-dlp $it · FFmpeg 7.1 (bundled)" } ?: "Preparing media engine…" }
    }

    fun refreshStorage() = viewModelScope.launch {
        _storage.value = withContext(Dispatchers.IO) {
            StorageInfo(tempBytes = storage.tempBytes(), freeBytes = storage.freeBytes(), totalBytes = storage.totalBytes())
        }
    }

    fun chooseFolder(uri: Uri?) {
        uri ?: return
        viewModelScope.launch {
            try {
                storage.persistFolder(uri)
                state.value.outputFolderUri?.let { old -> if (old != uri.toString()) storage.releaseFolder(Uri.parse(old)) }
                settings.setOutputFolder(uri.toString())
                _messages.send("Files will be saved to ${storage.folderLabel(uri.toString())}")
            } catch (e: SecurityException) {
                _messages.send("This folder cannot be used. Please choose another one.")
            }
        }
    }

    fun resetFolder() = viewModelScope.launch {
        state.value.outputFolderUri?.let { storage.releaseFolder(Uri.parse(it)) }
        settings.setOutputFolder(null)
    }

    fun setFormat(f: AudioFormat) = viewModelScope.launch { settings.setDefaultFormat(f) }
    fun setQuality(q: AudioQuality) = viewModelScope.launch { settings.setQuality(q) }
    fun setVideoHeight(h: Int) = viewModelScope.launch { settings.setVideoHeight(h) }
    fun setWifiOnly(v: Boolean) = viewModelScope.launch { settings.setWifiOnly(v) }
    fun setTheme(t: ThemeMode) = viewModelScope.launch { settings.setTheme(t) }
    fun setMaxConcurrent(n: Int) = viewModelScope.launch { settings.setMaxConcurrent(n) }
    fun setVibrate(v: Boolean) = viewModelScope.launch { settings.setVibrate(v) }
    fun setSound(v: Boolean) = viewModelScope.launch { settings.setSound(v) }
    fun setEmbedArtwork(v: Boolean) = viewModelScope.launch { settings.setEmbedArtwork(v) }

    fun clearHistory() = viewModelScope.launch {
        tasks.clearHistory()
        _messages.send("Download history cleared (saved files are kept)")
    }

    fun clearTemp() = viewModelScope.launch {
        tasks.clearTemporaryFiles()
        refreshStorage()
        _messages.send("Temporary files removed")
    }

    fun updateDownloader() {
        if (_updating.value) return
        _updating.update { true }
        viewModelScope.launch {
            try {
                val result = engine.updateYtDlp()
                _messages.send(result)
                _engine.value = engine.ytDlpVersion()?.let { "yt-dlp $it · FFmpeg 7.1 (bundled)" } ?: _engine.value
            } catch (e: Exception) {
                _messages.send("Update failed: ${e.message ?: "network error"}")
            } finally {
                _updating.value = false
            }
        }
    }
}
