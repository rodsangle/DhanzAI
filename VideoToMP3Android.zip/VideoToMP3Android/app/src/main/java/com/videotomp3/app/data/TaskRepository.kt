package com.videotomp3.app.data

import android.net.Uri
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.videotomp3.app.work.TaskWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** Creates and controls download / conversion tasks (persisted in Room, executed by WorkManager). */
@Singleton
class TaskRepository @Inject constructor(
    private val dao: TaskDao,
    private val workManager: WorkManager,
    private val storage: StorageRepository,
) {
    val tasks: Flow<List<TaskEntity>> = dao.observeAll()
    val outputBytes: Flow<Long> = dao.observeOutputBytes()

    private fun workName(id: Long) = "task-$id"

    private fun schedule(task: TaskEntity) {
        val network = when {
            task.kind == TaskKind.CONVERT -> NetworkType.NOT_REQUIRED
            task.wifiOnly -> NetworkType.UNMETERED
            else -> NetworkType.CONNECTED
        }
        val request = OneTimeWorkRequestBuilder<TaskWorker>()
            .setInputData(workDataOf(TaskWorker.KEY_TASK_ID to task.id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(network).build())
            .addTag(TaskWorker.TAG)
            .build()
        workManager.enqueueUniqueWork(workName(task.id), ExistingWorkPolicy.REPLACE, request)
    }

    suspend fun enqueue(task: TaskEntity): Long {
        val id = dao.insert(task.copy(status = TaskStatus.QUEUED, phase = waitingPhase(task)))
        schedule(task.copy(id = id))
        return id
    }

    /**
     * Prepares a local video for background conversion: picked documents keep a persisted read
     * permission; shared or dragged-in files (temporary permission) are copied into app storage.
     */
    suspend fun prepareSource(uri: Uri): Pair<String, Boolean> = withContext(Dispatchers.IO) {
        if (storage.hasPersistedRead(uri) || storage.tryPersistRead(uri)) uri.toString() to false
        else storage.importToAppStorage(uri).toString() to true
    }

    private fun waitingPhase(task: TaskEntity) = when {
        task.kind == TaskKind.DOWNLOAD && task.wifiOnly -> "Waiting in queue (Wi-Fi only)"
        else -> "Waiting in queue"
    }

    suspend fun cancel(id: Long) {
        val task = dao.get(id) ?: return
        if (task.status.isFinished) return
        dao.setStatus(id, TaskStatus.CANCELLED, "Cancelled")
        workManager.cancelUniqueWork(workName(id))
        if (task.status == TaskStatus.PAUSED || task.status == TaskStatus.QUEUED) storage.workDir(id).deleteRecursively()
    }

    /** Pausing stops yt-dlp but keeps the partial download, so Resume continues where it stopped (if the site supports it). */
    suspend fun pause(id: Long) {
        val task = dao.get(id) ?: return
        if (!task.canPause || !(task.status == TaskStatus.RUNNING || task.status == TaskStatus.QUEUED)) return
        dao.setStatus(id, TaskStatus.PAUSED, "Paused")
        workManager.cancelUniqueWork(workName(id))
    }

    suspend fun resume(id: Long) = restart(id, setOf(TaskStatus.PAUSED))

    suspend fun retry(id: Long) = restart(id, setOf(TaskStatus.FAILED, TaskStatus.CANCELLED))

    private suspend fun restart(id: Long, allowed: Set<TaskStatus>) {
        val task = dao.get(id) ?: return
        if (task.status !in allowed) return
        val queued = task.copy(status = TaskStatus.QUEUED, phase = waitingPhase(task), error = null, speed = "", eta = "",
            progress = if (task.status == TaskStatus.PAUSED) task.progress else 0f, finishedAt = null)
        dao.update(queued)
        schedule(queued)
    }

    /** Removes a task from the list and optionally deletes its output file. Returns false if the file could not be deleted. */
    suspend fun delete(id: Long, deleteFile: Boolean): Boolean = withContext(Dispatchers.IO) {
        val task = dao.get(id) ?: return@withContext true
        if (task.status.isActive) {
            dao.setStatus(id, TaskStatus.CANCELLED, "Cancelled")
            workManager.cancelUniqueWork(workName(id))
        }
        var ok = true
        if (deleteFile) task.outputUri?.let { ok = storage.deleteOutput(Uri.parse(it)) }
        if (task.sourceIsImported) storage.deleteImported(task.source)
        storage.workDir(id).deleteRecursively()
        dao.delete(id)
        ok
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        val finished = dao.allTasks().filter { it.status.isFinished }
        finished.filter { it.sourceIsImported }.forEach { storage.deleteImported(it.source) }
        dao.deleteFinished()
    }

    suspend fun clearTemporaryFiles() = withContext(Dispatchers.IO) {
        val all = dao.allTasks()
        val keepIds = all.filter { it.status.isActive || it.status == TaskStatus.FAILED }.map { it.id }.toSet()
        val keepImports = all.filter { it.sourceIsImported && it.status != TaskStatus.COMPLETED }.map { it.source }.toSet()
        storage.clearTemp(keepIds, keepImports)
    }

    /**
     * After a crash or force-stop, tasks may be marked RUNNING/QUEUED although WorkManager no longer
     * has work for them. Such tasks are marked as interrupted so the user can retry them.
     */
    suspend fun recoverInterruptedTasks() = withContext(Dispatchers.IO) {
        for (task in dao.pending()) {
            val infos = runCatching { workManager.getWorkInfosForUniqueWork(workName(task.id)).get() }.getOrDefault(emptyList())
            val alive = infos.any { !it.state.isFinished }
            if (!alive) dao.markFailed(task.id, "Interrupted (the app was closed or restarted). Tap Retry.", System.currentTimeMillis())
            if (alive && infos.all { it.state == WorkInfo.State.ENQUEUED } && task.status == TaskStatus.RUNNING) {
                dao.setStatus(task.id, TaskStatus.QUEUED, waitingPhase(task))
            }
        }
    }
}
