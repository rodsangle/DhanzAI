package com.videotomp3.app

import android.app.Application
import android.util.Log
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.videotomp3.app.data.TaskRepository
import com.videotomp3.app.engine.MediaEngine
import com.videotomp3.app.work.TaskNotifier
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class VideoToMp3App : Application(), Configuration.Provider {
    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var mediaEngine: MediaEngine
    @Inject lateinit var taskRepository: TaskRepository
    @Inject lateinit var notifier: TaskNotifier

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        notifier.createChannels()
        mediaEngine.initializeAsync()
        appScope.launch { runCatching { taskRepository.recoverInterruptedTasks() } }
    }
}
