package com.videotomp3.app.ui.convert

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.videotomp3.app.data.SettingsRepository
import com.videotomp3.app.data.StorageRepository
import com.videotomp3.app.data.TaskEntity
import com.videotomp3.app.data.TaskKind
import com.videotomp3.app.data.TaskRepository
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.FileNames
import com.videotomp3.core.InputFormats
import com.videotomp3.core.TimeText
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class SelectedVideo(
    val uri: Uri,
    val name: String,
    val size: Long?,
    val outputName: String,
    val durationSec: Double? = null,
    val width: Int? = null,
    val height: Int? = null,
    /** null = unknown (container not readable by Android's metadata reader; FFmpeg will check). */
    val hasAudio: Boolean? = null,
    val loading: Boolean = true,
)

data class ConvertUiState(
    val files: List<SelectedVideo> = emptyList(),
    val format: AudioFormat = AudioFormat.MP3,
    val quality: AudioQuality = AudioQuality.K192,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val start: String = "",
    val end: String = "",
    val embedArtwork: Boolean = true,
    val coverUri: Uri? = null,
    val coverName: String? = null,
    val starting: Boolean = false,
    val error: String? = null,
)

@HiltViewModel
class ConvertViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val storage: StorageRepository,
    private val tasks: TaskRepository,
    private val settings: SettingsRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(ConvertUiState())
    val state: StateFlow<ConvertUiState> = _state.asStateFlow()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private val sessionStart = System.currentTimeMillis()

    /** Conversions started in this session: running ones plus the most recent finished ones. */
    val conversions: StateFlow<List<TaskEntity>> = tasks.tasks
        .map { list -> list.filter { it.kind == TaskKind.CONVERT && (it.status.isActive || it.createdAt >= sessionStart) }.take(8) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folderLabel: StateFlow<String> = settings.settings.map { storage.folderLabel(it.outputFolderUri) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    init {
        viewModelScope.launch {
            val s = settings.current()
            _state.update { it.copy(format = s.defaultFormat, quality = s.quality, embedArtwork = s.embedArtwork) }
        }
    }

    fun addFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val rejected = mutableListOf<String>()
            val added = mutableListOf<SelectedVideo>()
            withContext(Dispatchers.IO) {
                val known = _state.value.files.map { it.uri }.toSet()
                for (uri in uris.distinct()) {
                    if (uri in known) continue
                    val meta = storage.queryMeta(uri)
                    if (!InputFormats.isVideoMime(meta.mime) && !InputFormats.isSupportedName(meta.name)) {
                        rejected += meta.name
                        continue
                    }
                    storage.tryPersistRead(uri) // keeps access for background conversion when possible
                    added += SelectedVideo(uri, meta.name, meta.size, FileNames.sanitize(FileNames.stemOf(meta.name)))
                }
            }
            _state.update { it.copy(files = it.files + added, error = null) }
            if (rejected.isNotEmpty()) _messages.send("Not a supported video: ${rejected.joinToString(", ").take(120)}")
            added.forEach { probe(it.uri) }
        }
    }

    private fun probe(uri: Uri) = viewModelScope.launch {
        val result = withContext(Dispatchers.IO) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(context, uri)
                val duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.div(1000.0)
                val audio = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
                val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                Triple(duration, audio?.let { it == "yes" }, w to h)
            } catch (e: Exception) {
                null // e.g. AVI/FLV: Android cannot read them, FFmpeg can
            } finally {
                runCatching { mmr.release() }
            }
        }
        _state.update { st ->
            st.copy(files = st.files.map { f ->
                if (f.uri != uri) f
                else if (result == null) f.copy(loading = false)
                else f.copy(loading = false, durationSec = result.first, hasAudio = result.second, width = result.third.first, height = result.third.second)
            })
        }
    }

    fun remove(uri: Uri) = _state.update { st -> st.copy(files = st.files.filterNot { it.uri == uri }) }
    fun clear() = _state.update { it.copy(files = emptyList()) }
    fun setOutputName(uri: Uri, name: String) = _state.update { st ->
        st.copy(files = st.files.map { if (it.uri == uri) it.copy(outputName = name) else it })
    }

    fun setFormat(f: AudioFormat) {
        _state.update { it.copy(format = f) }
        viewModelScope.launch { settings.setDefaultFormat(f) }
    }

    fun setQuality(q: AudioQuality) {
        _state.update { it.copy(quality = q) }
        viewModelScope.launch { settings.setQuality(q) }
    }

    fun setTitle(v: String) = _state.update { it.copy(title = v) }
    fun setArtist(v: String) = _state.update { it.copy(artist = v) }
    fun setAlbum(v: String) = _state.update { it.copy(album = v) }
    fun setStart(v: String) = _state.update { it.copy(start = v) }
    fun setEnd(v: String) = _state.update { it.copy(end = v) }
    fun setEmbedArtwork(v: Boolean) {
        _state.update { it.copy(embedArtwork = v) }
        viewModelScope.launch { settings.setEmbedArtwork(v) }
    }

    fun setCover(uri: Uri?) {
        if (uri == null) {
            _state.update { it.copy(coverUri = null, coverName = null) }
            return
        }
        storage.tryPersistRead(uri)
        _state.update { it.copy(coverUri = uri, coverName = storage.queryMeta(uri).name, embedArtwork = true) }
    }

    fun startConversion() {
        val s = _state.value
        if (s.files.isEmpty() || s.starting) return
        val start: Double?
        val end: Double?
        try {
            start = TimeText.parse(s.start)
            end = TimeText.parse(s.end)
        } catch (e: IllegalArgumentException) {
            _state.update { it.copy(error = e.message) }
            return
        }
        if (start != null && end != null && end <= start) {
            _state.update { it.copy(error = "The trim end time must be later than the start time.") }
            return
        }
        _state.update { it.copy(starting = true, error = null) }
        viewModelScope.launch {
            try {
                val prefs = settings.current()
                for (file in s.files) {
                    // Picked files keep a persisted permission; shared/dropped ones are copied first.
                    val (source, imported) = tasks.prepareSource(file.uri)
                    val name = FileNames.sanitize(file.outputName.ifBlank { FileNames.stemOf(file.name) })
                    tasks.enqueue(
                        TaskEntity(
                            kind = TaskKind.CONVERT,
                            source = source,
                            title = file.name,
                            outputName = name,
                            format = s.format.name,
                            quality = s.quality.name,
                            startSec = start,
                            endSec = end,
                            metaTitle = s.title.trim().ifBlank { name },
                            metaArtist = s.artist.trim().ifBlank { null },
                            metaAlbum = s.album.trim().ifBlank { null },
                            embedArtwork = s.embedArtwork,
                            coverUri = s.coverUri?.toString(),
                            outputFolderUri = prefs.outputFolderUri,
                            sourceIsImported = imported,
                        ),
                    )
                }
                _messages.send("Converting ${s.files.size} video(s) to ${s.format.extension.uppercase()}. Progress is shown below and in Downloads.")
                _state.update { it.copy(files = emptyList(), starting = false) }
            } catch (e: Exception) {
                _state.update { it.copy(starting = false, error = "Could not start: ${e.message}") }
            }
        }
    }

    fun cancel(id: Long) = viewModelScope.launch { tasks.cancel(id) }
}
