package com.videotomp3.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

enum class TaskKind { DOWNLOAD, CONVERT }

enum class TaskStatus {
    QUEUED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED;

    val isActive get() = this == QUEUED || this == RUNNING || this == PAUSED
    val isFinished get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

/** Output format value used for video downloads (all other values are [com.videotomp3.core.AudioFormat] names). */
const val FORMAT_MP4 = "MP4"

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: TaskKind,
    /** Video URL (downloads) or content:// / file:// URI (conversions). */
    val source: String,
    val title: String,
    /** Desired output file name without extension. */
    val outputName: String,
    /** AudioFormat name or [FORMAT_MP4]. */
    val format: String,
    val quality: String,
    val videoHeight: Int? = null,
    val startSec: Double? = null,
    val endSec: Double? = null,
    val metaTitle: String? = null,
    val metaArtist: String? = null,
    val metaAlbum: String? = null,
    val embedArtwork: Boolean = true,
    val coverUri: String? = null,
    /** SAF tree URI chosen by the user, or null for the default MediaStore folder. */
    val outputFolderUri: String? = null,
    val wifiOnly: Boolean = false,
    /** True when [source] is a private copy in app storage that must be deleted with the task. */
    val sourceIsImported: Boolean = false,
    val status: TaskStatus = TaskStatus.QUEUED,
    val phase: String = "Waiting in queue",
    /** 0..100, or -1 when indeterminate. */
    val progress: Float = 0f,
    val speed: String = "",
    val eta: String = "",
    val totalBytes: Long? = null,
    val error: String? = null,
    val outputUri: String? = null,
    val outputDisplayName: String? = null,
    val outputMime: String? = null,
    val outputSize: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val startedAt: Long? = null,
    val finishedAt: Long? = null,
    val attempts: Int = 0,
) {
    val isVideo get() = format == FORMAT_MP4
    val canPause get() = kind == TaskKind.DOWNLOAD
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun get(id: Long): TaskEntity?

    @Query("SELECT * FROM tasks WHERE status IN ('QUEUED', 'RUNNING')")
    suspend fun pending(): List<TaskEntity>

    @Query("SELECT * FROM tasks")
    suspend fun allTasks(): List<TaskEntity>

    @Insert
    suspend fun insert(task: TaskEntity): Long

    @Update
    suspend fun update(task: TaskEntity)

    @Query("UPDATE tasks SET status = :status, phase = :phase, error = :error, speed = '', eta = '' WHERE id = :id")
    suspend fun setStatus(id: Long, status: TaskStatus, phase: String, error: String? = null)

    /** Progress updates only apply while running, so they can never overwrite a pause/cancel request. */
    @Query(
        "UPDATE tasks SET phase = :phase, progress = :progress, speed = :speed, eta = :eta, " +
            "totalBytes = COALESCE(:totalBytes, totalBytes) WHERE id = :id AND status = 'RUNNING'",
    )
    suspend fun updateProgress(id: Long, phase: String, progress: Float, speed: String, eta: String, totalBytes: Long?)

    @Query("UPDATE tasks SET status = 'RUNNING', phase = 'Starting', progress = -1, error = NULL, startedAt = :now, attempts = attempts + 1 WHERE id = :id AND status IN ('QUEUED', 'RUNNING')")
    suspend fun markRunning(id: Long, now: Long): Int

    @Query(
        "UPDATE tasks SET status = 'COMPLETED', phase = 'Completed', progress = 100, speed = '', eta = '', error = NULL, " +
            "outputUri = :uri, outputDisplayName = :name, outputMime = :mime, outputSize = :size, finishedAt = :now WHERE id = :id",
    )
    suspend fun markCompleted(id: Long, uri: String, name: String, mime: String, size: Long?, now: Long)

    @Query("UPDATE tasks SET status = 'FAILED', phase = 'Failed', error = :error, speed = '', eta = '', finishedAt = :now WHERE id = :id")
    suspend fun markFailed(id: Long, error: String, now: Long)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM tasks WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED')")
    suspend fun deleteFinished()

    @Query("SELECT COALESCE(SUM(outputSize), 0) FROM tasks WHERE status = 'COMPLETED'")
    fun observeOutputBytes(): Flow<Long>
}

@Database(entities = [TaskEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
}
