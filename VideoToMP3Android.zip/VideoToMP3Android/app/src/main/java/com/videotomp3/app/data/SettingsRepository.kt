package com.videotomp3.app.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class ThemeMode(val label: String) { SYSTEM("System default"), LIGHT("Light"), DARK("Dark") }

data class AppSettings(
    val outputFolderUri: String? = null,
    val defaultFormat: AudioFormat = AudioFormat.MP3,
    val quality: AudioQuality = AudioQuality.K192,
    val videoHeight: Int = 1080,
    val wifiOnly: Boolean = false,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val maxConcurrent: Int = 2,
    val vibrate: Boolean = true,
    val sound: Boolean = false,
    val embedArtwork: Boolean = true,
)

@Singleton
class SettingsRepository @Inject constructor(private val store: DataStore<Preferences>) {
    private object Keys {
        val folder = stringPreferencesKey("output_folder_uri")
        val format = stringPreferencesKey("default_format")
        val quality = stringPreferencesKey("audio_quality")
        val height = intPreferencesKey("video_height")
        val wifiOnly = booleanPreferencesKey("wifi_only")
        val theme = stringPreferencesKey("theme")
        val maxConcurrent = intPreferencesKey("max_concurrent")
        val vibrate = booleanPreferencesKey("vibrate")
        val sound = booleanPreferencesKey("sound")
        val artwork = booleanPreferencesKey("embed_artwork")
    }

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            outputFolderUri = p[Keys.folder],
            defaultFormat = AudioFormat.fromName(p[Keys.format]),
            quality = AudioQuality.fromName(p[Keys.quality]),
            videoHeight = p[Keys.height] ?: 1080,
            wifiOnly = p[Keys.wifiOnly] ?: false,
            theme = ThemeMode.entries.firstOrNull { it.name == p[Keys.theme] } ?: ThemeMode.SYSTEM,
            maxConcurrent = (p[Keys.maxConcurrent] ?: 2).coerceIn(1, 5),
            vibrate = p[Keys.vibrate] ?: true,
            sound = p[Keys.sound] ?: false,
            embedArtwork = p[Keys.artwork] ?: true,
        )
    }

    suspend fun current(): AppSettings = settings.first()

    suspend fun setOutputFolder(uri: String?) = store.edit { prefs ->
        if (uri == null) {
            prefs.remove(Keys.folder)
        } else {
            prefs[Keys.folder] = uri
        }
    }
    suspend fun setDefaultFormat(f: AudioFormat) = store.edit { it[Keys.format] = f.name }
    suspend fun setQuality(q: AudioQuality) = store.edit { it[Keys.quality] = q.name }
    suspend fun setVideoHeight(h: Int) = store.edit { it[Keys.height] = h }
    suspend fun setWifiOnly(v: Boolean) = store.edit { it[Keys.wifiOnly] = v }
    suspend fun setTheme(t: ThemeMode) = store.edit { it[Keys.theme] = t.name }
    suspend fun setMaxConcurrent(n: Int) = store.edit { it[Keys.maxConcurrent] = n.coerceIn(1, 5) }
    suspend fun setVibrate(v: Boolean) = store.edit { it[Keys.vibrate] = v }
    suspend fun setSound(v: Boolean) = store.edit { it[Keys.sound] = v }
    suspend fun setEmbedArtwork(v: Boolean) = store.edit { it[Keys.artwork] = v }
}
