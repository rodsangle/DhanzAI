package com.videotomp3.app.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.annotation.CallSuper
import com.videotomp3.app.data.TaskRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Hilt injects BroadcastReceivers in super.onReceive(), which must therefore be a concrete method. */
abstract class HiltBroadcastReceiver : BroadcastReceiver() {
    @CallSuper
    override fun onReceive(context: Context, intent: Intent) = Unit
}

/** Handles the Cancel / Pause buttons of progress notifications. */
@AndroidEntryPoint
class NotificationActionReceiver : HiltBroadcastReceiver() {
    companion object {
        const val ACTION_CANCEL = "com.videotomp3.app.action.CANCEL"
        const val ACTION_PAUSE = "com.videotomp3.app.action.PAUSE"
        const val EXTRA_TASK_ID = "task_id"
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    }

    @Inject lateinit var repository: TaskRepository

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getLongExtra(EXTRA_TASK_ID, -1)
        if (id < 0) return
        val pending = goAsync()
        scope.launch {
            try {
                when (intent.action) {
                    ACTION_CANCEL -> repository.cancel(id)
                    ACTION_PAUSE -> repository.pause(id)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
