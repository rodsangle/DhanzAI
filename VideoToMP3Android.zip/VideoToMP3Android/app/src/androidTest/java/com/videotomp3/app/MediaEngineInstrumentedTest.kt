package com.videotomp3.app

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.videotomp3.app.engine.MediaEngine
import com.videotomp3.core.AudioFormat
import com.videotomp3.core.AudioQuality
import com.videotomp3.core.ConversionSpec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * Runs the bundled FFmpeg on the device/emulator: generates a test video with FFmpeg's own
 * test sources, converts it with the app's conversion engine and verifies the result.
 */
@RunWith(AndroidJUnit4::class)
class MediaEngineInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private val engine = MediaEngine(context)
    private lateinit var dir: File

    @Before
    fun setUp() = runBlocking {
        engine.ensureReady()
        dir = File(context.cacheDir, "instrumented-test").apply { deleteRecursively(); mkdirs() }
    }

    private suspend fun makeVideo(name: String, seconds: Int, audio: List<String>): File {
        val out = File(dir, name)
        engine.ffmpegRunner().run(
            listOf(
                "-hide_banner", "-nostdin", "-y", "-loglevel", "error",
                "-f", "lavfi", "-i", "testsrc=size=320x240:rate=15:duration=$seconds",
                "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100:duration=$seconds",
                "-shortest", "-c:v", "mpeg4",
            ) + audio + out.absolutePath,
        )
        return out
    }

    @Test
    fun mp4ToMp3At320kbps() = runBlocking {
        val video = makeVideo("sample.mp4", 6, listOf("-c:a", "aac", "-b:a", "128k"))
        val out = File(dir, "Mi canción ♫.mp3")
        engine.converter().convert(video, out, ConversionSpec(AudioFormat.MP3, AudioQuality.K320, title = "Título"), File(dir, "work"))
        val info = engine.ffmpegRunner().probe(out)
        assertEquals("mp3", info.audioCodec)
        assertEquals(320_000L, info.audioBitrate)
        assertFalse("video stream must be dropped", info.hasVideo)
        assertEquals(6.0, info.durationSec!!, 0.3)
    }

    @Test
    fun mkvToEveryOutputFormat() = runBlocking {
        val video = makeVideo("sample.mkv", 4, listOf("-c:a", "libmp3lame"))
        for (format in AudioFormat.entries) {
            val out = File(dir, "out.${format.extension}")
            engine.converter().convert(video, out, ConversionSpec(format, AudioQuality.K192, endSec = 2.0), File(dir, "work-$format"))
            val info = engine.ffmpegRunner().probe(out)
            assertTrue("$format has audio", info.hasAudio)
            assertEquals(format.name, 2.0, info.durationSec!!, 0.2)
        }
    }

    @Test
    fun cancellationStopsFfmpeg() = runBlocking {
        val video = makeVideo("long.mp4", 300, listOf("-c:a", "aac"))
        val out = File(dir, "long.mp3")
        var percent = 0.0
        val job = launch {
            engine.converter().convert(video, out, ConversionSpec(AudioFormat.MP3, AudioQuality.K320), File(dir, "work-long")) {
                percent = it.percent ?: 0.0
            }
        }
        withTimeout(60_000) { while (percent < 1.0) delay(50) }
        job.cancel()
        job.join()
        assertTrue(job.isCancelled)
        assertTrue(percent < 100.0)
    }
}
