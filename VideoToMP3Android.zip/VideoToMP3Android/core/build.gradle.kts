// Pure Kotlin/JVM module: conversion engine, FFmpeg/yt-dlp helpers. Unit-tested on the desktop JVM.
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.jvm)
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    api(libs.kotlinx.coroutines.core)
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
}

tasks.test {
    // Integration tests run the real `ffmpeg`, `ffprobe` and `yt-dlp` executables when they are on PATH.
    testLogging { events("passed", "skipped", "failed"); showStandardStreams = false }
    // Child processes receive UTF-8 arguments on Android; make the desktop test JVM behave the same.
    environment("LC_ALL", "C.UTF-8")
}
