package com.videotomp3.core

import java.io.File

/**
 * The complete local conversion pipeline: probe -> validate -> (cover art) -> FFmpeg -> verify.
 * Writes to [output] (a temporary file chosen by the caller); the caller moves it to the final location.
 */
class AudioConverter(private val runner: FfmpegRunner) {

    suspend fun probe(input: File): MediaInfo = runner.probe(input)

    suspend fun convert(
        input: File,
        output: File,
        spec: ConversionSpec,
        workDir: File,
        knownInfo: MediaInfo? = null,
        onProgress: (ConversionProgress) -> Unit = {},
    ): MediaInfo {
        if (!input.isFile) throw ConversionException("The source file could not be found.")
        val info = knownInfo ?: runner.probe(input)
        if (!info.hasAudio) throw ConversionException("This video has no audio track to extract.")
        val start = spec.startSec
        val end = spec.endSec
        if (start != null && end != null && end <= start) throw ConversionException("The trim end time must be later than the start time.")
        if (start != null && info.durationSec != null && start >= info.durationSec) {
            throw ConversionException("The trim start time is beyond the end of the media.")
        }

        workDir.mkdirs()
        var cover: File? = null
        if (spec.format.supportsCover) {
            val target = File(workDir, "cover.jpg")
            try {
                when {
                    spec.coverImage != null -> runner.run(FfmpegCommands.coverToJpeg(spec.coverImage, target))
                    spec.coverFromVideoFrame && info.hasVideo -> {
                        val at = ((info.durationSec ?: 0.0) * 0.1).coerceIn(0.0, 5.0)
                        runner.run(FfmpegCommands.videoFrame(input, at, target))
                    }
                }
                if (target.isFile && target.length() > 0) cover = target
            } catch (e: ConversionException) {
                cover = null // artwork is optional: never fail the conversion because of it
            }
        }

        val args = FfmpegCommands.audio(input, output, spec, info, cover)
        runner.run(args, FfmpegCommands.outputDuration(info, spec), onProgress)
        if (!output.isFile || output.length() == 0L) throw ConversionException("FFmpeg finished but produced an empty file.")
        return info
    }
}
