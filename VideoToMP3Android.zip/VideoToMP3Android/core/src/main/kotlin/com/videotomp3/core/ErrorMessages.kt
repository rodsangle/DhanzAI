package com.videotomp3.core

/** Turns raw FFmpeg / yt-dlp error output into short, understandable messages. */
object ErrorMessages {
    fun ffmpeg(stderr: String): String? {
        val t = stderr.lowercase()
        return when {
            "matches no streams" in t || "does not contain any stream" in t -> "This file has no audio track to extract."
            "invalid data found" in t || "moov atom not found" in t -> "The file is damaged or not a valid video file."
            "no space left" in t -> "Not enough free storage space for the output file."
            "permission denied" in t -> "Permission denied while reading or writing the file."
            "no such file" in t -> "The input file could not be found."
            "unknown encoder" in t || "encoder not found" in t -> "The bundled FFmpeg does not include the required audio encoder."
            else -> null
        }
    }

    private val hints: List<Pair<List<String>, String>> = listOf(
        listOf("drm") to "This video is protected by DRM and cannot be downloaded.",
        listOf("sign in to confirm your age", "age-restricted", "age restricted") to
            "This video is age-restricted and requires signing in. It cannot be downloaded by this app.",
        listOf("sign in to confirm you", "not a bot") to
            "The website is asking for a sign-in / bot check. Try again later; this app does not log in to websites.",
        listOf("private video", "this video is private", "is private") to "This video is private and cannot be downloaded.",
        listOf("login required", "log in", "login", "sign in", "cookies", "authentication", "account") to
            "This content requires signing in. This app only downloads publicly accessible media.",
        listOf("members-only", "members only", "join this channel", "premium", "payment", "purchase", "rental") to
            "This content is restricted to paying members or subscribers.",
        listOf("not available in your country", "geo restrict", "geo-restrict", "geoblock") to "This video is not available in your region.",
        listOf("unsupported url") to "This website or link type is not supported.",
        listOf("video unavailable", "has been removed", "no longer available", "does not exist", "http error 404", "not found") to
            "The video is unavailable (it may have been removed, or the link is wrong).",
        listOf("unable to connect to proxy", "proxyerror", "tunnel connection failed") to
            "Could not connect through the network proxy/firewall.",
        listOf("http error 403", "forbidden") to
            "The website refused the download (HTTP 403). The media may be restricted, or the downloader needs an update (Settings → Update).",
        listOf("http error 429", "too many requests") to "The website is rate-limiting requests. Wait a few minutes and try again.",
        listOf("live event will begin", "premieres in", "is_live", "live stream") to "Live streams and upcoming premieres cannot be downloaded.",
        listOf("getaddrinfo", "name or service not known", "no address associated", "temporary failure in name resolution",
            "network is unreachable", "connection refused", "connection reset", "timed out", "timeout",
            "unable to download webpage", "urlopen error", "remote end closed", "connection aborted", "eof occurred") to
            "Network error: the connection was lost or the website could not be reached. Check your connection and tap Retry.",
        listOf("requested format is not available", "no video formats found") to "No downloadable format was found for this link.",
        listOf("no space left") to "Not enough free storage space.",
    )

    fun download(message: String?): String {
        val t = message.orEmpty().lowercase()
        hints.firstOrNull { (needles, _) -> needles.any { it in t } }?.let { return it.second }
        val cleaned = message.orEmpty().lines().lastOrNull { it.contains("ERROR") } ?: message.orEmpty().lines().lastOrNull { it.isNotBlank() }
        return "Download failed: " + (cleaned ?: "unknown error").replace("ERROR: ", "").trim().take(240)
    }
}
