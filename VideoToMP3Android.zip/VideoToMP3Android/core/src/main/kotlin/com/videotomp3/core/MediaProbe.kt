package com.videotomp3.core

/** Parsers for media information printed by ffprobe (key=value) or `ffmpeg -i` (fallback). */
object MediaProbe {
    /** Arguments for ffprobe producing output understood by [parseFfprobe]. */
    fun ffprobeArgs(path: String) = listOf(
        "-v", "error",
        "-show_entries",
        "format=duration:stream=codec_type,codec_name,bit_rate,sample_rate,channels,width,height:stream_disposition=attached_pic",
        "-of", "default=noprint_wrappers=0",
        path,
    )

    fun parseFfprobe(text: String): MediaInfo {
        var info = MediaInfo()
        var section: String? = null
        var stream = mutableMapOf<String, String>()
        var formatDuration: Double? = null
        var streamDuration: Double? = null

        fun closeStream() {
            val type = stream["codec_type"]
            val attachedPic = stream["DISPOSITION:attached_pic"] == "1"
            if (type == "video" && !attachedPic && !info.hasVideo) {
                info = info.copy(
                    hasVideo = true,
                    videoWidth = stream["width"]?.toIntOrNull(),
                    videoHeight = stream["height"]?.toIntOrNull(),
                )
            } else if (type == "audio" && !info.hasAudio) {
                info = info.copy(
                    hasAudio = true,
                    audioCodec = stream["codec_name"],
                    audioBitrate = stream["bit_rate"]?.toLongOrNull(),
                    sampleRate = stream["sample_rate"]?.toIntOrNull(),
                    channels = stream["channels"]?.toIntOrNull(),
                )
            }
            stream = mutableMapOf()
        }

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line == "[STREAM]" -> section = "stream"
                line == "[/STREAM]" -> { closeStream(); section = null }
                line == "[FORMAT]" -> section = "format"
                line == "[/FORMAT]" -> section = null
                line.contains('=') -> {
                    val key = line.substringBefore('=')
                    val value = line.substringAfter('=')
                    if (section == "stream") stream[key] = value
                    if (section == "format" && key == "duration") formatDuration = value.toDoubleOrNull()
                    if (section == "stream" && key == "duration") streamDuration = value.toDoubleOrNull()
                }
            }
        }
        return info.copy(durationSec = formatDuration ?: streamDuration)
    }

    private val durationRe = Regex("Duration:\\s*(\\d+):(\\d+):(\\d+(?:\\.\\d+)?)")
    private val audioRe = Regex("Stream #\\d+:\\d+.*?: Audio: (\\w+)[^\\n]*?(\\d+) Hz(?:, ([^,\\n]+))?(?:[^\\n]*?(\\d+) kb/s)?")
    private val videoRe = Regex("Stream #\\d+:\\d+.*?: Video: [^\\n]*?(\\d{2,5})x(\\d{2,5})")

    /** Fallback parser for the stderr text of `ffmpeg -hide_banner -i <file>`. */
    fun parseFfmpegBanner(text: String): MediaInfo {
        var info = MediaInfo()
        durationRe.find(text)?.let { m ->
            info = info.copy(durationSec = m.groupValues[1].toInt() * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toDouble())
        }
        text.lineSequence().firstOrNull { ": Video:" in it && "attached pic" !in it }?.let { line ->
            val m = videoRe.find(line)
            info = info.copy(hasVideo = true, videoWidth = m?.groupValues?.get(1)?.toIntOrNull(), videoHeight = m?.groupValues?.get(2)?.toIntOrNull())
        }
        audioRe.find(text)?.let { m ->
            info = info.copy(
                hasAudio = true,
                audioCodec = m.groupValues[1],
                sampleRate = m.groupValues[2].toIntOrNull(),
                channels = when (m.groupValues[3].trim()) { "mono" -> 1; "stereo" -> 2; else -> null },
                audioBitrate = m.groupValues[4].toLongOrNull()?.times(1000),
            )
        }
        return info
    }
}
