package com.videotomp3.core

import java.io.File

/** Command-line options for yt-dlp. No credentials, cookies or DRM-related options are ever used. */
object YtDlpArgs {
    enum class Mode { AUDIO, VIDEO }

    /** Options for metadata extraction (the Android library adds `--dump-json`). */
    fun analyze(): List<String> = listOf("--no-playlist", "--socket-timeout", "30")

    fun videoFormatSelector(maxHeight: Int?): String {
        val cap = maxHeight?.let { "[height<=$it]" } ?: ""
        return "bv*[ext=mp4]$cap+ba[ext=m4a]/bv*$cap+ba/b[ext=mp4]$cap/b$cap/bv*+ba/b"
    }

    fun download(workDir: File, mode: Mode, maxHeight: Int?, writeThumbnail: Boolean): List<String> {
        val args = mutableListOf(
            "--no-playlist", "--newline", "--no-mtime", "--continue",
            "--retries", "10", "--fragment-retries", "10", "--socket-timeout", "30",
            "--windows-filenames",
            "-o", File(workDir, "media.%(ext)s").absolutePath,
            "-o", "thumbnail:" + File(workDir, "thumb.%(ext)s").absolutePath,
        )
        if (mode == Mode.AUDIO) {
            args += listOf("-f", "bestaudio/best")
            if (writeThumbnail) args += listOf("--write-thumbnail", "--convert-thumbnails", "jpg")
        } else {
            args += listOf("-f", videoFormatSelector(maxHeight), "--merge-output-format", "mp4")
        }
        return args
    }

    private val imageExt = setOf("jpg", "jpeg", "png", "webp")

    /** Finds the finished media file and optional thumbnail in a download work directory. */
    fun findOutputs(workDir: File): Pair<File?, File?> {
        val files = workDir.listFiles()?.filter { it.isFile } ?: emptyList()
        val media = files.filter { it.name.startsWith("media.") && it.extension.lowercase() !in imageExt &&
            !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !Regex("\\.f\\d+\\.").containsMatchIn(it.name) }
            .maxByOrNull { it.length() }
        val thumb = files.firstOrNull { it.name.startsWith("thumb.") && it.extension.lowercase() in imageExt }
        return media to thumb
    }
}

data class DownloadProgress(
    val percent: Double?,
    val totalBytes: Long?,
    val speedBytesPerSec: Double?,
    val etaSec: Long?,
)

/** Parses yt-dlp `[download]` progress lines. */
object YtDlpProgress {
    private val re = Regex(
        "\\[download]\\s+(\\d+(?:\\.\\d+)?)%\\s+of\\s+~?\\s*([\\d.]+)\\s*([KMGT]?i?B)" +
            "(?:\\s+at\\s+(?:([\\d.]+)\\s*([KMGT]?i?B)/s|[^E]*?))?" +
            "(?:\\s+ETA\\s+([\\d:]+))?",
    )

    private fun toBytes(value: String, unit: String): Long? {
        val v = value.toDoubleOrNull() ?: return null
        val mult = when (unit.uppercase().replace("I", "")) {
            "B" -> 1.0; "KB" -> 1024.0; "MB" -> 1024.0 * 1024; "GB" -> 1024.0 * 1024 * 1024; "TB" -> 1024.0 * 1024 * 1024 * 1024
            else -> return null
        }
        return (v * mult).toLong()
    }

    fun parse(line: String): DownloadProgress? {
        val m = re.find(line) ?: return null
        val g = m.groupValues
        val eta = g[6].takeIf { it.isNotEmpty() }?.split(":")?.mapNotNull { it.toLongOrNull() }?.fold(0L) { a, v -> a * 60 + v }
        return DownloadProgress(
            percent = g[1].toDoubleOrNull(),
            totalBytes = toBytes(g[2], g[3]),
            speedBytesPerSec = if (g[4].isNotEmpty()) toBytes(g[4], g[5])?.toDouble() else null,
            etaSec = eta,
        )
    }
}
