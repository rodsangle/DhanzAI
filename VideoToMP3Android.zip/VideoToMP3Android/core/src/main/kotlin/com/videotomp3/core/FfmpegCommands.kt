package com.videotomp3.core

import java.io.File
import java.util.Locale

/** Builds FFmpeg argument lists (without the executable itself). */
object FfmpegCommands {
    private fun Double.fmt() = String.format(Locale.US, "%.3f", this)

    fun canStreamCopy(format: AudioFormat, quality: AudioQuality, info: MediaInfo): Boolean =
        quality == AudioQuality.ORIGINAL && info.audioCodec in format.copyCodecs

    fun encoderArgs(format: AudioFormat, quality: AudioQuality, info: MediaInfo): List<String> {
        if (canStreamCopy(format, quality, info)) return listOf("-c:a", "copy")
        return when (format) {
            AudioFormat.WAV -> listOf("-c:a", "pcm_s16le")
            AudioFormat.FLAC -> listOf("-c:a", "flac", "-compression_level", "5")
            AudioFormat.MP3 -> quality.kbps?.let { listOf("-c:a", "libmp3lame", "-b:a", "${it}k") }
                ?: listOf("-c:a", "libmp3lame", "-q:a", "0") // highest-quality VBR (~245 kbps)
            AudioFormat.M4A, AudioFormat.AAC -> {
                val kbps = quality.kbps ?: if ((info.audioBitrate ?: 0) > 256_000) 320 else 256
                listOf("-c:a", "aac", "-b:a", "${kbps}k")
            }
        }
    }

    /**
     * Extracts/converts only the first audio stream of [input] into [output]. Video is never re-encoded:
     * it is simply not mapped (an optional cover image is attached instead).
     */
    fun audio(input: File, output: File, spec: ConversionSpec, info: MediaInfo, cover: File?): List<String> {
        val f = spec.format
        val args = mutableListOf("-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-nostats", "-progress", "pipe:1")
        spec.startSec?.takeIf { it > 0 }?.let { args += listOf("-ss", it.fmt()) }
        args += listOf("-i", input.absolutePath)
        val useCover = cover != null && f.supportsCover
        if (useCover) args += listOf("-i", cover!!.absolutePath)
        spec.endSec?.let { args += listOf("-t", (it - (spec.startSec ?: 0.0)).coerceAtLeast(0.0).fmt()) }
        args += listOf("-map", "0:a:0")
        if (useCover) {
            args += listOf(
                "-map", "1:v:0", "-c:v", if (f == AudioFormat.MP3) "mjpeg" else "copy",
                "-disposition:v:0", "attached_pic",
                "-metadata:s:v", "title=Album cover", "-metadata:s:v", "comment=Cover (front)",
            )
        }
        args += encoderArgs(f, spec.quality, info)
        listOf("title" to spec.title, "artist" to spec.artist, "album" to spec.album).forEach { (k, v) ->
            if (!v.isNullOrBlank()) args += listOf("-metadata", "$k=${v.trim()}")
        }
        if (f == AudioFormat.MP3) args += listOf("-id3v2_version", "3", "-write_id3v1", "1")
        if (f == AudioFormat.M4A) args += listOf("-movflags", "+faststart")
        args += listOf("-f", f.muxer, output.absolutePath)
        return args
    }

    /** Converts any image FFmpeg can read (webp/png/jpg) to a JPEG suitable for cover art. */
    fun coverToJpeg(image: File, output: File) = listOf(
        "-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-i", image.absolutePath,
        "-frames:v", "1", "-vf", "scale='min(1000,iw)':-2", "-q:v", "3", "-f", "image2", "-c:v", "mjpeg", output.absolutePath,
    )

    /** Grabs a single video frame (used as album artwork for local videos). */
    fun videoFrame(video: File, atSec: Double, output: File) = listOf(
        "-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-ss", atSec.fmt(), "-i", video.absolutePath,
        "-frames:v", "1", "-vf", "scale='min(1000,iw)':-2", "-q:v", "3", "-f", "image2", "-c:v", "mjpeg", output.absolutePath,
    )

    fun outputDuration(info: MediaInfo, spec: ConversionSpec): Double? {
        val total = info.durationSec
        if (total == null && spec.endSec == null) return null
        var end = spec.endSec ?: total!!
        if (total != null) end = minOf(end, total)
        return (end - (spec.startSec ?: 0.0)).coerceAtLeast(0.0)
    }
}

/** Incrementally parses FFmpeg `-progress pipe:1` key=value output. */
class FfmpegProgressParser(private val durationSec: Double?, private val clock: () -> Long = System::nanoTime) {
    private val started = clock()
    private var processed = 0.0
    private var speed: Double? = null

    /** Feed one line; returns a progress snapshot at the end of each progress block, otherwise null. */
    fun onLine(line: String): ConversionProgress? {
        val key = line.substringBefore('=').trim()
        val value = line.substringAfter('=', "").trim()
        when (key) {
            "out_time_us", "out_time_ms" -> value.toLongOrNull()?.let { processed = (it / 1_000_000.0).coerceAtLeast(0.0) }
            "speed" -> speed = value.removeSuffix("x").toDoubleOrNull()?.takeIf { it > 0 }
            "progress" -> {
                var percent: Double? = null
                var eta: Double? = null
                if (durationSec != null && durationSec > 0) {
                    percent = if (value == "end") 100.0 else (processed / durationSec * 100).coerceIn(0.0, 100.0)
                    val elapsed = (clock() - started) / 1e9
                    if (processed > 0) eta = ((durationSec - processed) * elapsed / processed).coerceAtLeast(0.0)
                }
                return ConversionProgress(percent, processed, speed, eta)
            }
        }
        return null
    }
}
