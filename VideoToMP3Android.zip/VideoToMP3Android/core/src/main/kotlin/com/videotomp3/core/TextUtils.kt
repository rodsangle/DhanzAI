package com.videotomp3.core

import java.util.Locale
import kotlin.math.roundToLong

object FileNames {
    private val invalid = Regex("[\\\\/:*?\"<>|\\x00-\\x1F]")
    private val reserved = setOf("CON", "PRN", "AUX", "NUL") + (1..9).flatMap { listOf("COM$it", "LPT$it") }
    const val MAX_STEM = 120

    /** Returns a file stem that is safe on Android shared storage (FAT/exFAT/ext4), keeping Unicode. */
    fun sanitize(name: String?, fallback: String = "audio"): String {
        var s = invalid.replace(name.orEmpty(), "_")
        s = s.replace(Regex("\\s+"), " ").trim().trimEnd('.', ' ').trimStart('.')
        if (s.length > MAX_STEM) s = s.take(MAX_STEM).trimEnd('.', ' ')
        if (s.isEmpty()) return fallback
        if (s.substringBefore('.').uppercase(Locale.ROOT) in reserved) s = "${fallback}_$s"
        return s
    }

    /** "name.ext", or "name (1).ext", "name (2).ext"… – the first name for which [exists] is false. */
    fun unique(stem: String, extension: String, exists: (String) -> Boolean): String {
        val first = "$stem.$extension"
        if (!exists(first)) return first
        var n = 1
        while (true) {
            val candidate = "$stem ($n).$extension"
            if (!exists(candidate)) return candidate
            n++
        }
    }

    fun stemOf(displayName: String): String = displayName.substringBeforeLast('.', displayName)
}

object TimeText {
    /** Parses "SS", "MM:SS" or "HH:MM:SS(.ms)". Blank -> null. Throws IllegalArgumentException when invalid. */
    fun parse(text: String?): Double? {
        val t = text?.trim()?.replace(',', '.') ?: return null
        if (t.isEmpty()) return null
        val parts = t.split(":")
        require(parts.size <= 3 && parts.none { it.isBlank() }) { "Invalid time \"$t\". Use HH:MM:SS, MM:SS or seconds." }
        val values = parts.map { it.toDoubleOrNull() ?: throw IllegalArgumentException("Invalid time \"$t\". Use HH:MM:SS, MM:SS or seconds.") }
        require(values.all { it >= 0 } && values.drop(1).all { it < 60 }) { "Invalid time \"$t\". Minutes and seconds must be below 60." }
        return values.fold(0.0) { acc, v -> acc * 60 + v }
    }

    fun duration(seconds: Double?): String {
        if (seconds == null || seconds < 0) return "--:--"
        val total = seconds.roundToLong()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun bytes(bytes: Long?): String {
        if (bytes == null || bytes < 0) return "–"
        if (bytes < 1024) return "$bytes B"
        var v = bytes.toDouble()
        for (unit in listOf("KB", "MB", "GB", "TB")) {
            v /= 1024
            if (v < 1024 || unit == "TB") return String.format(Locale.US, "%.1f %s", v, unit)
        }
        return "$bytes B"
    }

    fun speed(bytesPerSec: Double?): String = if (bytesPerSec == null || bytesPerSec <= 0) "" else bytes(bytesPerSec.toLong()) + "/s"
}

object Urls {
    private val urlInText = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE)

    /** Finds the first http(s) link in text shared from another app (e.g. "Watch this! https://…"). */
    fun extractFromText(text: String?): String? =
        text?.let { urlInText.find(it)?.value?.trimEnd('.', ',', ')', ']', '!', '?', ';') }

    /** Normalises and validates a URL typed or pasted by the user. Throws IllegalArgumentException with a readable message. */
    fun validate(input: String?): String {
        var url = input?.trim().orEmpty()
        require(url.isNotEmpty()) { "Please paste a video link first." }
        extractFromText(url)?.let { url = it }
        require(!url.contains(' ')) { "The link contains spaces. Paste a single, complete link." }
        if (!url.contains("://")) url = "https://$url"
        val uri = try {
            java.net.URI(url)
        } catch (e: Exception) {
            throw IllegalArgumentException("This does not look like a valid web address.")
        }
        require(uri.scheme?.lowercase() in setOf("http", "https")) { "Only http:// and https:// links are supported." }
        val host = uri.host.orEmpty()
        require(host.contains('.') || host == "localhost") { "This does not look like a valid web address." }
        return url
    }
}
