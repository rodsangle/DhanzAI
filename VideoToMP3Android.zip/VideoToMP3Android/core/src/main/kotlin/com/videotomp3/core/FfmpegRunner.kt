package com.videotomp3.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Runs the FFmpeg / FFprobe executables as child processes.
 * Works identically on a desktop JVM (tests) and on Android (binaries shipped as native libraries).
 * Cancelling the calling coroutine kills the process immediately.
 */
class FfmpegRunner(
    private val ffmpeg: String,
    private val ffprobe: String? = null,
    private val environment: Map<String, String> = emptyMap(),
) {
    private fun start(binary: String, args: List<String>): Process =
        try {
            ProcessBuilder(listOf(binary) + args).also { it.environment().putAll(environment) }.start()
        } catch (e: IOException) {
            throw ConversionException("Could not start FFmpeg: ${e.message}", e)
        }

    suspend fun probe(file: File): MediaInfo = withContext(Dispatchers.IO) {
        if (ffprobe != null) {
            val p = start(ffprobe, MediaProbe.ffprobeArgs(file.absolutePath))
            val err = async { p.errorStream.bufferedReader().readText() }
            val out = p.inputStream.bufferedReader().readText()
            if (p.waitFor() == 0) return@withContext MediaProbe.parseFfprobe(out)
            if ("Invalid data" in err.await() || "moov atom not found" in err.await()) {
                throw ConversionException("The file is damaged or not a valid video file.")
            }
        }
        val p = start(ffmpeg, listOf("-hide_banner", "-nostdin", "-i", file.absolutePath))
        p.inputStream.close()
        val text = p.errorStream.bufferedReader().readText()
        p.waitFor()
        if ("Invalid data found" in text || "moov atom not found" in text) {
            throw ConversionException("The file is damaged or not a valid video file.")
        }
        MediaProbe.parseFfmpegBanner(text)
    }

    /** Runs FFmpeg with [args]; [onProgress] receives updates when the args contain `-progress pipe:1`. */
    suspend fun run(args: List<String>, durationSec: Double? = null, onProgress: (ConversionProgress) -> Unit = {}) =
        coroutineScope {
            val process = withContext(Dispatchers.IO) { start(ffmpeg, args) }
            val stderrTail = ArrayDeque<String>()
            val errJob = launch(Dispatchers.IO) {
                process.errorStream.bufferedReader().forEachLine { line ->
                    synchronized(stderrTail) {
                        stderrTail.addLast(line)
                        if (stderrTail.size > 40) stderrTail.removeFirst()
                    }
                }
            }
            val outJob = async(Dispatchers.IO) {
                val parser = FfmpegProgressParser(durationSec)
                process.inputStream.bufferedReader().forEachLine { line -> parser.onLine(line)?.let(onProgress) }
                process.waitFor()
            }
            val exit = try {
                outJob.await().also { errJob.join() }
            } catch (e: CancellationException) {
                process.destroyForcibly()
                throw e
            }
            if (exit != 0) {
                val stderr = synchronized(stderrTail) { stderrTail.joinToString("\n") }
                throw ConversionException(
                    ErrorMessages.ffmpeg(stderr) ?: "FFmpeg could not convert this file (${stderr.lines().lastOrNull { it.isNotBlank() } ?: "exit code $exit"}).",
                )
            }
        }
}
