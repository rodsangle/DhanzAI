package com.videotomp3.core

/** Output audio formats supported by the converter. */
enum class AudioFormat(
    val label: String,
    val extension: String,
    val mimeType: String,
    /** FFmpeg muxer name passed with `-f`. */
    val muxer: String,
    val lossless: Boolean,
    val supportsCover: Boolean,
    /** Source codecs that can be stream-copied into this format without re-encoding. */
    val copyCodecs: Set<String>,
) {
    MP3("MP3", "mp3", "audio/mpeg", "mp3", false, true, setOf("mp3")),
    M4A("M4A (AAC)", "m4a", "audio/mp4", "ipod", false, true, setOf("aac", "alac")),
    AAC("AAC", "aac", "audio/aac", "adts", false, false, setOf("aac")),
    WAV("WAV (lossless)", "wav", "audio/wav", "wav", true, false, setOf("pcm_s16le")),
    FLAC("FLAC (lossless)", "flac", "audio/flac", "flac", true, true, setOf("flac"));

    companion object {
        fun fromName(name: String?): AudioFormat = entries.firstOrNull { it.name == name } ?: MP3
    }
}

/** Audio quality presets. [kbps] is null for "original" (best possible / stream copy). */
enum class AudioQuality(val kbps: Int?, val label: String) {
    ORIGINAL(null, "Original quality (best)"),
    K320(320, "320 kbps – Maximum MP3 bitrate"),
    K256(256, "256 kbps – High quality"),
    K192(192, "192 kbps – Standard quality"),
    K128(128, "128 kbps – Small file size");

    companion object {
        fun fromName(name: String?): AudioQuality = entries.firstOrNull { it.name == name } ?: K192
    }
}

/** Supported input containers. Android's picker is filtered by MIME type, the extension list is used for validation. */
object InputFormats {
    val extensions = setOf("mp4", "m4v", "mov", "avi", "mkv", "webm", "flv", "3gp", "3g2", "wmv", "ts", "mpg", "mpeg")
    val pickerMimeTypes = arrayOf("video/*", "application/x-matroska", "video/x-flv", "video/avi", "video/x-msvideo")

    fun isSupportedName(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in extensions

    fun isVideoMime(mime: String?): Boolean =
        mime != null && (mime.startsWith("video/") || mime == "application/x-matroska")
}

data class ConversionSpec(
    val format: AudioFormat = AudioFormat.MP3,
    val quality: AudioQuality = AudioQuality.K192,
    val startSec: Double? = null,
    val endSec: Double? = null,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    /** Image to embed as album artwork (any format FFmpeg reads). */
    val coverImage: java.io.File? = null,
    /** If no [coverImage] is given, grab a frame from the video and embed it. */
    val coverFromVideoFrame: Boolean = false,
)

data class MediaInfo(
    val durationSec: Double? = null,
    val hasAudio: Boolean = false,
    val hasVideo: Boolean = false,
    val audioCodec: String? = null,
    val audioBitrate: Long? = null,
    val sampleRate: Int? = null,
    val channels: Int? = null,
    val videoWidth: Int? = null,
    val videoHeight: Int? = null,
)

data class ConversionProgress(
    /** 0..100, or null while unknown. */
    val percent: Double?,
    val processedSec: Double,
    /** Processing speed relative to real time (e.g. 12.5x). */
    val speed: Double?,
    val etaSec: Double?,
)

class ConversionException(message: String, cause: Throwable? = null) : Exception(message, cause)
