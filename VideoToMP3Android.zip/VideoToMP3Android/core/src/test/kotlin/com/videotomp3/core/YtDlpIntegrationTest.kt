package com.videotomp3.core

import com.sun.net.httpserver.HttpServer
import org.junit.AfterClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume
import org.junit.BeforeClass
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.net.InetSocketAddress

/**
 * Runs the real yt-dlp (desktop build, same engine the Android library bundles) with the exact
 * options produced by [YtDlpArgs] against a local HTTP server, and parses its real progress output.
 */
class YtDlpIntegrationTest {
    @get:Rule val tmp = TemporaryFolder()

    companion object {
        private lateinit var server: HttpServer
        private var port = 0
        private val ytDlp: List<String>? by lazy {
            TestTools.which("yt-dlp")?.let { listOf(it) }
                ?: runCatching { TestTools.exec("python3", "-m", "yt_dlp", "--version"); listOf("python3", "-m", "yt_dlp") }.getOrNull()
        }

        @BeforeClass @JvmStatic fun start() {
            val samples = TestTools.samples
            server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
            server.createContext("/") { ex ->
                val f = File(samples, ex.requestURI.path.removePrefix("/").removePrefix("slow/"))
                val slow = ex.requestURI.path.startsWith("/slow/")
                if (!f.isFile) { ex.sendResponseHeaders(404, -1); ex.close(); return@createContext }
                ex.responseHeaders.add("Content-Type", "video/mp4")
                ex.sendResponseHeaders(200, f.length())
                try {
                    ex.responseBody.use { out ->
                        f.inputStream().use { inp ->
                            val buf = ByteArray(if (slow) 32 * 1024 else 64 * 1024)
                            while (true) {
                                val n = inp.read(buf); if (n < 0) break
                                out.write(buf, 0, n)
                                if (slow) Thread.sleep(40)
                            }
                        }
                    }
                } catch (_: Exception) { }
            }
            server.start()
            port = server.address.port
        }

        @AfterClass @JvmStatic fun stop() = server.stop(0)
    }

    private fun run(url: String, args: List<String>, onLine: (String) -> Unit = {}): Int {
        val cmd = ytDlp!! + args + listOf("--ffmpeg-location", TestTools.ffmpeg, url)
        val pb = ProcessBuilder(cmd).redirectErrorStream(true)
        pb.environment()["no_proxy"] = "127.0.0.1,localhost"
        pb.environment()["NO_PROXY"] = "127.0.0.1,localhost"
        val p = pb.start()
        p.inputStream.bufferedReader().forEachLine(onLine)
        return p.waitFor()
    }

    @Test fun audioDownloadThenConvert() {
        Assume.assumeNotNull(ytDlp)
        val work = tmp.newFolder("work")
        val lines = mutableListOf<String>()
        val code = run("http://127.0.0.1:$port/slow/sample.mkv", YtDlpArgs.download(work, YtDlpArgs.Mode.AUDIO, null, true)) { lines += it }
        assertEquals(lines.joinToString("\n"), 0, code)
        val progress = lines.mapNotNull(YtDlpProgress::parse)
        assertTrue("progress lines parsed: $lines", progress.size >= 2)
        assertTrue(progress.any { it.speedBytesPerSec != null && it.totalBytes != null })
        assertEquals(100.0, progress.last().percent!!, 0.001)
        val (media, _) = YtDlpArgs.findOutputs(work)
        assertNotNull("media file in ${work.list()?.toList()}", media)

        // Same pipeline the app runs after a download: convert to MP3 with our engine.
        val out = File(tmp.root, "My Video.mp3")
        kotlinx.coroutines.runBlocking {
            AudioConverter(FfmpegRunner(TestTools.ffmpeg, TestTools.ffprobe))
                .convert(media!!, out, ConversionSpec(AudioFormat.MP3, AudioQuality.K320, title = "My Video"), tmp.newFolder())
        }
        assertEquals("My Video", TestTools.probe(out)["format.tags.title"])
    }

    @Test fun videoDownloadAsMp4() {
        Assume.assumeNotNull(ytDlp)
        val work = tmp.newFolder("work")
        val lines = mutableListOf<String>()
        val code = run("http://127.0.0.1:$port/sample.mp4", YtDlpArgs.download(work, YtDlpArgs.Mode.VIDEO, 720, false)) { lines += it }
        assertEquals(lines.joinToString("\n"), 0, code)
        val (media, _) = YtDlpArgs.findOutputs(work)
        assertEquals("mp4", media!!.extension)
        val p = TestTools.probe(media)
        assertTrue(p.values.contains("video") && p.values.contains("audio"))
    }

    @Test fun missingMediaGivesFriendlyError() {
        Assume.assumeNotNull(ytDlp)
        val lines = mutableListOf<String>()
        val code = run("http://127.0.0.1:$port/gone.mp4", YtDlpArgs.download(tmp.newFolder(), YtDlpArgs.Mode.AUDIO, null, false)) { lines += it }
        assertTrue(code != 0)
        assertTrue(ErrorMessages.download(lines.joinToString("\n")).contains("unavailable"))
    }

    @Test fun unreachableHostGivesNetworkError() {
        Assume.assumeNotNull(ytDlp)
        val lines = mutableListOf<String>()
        val code = run("http://127.0.0.1:9/video.mp4", YtDlpArgs.download(tmp.newFolder(), YtDlpArgs.Mode.AUDIO, null, false) +
            listOf("--retries", "0", "--extractor-retries", "0")) { lines += it }
        assertTrue(code != 0)
        assertTrue(lines.joinToString("\n"), ErrorMessages.download(lines.joinToString("\n")).startsWith("Network error"))
    }
}
