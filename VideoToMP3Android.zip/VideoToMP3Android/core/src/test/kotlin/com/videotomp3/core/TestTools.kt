package com.videotomp3.core

import org.junit.Assume
import java.io.File
import java.util.concurrent.TimeUnit

object TestTools {
    fun which(name: String): String? = System.getenv("PATH").orEmpty().split(File.pathSeparator)
        .map { File(it, name) }.firstOrNull { it.canExecute() }?.absolutePath

    val ffmpeg: String by lazy { which("ffmpeg").also { Assume.assumeNotNull(it) }!! }
    val ffprobe: String? by lazy { which("ffprobe") }

    fun exec(vararg cmd: String): String {
        val p = ProcessBuilder(*cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        check(p.waitFor(300, TimeUnit.SECONDS) && p.exitValue() == 0) { "Command failed: ${cmd.joinToString(" ")}\n$out" }
        return out
    }

    /** Generates a small test video (test pattern + 440 Hz tone). */
    fun video(dir: File, name: String, seconds: Int, vcodec: List<String>, acodec: List<String>?): File {
        val out = File(dir, name)
        if (out.exists()) return out
        val cmd = mutableListOf(ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "testsrc=size=320x240:rate=15:duration=$seconds")
        if (acodec != null) cmd += listOf("-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100:duration=$seconds", "-shortest")
        cmd += vcodec
        if (acodec != null) cmd += acodec
        cmd += out.absolutePath
        exec(*cmd.toTypedArray())
        return out
    }

    /** ffprobe key=value dump for assertions. */
    fun probe(file: File): Map<String, String> {
        val text = exec(ffprobe ?: error("ffprobe required"), "-v", "error", "-show_format", "-show_streams", "-of", "flat", file.absolutePath)
        return text.lines().filter { '=' in it }.associate { it.substringBefore('=') to it.substringAfter('=').trim('"') }
    }

    val samples: File by lazy {
        val dir = File(System.getProperty("java.io.tmpdir"), "vtm-core-samples").apply { mkdirs() }
        val mpeg4 = listOf("-c:v", "mpeg4")
        video(dir, "sample.mp4", 6, mpeg4, listOf("-c:a", "aac", "-b:a", "128k"))
        video(dir, "sample.mkv", 6, mpeg4, listOf("-c:a", "libmp3lame", "-b:a", "128k"))
        video(dir, "sample.mov", 4, mpeg4, listOf("-c:a", "aac"))
        video(dir, "sample.avi", 4, mpeg4, listOf("-c:a", "libmp3lame"))
        video(dir, "sample.webm", 4, listOf("-c:v", "libvpx", "-b:v", "200k"), listOf("-c:a", "libopus"))
        video(dir, "sample.flv", 4, listOf("-c:v", "flv"), listOf("-c:a", "libmp3lame", "-ar", "44100"))
        video(dir, "sample.3gp", 4, listOf("-c:v", "h263", "-s", "352x288"), listOf("-c:a", "aac", "-ar", "16000", "-ac", "1"))
        video(dir, "silent.mp4", 2, mpeg4, null)
        File(dir, "corrupt.mp4").writeBytes(ByteArray(5000) { (it % 7).toByte() })
        val long = File(dir, "long.mkv")
        if (!long.exists()) exec(ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
            "-i", "anoisesrc=d=1500:c=pink:r=44100", "-c:a", "flac", "-compression_level", "0", long.absolutePath)
        dir
    }
}
