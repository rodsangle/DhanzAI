package com.videotomp3.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** Real FFmpeg runs on generated media (skipped automatically if ffmpeg is not installed). */
class ConverterTest {
    @get:Rule val tmp = TemporaryFolder()

    private val samples get() = TestTools.samples
    private val converter by lazy { AudioConverter(FfmpegRunner(TestTools.ffmpeg, TestTools.ffprobe)) }

    private fun convert(name: String, spec: ConversionSpec, out: String = "out.${spec.format.extension}",
                        progress: MutableList<ConversionProgress>? = null): File = runBlocking {
        val output = File(tmp.root, out)
        converter.convert(File(samples, name), output, spec, tmp.newFolder()) { progress?.add(it) }
        output
    }

    private fun audioStream(p: Map<String, String>, key: String) =
        p.entries.first { it.key.startsWith("streams.stream.") && it.key.endsWith(".codec_type") && it.value == "audio" }
            .key.removeSuffix("codec_type").let { p[it + key] }

    @Test fun probeWithFfprobeAndFallbackParser() = runBlocking {
        val info = converter.probe(File(samples, "sample.mp4"))
        assertTrue(info.hasAudio && info.hasVideo)
        assertEquals("aac", info.audioCodec)
        assertEquals(6.0, info.durationSec!!, 0.2)
        assertEquals(320, info.videoWidth)
        val fallback = FfmpegRunner(TestTools.ffmpeg, null).probe(File(samples, "sample.mkv"))
        assertEquals("mp3", fallback.audioCodec)
        assertEquals(6.0, fallback.durationSec!!, 0.2)
        assertTrue(fallback.hasVideo)
    }

    @Test fun mp4ToMp3At320kbps() {
        val progress = mutableListOf<ConversionProgress>()
        val out = convert("sample.mp4", ConversionSpec(AudioFormat.MP3, AudioQuality.K320), progress = progress)
        val p = TestTools.probe(out)
        assertEquals("1", p["format.nb_streams"]) // audio only, video dropped
        assertEquals("mp3", audioStream(p, "codec_name"))
        assertEquals("320000", audioStream(p, "bit_rate"))
        assertEquals(6.0, p["format.duration"]!!.toDouble(), 0.3)
        assertTrue("progress reported", progress.isNotEmpty())
        assertEquals(100.0, progress.last().percent!!, 0.001)
    }

    @Test fun mkvToMp3() {
        val out = convert("sample.mkv", ConversionSpec(AudioFormat.MP3, AudioQuality.K192))
        assertEquals("192000", audioStream(TestTools.probe(out), "bit_rate"))
    }

    @Test fun originalQualityStreamCopiesMatchingCodec() {
        val out = convert("sample.mkv", ConversionSpec(AudioFormat.MP3, AudioQuality.ORIGINAL))
        assertEquals("128000", audioStream(TestTools.probe(out), "bit_rate")) // untouched MP3 stream
        val m4a = convert("sample.mp4", ConversionSpec(AudioFormat.M4A, AudioQuality.ORIGINAL))
        assertEquals("aac", audioStream(TestTools.probe(m4a), "codec_name"))
    }

    @Test fun allOutputFormats() {
        val expected = mapOf(AudioFormat.MP3 to "mp3", AudioFormat.M4A to "aac", AudioFormat.AAC to "aac",
            AudioFormat.WAV to "pcm_s16le", AudioFormat.FLAC to "flac")
        for ((fmt, codec) in expected) {
            val out = convert("sample.mp4", ConversionSpec(fmt, AudioQuality.K256))
            assertEquals(fmt.name, codec, audioStream(TestTools.probe(out), "codec_name"))
        }
    }

    @Test fun batchOfAllInputContainers() = runBlocking {
        val names = listOf("sample.mp4", "sample.mov", "sample.avi", "sample.mkv", "sample.webm", "sample.flv", "sample.3gp")
        val outputs = coroutineScope {
            names.map { n ->
                async {
                    val out = File(tmp.root, n.replace('.', '_') + ".mp3")
                    converter.convert(File(samples, n), out, ConversionSpec(AudioFormat.MP3, AudioQuality.K128), tmp.newFolder())
                    out
                }
            }.awaitAll()
        }
        for (o in outputs) assertEquals(o.name, "mp3", audioStream(TestTools.probe(o), "codec_name"))
    }

    @Test fun trimMetadataAndCoverFromVideoFrame() {
        val out = convert("sample.mp4", ConversionSpec(AudioFormat.MP3, AudioQuality.K192, startSec = 1.0, endSec = 3.5,
            title = "Título ♫", artist = "Artista 日本", album = "Álbum", coverFromVideoFrame = true), out = "Mi canción ♫.mp3")
        val p = TestTools.probe(out)
        assertEquals(2.5, p["format.duration"]!!.toDouble(), 0.15)
        assertEquals("Título ♫", p["format.tags.title"])
        assertEquals("Artista 日本", p["format.tags.artist"])
        assertEquals("Álbum", p["format.tags.album"])
        assertEquals("1", p.entries.first { it.key.endsWith("disposition.attached_pic") && it.value == "1" }.value)
    }

    @Test fun coverImageEmbeddedInFlacAndM4a() {
        val cover = File(tmp.root, "cover.png")
        TestTools.exec(TestTools.ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=blue:s=300x300",
            "-frames:v", "1", cover.absolutePath)
        for (fmt in listOf(AudioFormat.FLAC, AudioFormat.M4A)) {
            val out = convert("sample.mov", ConversionSpec(fmt, AudioQuality.K256, coverImage = cover))
            assertTrue(fmt.name, TestTools.probe(out).any { it.key.endsWith("disposition.attached_pic") && it.value == "1" })
        }
    }

    @Test fun friendlyErrors() {
        fun failure(name: String, spec: ConversionSpec = ConversionSpec()) = try {
            convert(name, spec); fail("expected failure"); ""
        } catch (e: ConversionException) { e.message!! }
        assertTrue(failure("corrupt.mp4").contains("damaged"))
        assertTrue(failure("silent.mp4").contains("no audio"))
        assertTrue(failure("missing.mp4").contains("could not be found"))
        assertTrue(failure("sample.mp4", ConversionSpec(startSec = 4.0, endSec = 2.0)).contains("end time"))
    }

    @Test fun cancellationKillsFfmpegPromptly() = runBlocking {
        val out = File(tmp.root, "long.mp3")
        var lastPercent = 0.0
        val job = launch {
            converter.convert(File(samples, "long.mkv"), out, ConversionSpec(AudioFormat.MP3, AudioQuality.K320), tmp.newFolder()) {
                lastPercent = it.percent ?: 0.0
            }
        }
        withTimeout(30_000) { while (lastPercent < 1.0) delay(20) }
        val t0 = System.nanoTime()
        job.cancel(CancellationException("user cancelled"))
        job.join()
        val tookMs = (System.nanoTime() - t0) / 1e6
        assertTrue("cancel took $tookMs ms", tookMs < 3000)
        assertTrue(job.isCancelled)
        assertTrue("cancelled before finishing ($lastPercent%)", lastPercent < 100.0)
        // No ffmpeg process should still be writing: the partial file size must stay constant.
        val size = out.length()
        delay(500)
        assertEquals(size, out.length())
        assertFalse(lastPercent >= 100.0)
    }
}
