package com.videotomp3.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class TextUtilsTest {
    @Test fun sanitizeKeepsUnicodeAndRemovesInvalid() {
        assertEquals("Café_ _Live_ 日本語_", FileNames.sanitize("Café: \"Live\" 日本語?"))
        assertEquals("audio", FileNames.sanitize("  ...  "))
        assertEquals("audio_CON", FileNames.sanitize("CON"))
        assertEquals(FileNames.MAX_STEM, FileNames.sanitize("x".repeat(400)).length)
        assertEquals("hidden", FileNames.sanitize(".hidden"))
    }

    @Test fun uniqueNamesNeverOverwrite() {
        val existing = mutableSetOf("song.mp3", "song (1).mp3")
        assertEquals("song (2).mp3", FileNames.unique("song", "mp3") { it in existing })
        assertEquals("other.mp3", FileNames.unique("other", "mp3") { it in existing })
    }

    @Test fun parseTime() {
        assertNull(TimeText.parse(""))
        assertEquals(90.0, TimeText.parse("1:30")!!, 0.0)
        assertEquals(3723.5, TimeText.parse("01:02:03.5")!!, 0.0)
        assertEquals(2.5, TimeText.parse("2,5")!!, 0.0)
        for (bad in listOf("abc", "1:75", "1::2", "-4", "1:2:3:4")) {
            assertThrows(IllegalArgumentException::class.java) { TimeText.parse(bad) }
        }
    }

    @Test fun formatting() {
        assertEquals("1:05", TimeText.duration(65.0))
        assertEquals("1:02:03", TimeText.duration(3723.0))
        assertEquals("1.5 MB", TimeText.bytes(1_572_864))
        assertEquals("", TimeText.speed(null))
    }

    @Test fun urls() {
        assertEquals("https://youtu.be/abc", Urls.extractFromText("Look at this: https://youtu.be/abc!"))
        assertEquals("https://vimeo.com/1", Urls.validate("vimeo.com/1"))
        assertEquals("https://www.tiktok.com/@a/video/1", Urls.validate("Shared via TikTok https://www.tiktok.com/@a/video/1"))
        for (bad in listOf("", "   ", "ftp://x.com/a", "not a url", "javascript:alert(1)", "http://")) {
            assertThrows(bad, IllegalArgumentException::class.java) { Urls.validate(bad) }
        }
    }

    @Test fun inputFormats() {
        for (n in listOf("a.mp4", "b.MOV", "c.avi", "d.mkv", "e.webm", "f.flv", "g.3gp")) assertTrue(n, InputFormats.isSupportedName(n))
        assertTrue(!InputFormats.isSupportedName("notes.txt"))
    }

    @Test fun downloadErrors() {
        val f = ErrorMessages::download
        assertTrue(f("ERROR: This video is DRM protected").contains("DRM"))
        assertTrue(f("ERROR: [youtube] x: Private video. Sign in if you've been granted access").contains("private"))
        assertTrue(f("ERROR: [instagram] x: login required").contains("signing in"))
        assertTrue(f("ERROR: Unable to download webpage: <urlopen error [Errno 7] No address associated with hostname>").startsWith("Network error"))
        assertTrue(f("ERROR: Unsupported URL: https://example.com/x").contains("not supported"))
        assertTrue(f("ERROR: something odd").startsWith("Download failed: something odd"))
    }

    @Test fun ytDlpProgressLines() {
        val p = YtDlpProgress.parse("[download]  45.3% of   10.00MiB at    1.20MiB/s ETA 00:05")!!
        assertEquals(45.3, p.percent!!, 0.001)
        assertEquals(10L * 1024 * 1024, p.totalBytes)
        assertEquals(1.2 * 1024 * 1024, p.speedBytesPerSec!!, 1.0)
        assertEquals(5L, p.etaSec)
        val q = YtDlpProgress.parse("[download]   3.0% of ~  55.21MiB at  Unknown B/s ETA Unknown (frag 1/120)")!!
        assertEquals(3.0, q.percent!!, 0.0)
        assertNull(q.speedBytesPerSec)
        val done = YtDlpProgress.parse("[download] 100% of    5.37MiB in 00:00:02 at 2.11MiB/s")!!
        assertEquals(100.0, done.percent!!, 0.0)
        assertNull(YtDlpProgress.parse("[info] Downloading webpage"))
    }

    @Test fun videoFormatSelector() {
        assertTrue(YtDlpArgs.videoFormatSelector(720).startsWith("bv*[ext=mp4][height<=720]+ba[ext=m4a]"))
        assertEquals("bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b[ext=mp4]/b/bv*+ba/b", YtDlpArgs.videoFormatSelector(null))
    }
}
