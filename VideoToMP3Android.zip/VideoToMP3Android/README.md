# Video to MP3 – Converter & Downloader (Android)

A native Android app (Kotlin, Jetpack Compose, Material 3) that:
- converts videos on the device into MP3, M4A, AAC, WAV or FLAC, fully offline;
- downloads permitted, publicly accessible online media as MP4 or audio.

- **Platforms:** Android 10 (API 29) → Android 16 (API 36), on phones and tablets, in portrait and landscape.
- **ABIs:** arm64-v8a and armeabi-v7a. x86_64 is also included in debug builds, for emulators.
- **No ads, subscriptions, tracking or accounts.** The app never asks for website passwords and never bypasses DRM, logins, paywalls or other site restrictions.

---

## 1. Build status: read this first

| Item | Status |
|---|---|
| `:core` module (conversion engine, FFmpeg runner, yt-dlp options and progress parsing, filenames, URL and error handling) | **Compiled and tested: 23/23 tests pass.** These run on a desktop JVM against real FFmpeg 6.1 and yt-dlp. |
| `:app` Kotlin sources | **Syntax-checked with the Kotlin 2.2 compiler** (0 syntax errors). |
| Full Android build (`assembleDebug` / `assembleRelease`) | **Not run.** The build machine's network policy blocked Google's Android repositories (`dl.google.com` / `maven.google.com`), so neither the Android SDK nor the AndroidX/AGP libraries could be downloaded. **No APK is included.** Build it with the steps in section 4, or let the GitHub Actions workflow in `.github/workflows/build-apk.yml` build it. |
| Behaviour on a real device | **Not tested.** Covers share intents, scoped storage, notifications, background work and playback. Run the instrumented tests and the manual checklist in section 6. |

Library versions were pinned to stable releases known to work together: AGP 8.11.1, Kotlin 2.2.0, KSP 2.2.0-2.0.2, Hilt 2.57, Compose BOM 2025.06.01, Room 2.7.2, WorkManager 2.10.2, Media3 1.7.1.

The Maven Central artifacts were confirmed to exist, including the yt-dlp/FFmpeg library 0.18.1, whose API was checked directly from its AAR. Google Maven versions couldn't be checked from the build machine. If Android Studio reports one as missing or outdated, accept its suggested update in `gradle/libs.versions.toml`.

---

## 2. Features

**Tab 1 – URL Downloader** (with the dashboard)
- The header reads **VIDEO TO MP3 / Converter & Downloader**, with two big actions: **CONVERT VIDEO** and **PASTE VIDEO LINK**.
- URL input, **Paste Link** and **Analyze Video**. Analysis shows the thumbnail, title, uploader, site, duration, available qualities and an approximate size.
- **Download MP3** (the button follows the chosen output format: MP3/M4A/AAC/WAV/FLAC) and **Download MP4**.
- Audio quality options: 128 / 192 / 256 / 320 kbps or Original (stream copy when possible). The MP4 download quality is selectable.
- Optional metadata (title/artist/album), trim start/end, and the thumbnail embedded as album artwork.
- Links shared from other apps (YouTube, browsers, TikTok…) open here automatically.

**Tab 2 – Video Converter**
- **Select Video** opens the system file picker (Storage Access Framework). You can select several files for **batch conversion**.
- **Drag & drop** works on tablets, foldables, ChromeOS and split-screen.
- Inputs: MP4, MOV, AVI, MKV, WEBM, FLV, 3GP, plus WMV, TS and MPG.
- Shows info for each file (size, duration, resolution, audio present), and each output file name is editable.
- Output in MP3/M4A/AAC/WAV/FLAC at 128/192/256/320 kbps or Original. Includes metadata, trim, and album artwork from a video frame or a chosen image.
- Live conversion progress bars, and a notification when a conversion completes.
- Videos shared from Gallery or Files ("Convert to MP3" in the Share menu) arrive here.

**Tab 3 – Downloads**
- **Active**, **Completed** and **History** lists. Each item shows progress %, speed, ETA, file size and format.
- Actions: **Pause / Resume** (resume continues from the partial file when the site supports it), **Cancel**, **Retry**, **Play** (built-in Media3 player with play/pause/seek/±10 s), **Share**, **Open**, **Folder** and **Delete** (optionally deletes the file too).

**Tab 4 – Settings**
- Download folder: either the default `Music/VideoToMP3` and `Movies/VideoToMP3`, or any folder you pick.
- Preferred MP3 bitrate, default output format and preferred video quality.
- Wi-Fi-only downloads, and maximum concurrent tasks (1–5).
- Vibration and sound on completion.
- Theme: System / Light / Dark.
- Storage usage (saved files, temporary files, free space), plus Clear temporary files and Clear download history.
- A **Update yt-dlp** button, and an About section with the legal notice.

**Behaviour you can rely on**
- Settings are remembered (format, bitrate, artwork, folder…).
- Existing files are never overwritten: duplicates get `name (1).mp3`, `name (2).mp3`…
- Files are written through MediaStore or the folder you chose. No broad storage permission is requested.
- Temporary files are cleaned up after every task, and on demand.
- Long tasks run in WorkManager as **foreground work**:
  - `mediaProcessing` type on Android 15+ for conversions;
  - `dataSync` type otherwise.
- Progress notifications have Cancel and Pause buttons.
- Network loss surfaces as a clear error with **Retry**. "Wi-Fi only" downloads wait for an unmetered network.
- The notification permission is requested only on Android 13+, and only once you start a task.
- Includes a splash screen (AndroidX SplashScreen), an adaptive launcher icon with a themed (monochrome) layer, and dark navy/blue Material 3 themes.

---

## 3. Architecture

```
VideoToMP3Android/
├── settings.gradle.kts, build.gradle.kts, gradle.properties, gradle/libs.versions.toml, gradlew
├── core/                       Pure Kotlin/JVM – fully unit-tested on the desktop
│   └── src/main/kotlin/com/videotomp3/core/
│       ├── Formats.kt          AudioFormat, AudioQuality, ConversionSpec, MediaInfo
│       ├── FfmpegCommands.kt   FFmpeg argument builder + -progress parser
│       ├── FfmpegRunner.kt     runs ffmpeg/ffprobe processes, progress, cancellation
│       ├── AudioConverter.kt   probe → validate → artwork → convert → verify
│       ├── MediaProbe.kt       ffprobe / ffmpeg output parsers
│       ├── YtDlp.kt            yt-dlp options, output discovery, progress-line parser
│       ├── ErrorMessages.kt    friendly FFmpeg / download error messages
│       └── TextUtils.kt        filenames (unique, sanitised), time parsing, URL validation
└── app/                        Android application (MVVM + Hilt)
    ├── src/main/AndroidManifest.xml   share-target intent filters, typed foreground service
    ├── src/main/java/com/videotomp3/app/
    │   ├── VideoToMp3App.kt     Hilt app, WorkManager config, engine warm-up
    │   ├── MainActivity.kt      splash, edge-to-edge, incoming share/VIEW intents
    │   ├── ShareBus.kt          hands shared links/videos to screens
    │   ├── data/                Room (TaskEntity, TaskDao), DataStore settings,
    │   │                        StorageRepository (SAF + MediaStore), TaskRepository
    │   ├── engine/MediaEngine   yt-dlp (youtubedl-android) + bundled FFmpeg 7.1
    │   ├── work/                TaskWorker (WorkManager), ConcurrencyGate,
    │   │                        TaskNotifier, NotificationActionReceiver
    │   └── ui/                  Compose screens + ViewModels: url/, convert/, downloads/,
    │                            settings/, player/, components/, theme/
    ├── src/androidTest/         on-device FFmpeg engine tests
    └── proguard-rules.pro
```

**Media stack**
- [`io.github.junkfood02.youtubedl-android`](https://github.com/JunkFood02/youtubedl-android) 0.18.1 bundles three things:
  - **yt-dlp**, with Python 3 and QuickJS;
  - an **FFmpeg 7.1** build with LAME (MP3), AAC, FLAC, Opus, Vorbis and libx264;
  - **FFprobe**.
- All three ship for arm64-v8a, armeabi-v7a, x86 and x86_64, and the ELF segments are **16 KB-aligned**, which Android 15+ devices with 16 KB pages require.
- Local conversion runs the bundled `ffmpeg` executable directly, so it **works completely offline**. Only the first audio stream is processed; video is never re-encoded.
- **Original quality** stream-copies when the codec already matches (e.g. AAC→M4A, MP3→MP3).

---

## 4. Building the APK

### Requirements
- **Android Studio** Narwhal (2025.1) or newer, with the bundled JDK 17/21.
- Android SDK Platform **36**. Android Studio installs it automatically on first sync.
- About 3 GB of free disk space for the SDK and the Gradle cache.
- No NDK is needed: the native FFmpeg/Python binaries come prebuilt inside the dependency.

### Step by step (Android Studio)
1. **Open the project:** *File → Open…* → select the `VideoToMP3Android` folder.
2. **Download dependencies:** Android Studio runs *Gradle Sync* automatically. If it asks, accept *Install missing SDK platform 36* and *Use Gradle wrapper* (Gradle 8.14.3).
3. **SDK and native libraries:** nothing to configure. The FFmpeg/yt-dlp native libraries come from Maven Central. `local.properties` (with `sdk.dir`) is created by Android Studio.
4. **Build the debug APK:** *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.
   - Output: `app/build/outputs/apk/debug/app-debug.apk`
5. **Build the release APK:** *Build → Generate Signed App Bundle or APK… → APK*:
   - create a keystore (or pick an existing one) → choose `release` → Finish.
   - Output: `app/build/outputs/apk/release/app-release.apk`

### Command line
```bash
./gradlew :core:test            # engine tests (needs ffmpeg + yt-dlp on PATH for integration tests)
./gradlew assembleDebug         # → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease       # → app/build/outputs/apk/release/app-release.apk (signed if configured)
```

Optional Gradle properties:
- `-Pvideotomp3.includeX86=true` adds x86_64 to release builds, for Chromebooks and emulators.
- `-Pvideotomp3.minify=false` builds the release without R8. Use it if a release build ever misbehaves.

### Signing the release APK (no secrets in the build files)
1. Create a keystore once. Keep it and its passwords safe, because you need the same key for every update:
   ```bash
   keytool -genkeypair -v -keystore release-keystore.jks -keyalg RSA -keysize 4096 -validity 10000 -alias videotomp3
   ```
2. Copy `keystore.properties.example` → `keystore.properties` and fill in the values. Both the `.properties` and `.jks` files are git-ignored.
3. Alternatively, set environment variables: `VTM_KEYSTORE_FILE`, `VTM_KEYSTORE_PASSWORD`, `VTM_KEY_ALIAS`, `VTM_KEY_PASSWORD`.
4. Run `./gradlew assembleRelease`. Without signing values, Gradle produces `app-release-unsigned.apk`; sign it with:
   ```bash
   zipalign -p 4 app-release-unsigned.apk aligned.apk
   apksigner sign --ks release-keystore.jks --out app-release.apk aligned.apk
   ```

### Build in the cloud instead (GitHub Actions)
Push the project to a GitHub repository. The workflow `.github/workflows/build-apk.yml`:
- runs the core tests;
- builds `app-debug.apk` and `app-release.apk`;
- attaches both as the **apks** artifact of the run.

To get a signed release, add these repository secrets: `VTM_KEYSTORE_BASE64` (from `base64 -w0 release-keystore.jks`), `VTM_KEYSTORE_PASSWORD`, `VTM_KEY_ALIAS`, `VTM_KEY_PASSWORD`.

**APK size:** about 110 MB for a release with arm64 + armv7 (about 165 MB for the debug APK, which also has x86_64), because it bundles Python, yt-dlp and FFmpeg. For smaller per-device APKs, publish an App Bundle (`./gradlew bundleRelease`); Google Play then delivers only the matching ABI.

---

## 5. Installing on a phone

1. Copy the APK to the phone using a USB cable (file transfer mode), Google Drive, e-mail, or `adb install app-debug.apk`.
2. On the phone, open the APK from **Files** / **Downloads**.
3. When Android asks, allow **Install unknown apps** for the app you opened it with: *Settings → Apps → Special app access → Install unknown apps*.
4. Tap **Install**, then **Open**.
5. On first launch, the app unpacks its media tools, which takes a few seconds. On Android 13+, allow notifications when you start your first task.

---

## 6. Testing

### Automated tests
| Test | Where | Result |
|---|---|---|
| MP4 → MP3 at **320 kbps** (bitrate verified with ffprobe) | `core` `ConverterTest` | ✅ passed on the build machine |
| MKV → MP3; Original-quality stream copy | `core` | ✅ |
| **Batch** of MP4, MOV, AVI, MKV, WEBM, FLV, 3GP (run in parallel) | `core` | ✅ |
| All outputs (MP3, M4A, AAC, WAV, FLAC), trim, Unicode metadata, artwork from a video frame or image | `core` | ✅ |
| Damaged file / no audio track / missing file / bad trim give clear errors | `core` | ✅ |
| **Cancelling** a conversion kills FFmpeg within 3 s | `core` | ✅ |
| Real **yt-dlp** download with the app's options, progress/speed parsing, then MP3 conversion; MP4 download with merge | `core` `YtDlpIntegrationTest` (local HTTP server) | ✅ |
| Unsupported/missing URL and **network-unreachable** errors map to friendly messages | `core` | ✅ |
| Same engine on a **real device**: MP4→MP3 320 kbps, MKV→every format, cancellation | `app/src/androidTest` → `./gradlew connectedDebugAndroidTest` | ⚠️ written, **not run** (no emulator or device here) |

### Manual checklist on a device (not yet performed)
- [ ] Convert a local MP4 to MP3 at 320 kbps. Play it in the built-in player, share it, open it, delete it.
- [ ] Batch-convert 3 videos and check they all appear in `Music/VideoToMP3`.
- [ ] Choose a custom folder in Settings, convert, and confirm the file is saved there. A duplicate name should get ` (1)`.
- [ ] Cancel an active conversion and confirm no partial file is left behind.
- [ ] Share a video from Gallery to the app, and share a YouTube link from the YouTube app.
- [ ] Download audio and MP4 from a public video you're allowed to download. Pause/resume it, then turn on airplane mode mid-download and confirm you get an error with Retry.
- [ ] Turn on Wi-Fi only, go on mobile data, and confirm the task waits.
- [ ] Lock the screen during a long conversion and confirm it continues, with a progress notification.
- [ ] Rotate the device and try a tablet layout (navigation rail).

### Known limitations
- **Online platforms change often.** Downloads work only for publicly accessible media that yt-dlp supports. YouTube in particular may demand sign-in or bot checks for some videos; the app refuses those rather than logging in. Use *Settings → Update yt-dlp* when a site stops working.
- **DRM-protected, private, age-restricted, members-only and live content** is reported as unavailable, by design.
- "Open folder" depends on the device's file manager. If it can't open the folder, the app tells you the path.
- If Android refuses to start foreground work (for example when the app is in the background), very long tasks may be paused by the system and are resumed automatically by WorkManager.

---

## 7. Compliance & licences
- Only download media you own, are licensed to download, or are otherwise permitted to save. Respect copyright and each platform's terms.
- Permissions used: `INTERNET`, `ACCESS_NETWORK_STATE`, `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE` (+ `DATA_SYNC`, `MEDIA_PROCESSING`) and `VIBRATE`. **No storage permissions.**
- The bundled FFmpeg build includes GPL components (e.g. libx264), and youtubedl-android is GPL-3.0. **Distribute the app under GPL-3.0-compatible terms and provide the source**, which this project already does.
